(function(){
'use strict';
const el=id=>document.getElementById(id);
const get=id=>el(id).value.trim();
const number=id=>{const n=Number(get(id));if(!Number.isFinite(n))throw Error('Invalid setting: '+id);return n;};
const localHost=['127.0.0.1','localhost'].includes(location.hostname) && location.port==='8765';
const api=async(path,body)=>{
  if(!localHost)throw Error('Local Python bridge unavailable. Open http://127.0.0.1:8765 after python launch.py');
  const r=await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,cache:'no-store'});
  const d=await r.json();if(!r.ok)throw Error(d.error||r.statusText);return d;
};
let reportCache=null;
function renderPPL(original,pre,post){
  const vals=[original,pre,post],names=['Original Q8 perplexity','Pre-recovery perplexity','Post-recovery perplexity'];
  const read=v=>v&&Number.isFinite(v.ppl)?v.ppl.toLocaleString('en-US',{maximumFractionDigits:3}):v&&Number.isFinite(v.nll)?'Overflow (NLL '+v.nll.toFixed(3)+')':'Pending';
  el('pplResults').replaceChildren(...vals.map((v,i)=>{
    const b=document.createElement('div');b.className='kv';
    const title=document.createElement('div');title.className='k';title.textContent=names[i];
    const value=document.createElement('div');value.className='v';value.textContent=read(v);
    b.append(title,value);return b;
  }));
}
function recipe(){
  const budget=Math.round(number('budgetMillions')*1_000_000);
  if(budget<100||budget>100_000_000_000)throw Error('Recovery budget must be between 100 and 100,000,000,000 token exposures');
  const mode=get('recoveryMode');
  const res={factor_gguf:get('factorPath'),q8_gguf:get('q8Path'),hf_model:get('hfPath'),
    corpus_dir:get('tokenDir'),output_dir:get('runDir'),checkpoint:get('checkpointPath'),mode,
    budget_tokens:budget,seq_len:number('recoverySeq'),batch_size:number('recoveryBatch'),
    device:get('trainingDevice'),seed:20261007,lr:number('recoveryLR'),
    validation_tokens:number('recoveryValTokens'),checkpoint_every:number('recoveryCheck'),
    retain:number('recoveryRetain'),log_every:5,lr_schedule:get('lrSchedule'),warmup_ratio:0.02};
  if(!res.factor_gguf||!res.q8_gguf||!res.hf_model||!res.corpus_dir||!res.output_dir)throw Error('Fill all required model and corpus paths');
  if(mode!=='new'&&!res.checkpoint)throw Error('Checkpoint path required for resume/cycle');
  return res;
}
function corpusRecipe(){
  const r={hf_model:get('corpusHF'),corpus_dir:get('corpusDir'),mode:get('corpusMode'),
    import_dir:get('corpusImport'),per_stage:number('corpusStageTokens'),
    validation:number('corpusValidation'),max_rows:number('corpusMaxRows'),seed:number('corpusSeed')};
  if(!r.hf_model||!r.corpus_dir)throw Error('Model and corpus paths required');
  if(r.mode==='import'&&!r.import_dir)throw Error('Choose a local directory containing stage1.txt...stage5.txt plus validation.txt');
  return r;
}
function updateBudget(){
  const millions=number('budgetMillions');
  const total=millions*1e6;
  const stage=total/5;
  const cap=number('corpusStageTokens')*5;
  el('tokenEstimate').textContent=`${total.toLocaleString()} token exposures; ${stage.toLocaleString()} per stage. `+
      `If you build ${cap.toLocaleString()} corpus tokens, the estimated average exposure reuse is ${(total/cap).toFixed(3)}× `+
      `(stage 5 already deliberately replays earlier documents). No job starts when you change this.`;
}
function error(where,msg){el(where).textContent='Error: '+msg;}
for(const id of ['budgetMillions','corpusStageTokens'])el(id).addEventListener('input',()=>{try{updateBudget();}catch(e){error('tokenEstimate',e.message);}});
updateBudget();
function download(name,bytes,type){
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bytes],{type:type||'application/octet-stream'}));
  a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2500);
}
el('downloadRecipe').onclick=()=>{try{download('nexus-recovery-recipe.json',JSON.stringify(recipe(),null,2),'application/json');el('runStatus').textContent='Recovery recipe exported. This does not start training.';}catch(e){error('runStatus',e.message);}};
el('startGPUCompress').onclick=async()=>{
  const button=el('startGPUCompress'),status=el('compressionStatus');
  status.textContent='Requesting Python compression using the Stage 5 source and destination paths…';button.disabled=true;
  try{
    const payload={q8_gguf:get('q8Path'),output_gguf:get('factorPath'),
      weights_bpw:number('optBpw'),embeddings_bpw:number('optEmbedBpw'),
      residual:el('optRes').checked,split:number('optSplit'),
      als:number('optAls'),power:number('optPow'),itq:number('optItq'),
      edge:number('optEdge'),kv:number('optKv'),seed:number('optSeed'),
      device:get('compressionDevice')};
    if(!payload.q8_gguf||!payload.output_gguf)throw Error('Enter the source Q8 and destination factor file paths in Stage 5. The browser file picker does not fill Python paths.');
    const r=await api('/api/compress',payload);
    el('runStatus').textContent=`Full PyTorch compression started (PID ${r.pid}), output: ${r.output_gguf}`;
    status.textContent=el('runStatus').textContent;await poll();
  }catch(e){status.textContent='Compression failed: '+e.message;error('runStatus',e.message);}finally{button.disabled=false;}
};
el('startCorpus').onclick=async()=>{
 const status=el('corpusBuildStatus'),button=el('startCorpus');
 if(!localHost){status.textContent='The included 10M-token corpus is already ready for browser recovery. This custom rebuild requires the optional Python launcher (python launch.py). Open Nexus_Web_LLM.html and click Recovery to use the included corpus.';return;}
 button.disabled=true;status.textContent='Requesting a custom corpus build from the local Python service…';
 try{let r=await api('/api/corpus',corpusRecipe());status.textContent=`Corpus build started (PID ${r.pid}). Follow live progress below; the manifest is written on completion.`;el('runStatus').textContent=status.textContent;await poll();}
 catch(e){status.textContent='Corpus build failed: '+e.message;error('runStatus',e.message);}
 finally{button.disabled=false;}
};
el('startRecovery').onclick=async()=>{try{let r=await api('/api/recovery',recipe());el('runStatus').textContent=`Recovery training started locally (PID ${r.pid}). Checkpoints and metrics will appear below.`;await poll();}catch(e){error('runStatus',e.message);}};
for(const id of ['stopCorpus','stopRecovery'])el(id).onclick=async()=>{try{let r=await api('/api/stop',{});el('runStatus').textContent=r.message;}catch(e){error('runStatus',e.message);}};
let lastSnapshot='';
const fmtPpl=p=>Number.isFinite(p?.ppl)?p.ppl.toFixed(3):Number.isFinite(p?.nll)?'overflow (NLL '+p.nll.toFixed(3)+')':'pending';
async function poll(){
  if(!localHost)return;
  try{
    const data=await api('/api/status');
    const ev=(data.last_events||[]).slice(-12);
    const lines=ev.map(d=>{
      if(d.event==='log')return d.message;
      if(d.event==='progress')return `stage ${d.stage}/5 | ${Number(d.exposures).toLocaleString()} exposures | loss ${Number(d.loss).toFixed(4)} | reuse ${d.reuse}x`;
      if(d.event==='baseline')return `Held-out original Q8 PPL ${fmtPpl(d.baseline)}, compressed pre PPL ${fmtPpl(d.pre)}`;
      if(d.event==='complete')return `Complete: original PPL ${fmtPpl(d.baseline)}, pre ${fmtPpl(d.pre)}, post ${fmtPpl(d.post)}`;
      return `${d.event||'log'} ${d.message||d.path||d.stage||''}`;
    });
    const serialized=lines.join('\n');if(serialized!==lastSnapshot){el('localLog').textContent=serialized;lastSnapshot=serialized;}
    const baseline=(data.last_events||[]).findLast(x=>x.event==='baseline');
    if(baseline)renderPPL(baseline.baseline,baseline.pre,null);
    if(data.report){reportCache=data.report;renderPPL(data.report.original_baseline,data.report.pre,data.report.post);}
    if(data.compress_report)el('accelStatus').textContent='PyTorch compression complete: '+data.compress_report.matrix_count+' matrices, achieved '+data.compress_report.packed_bpw.toFixed(4)+' BPW, backend '+data.compress_report.backend+'. File SHA256 '+data.compress_report.file_sha256;
    if(data.job){
      if(String(data.job).toLowerCase().includes('compress'))el('compressionStatus').textContent=(data.active?'Python compression running':data.returncode===0?'Python compression finished':'Python compression stopped or failed')+(lines.length?' · '+lines[lines.length-1]:'');
      if(String(data.job).toLowerCase().includes('corpus'))el('corpusBuildStatus').textContent=(data.active?'Corpus build running':data.returncode===0?'Corpus build finished':'Corpus build stopped or failed')+(lines.length?' · '+lines[lines.length-1]:'');
      const done=data.returncode!==null;
      el('runStatus').textContent=(data.active?'Running':done?(data.returncode===0?'Job finished':'Job failed'):'Idle')+
        ` · ${data.job} · PID ${data.pid||'—'} · ${data.run_folder||''}`;
    }
  }catch(e){error('runStatus',e.message);}
}
if(localHost){poll();setInterval(poll,1700);}
el('checkTorch').onclick=async()=>{try{
  el('accelStatus').textContent='Checking real PyTorch backend and matrix multiplication…';
  const d=await api('/api/hardware');
  el('accelStatus').textContent=`PyTorch ${d.torch_version}; backend ${d.backend}; ${d.gpu_name||'No PyTorch GPU'}; `+
    `training GPU ${d.gpu_matmul_ok?'verified by matmul':'NOT verified'}; ${d.detail||''}`;
}catch(e){error('accelStatus',e.message);}};
el('checkWebGPU').onclick=async()=>{
 try{
   if(!navigator.gpu)throw Error('navigator.gpu unavailable. Use Edge/Chrome on localhost, with WebGPU enabled.');
   const adapter=await navigator.gpu.requestAdapter({powerPreference:'high-performance'});
   if(!adapter)throw Error('WebGPU adapter was not granted');
   const device=await adapter.requestDevice();
   const shader=device.createShaderModule({code:`@group(0) @binding(0) var<storage,read_write> a:array<f32>;
     @compute @workgroup_size(1) fn main(){a[0]=a[0]*a[0]+1.0;}`});
   const pipeline=device.createComputePipeline({layout:'auto',compute:{module:shader,entryPoint:'main'}});
   const B=GPUBufferUsage,buf=device.createBuffer({size:4,usage:B.STORAGE|B.COPY_SRC|B.COPY_DST});
   const read=device.createBuffer({size:4,usage:B.MAP_READ|B.COPY_DST});
   device.queue.writeBuffer(buf,0,new Float32Array([3]));
   const bind=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:buf}}]});
   const encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bind);pass.dispatchWorkgroups(1);pass.end();
   encoder.copyBufferToBuffer(buf,0,read,0,4);device.queue.submit([encoder.finish()]);
   await read.mapAsync(GPUMapMode.READ);const value=new Float32Array(read.getMappedRange())[0];read.unmap();buf.destroy();read.destroy();device.destroy();
   if(Math.abs(value-10)>1e-5)throw Error('WebGPU compute output mismatch '+value);
   el('accelStatus').textContent=`WebGPU compute verified (3×3+1 = ${value}). Browser matrix SVD kernels available. This does not establish Radeon-specific timing; ALS remains CPU.`;
 }catch(e){error('accelStatus',e.message);}
};
el('headerCompress').onclick=async()=>{
 try{
   const selected=window.__littlebitHeader;
   if(!selected||!selected.file||!selected.model)throw Error('Load a Q8 GGUF before exporting header');
   if(typeof CompressionStream!=='function')throw Error('Browser CompressionStream GZIP is unavailable');
   const n=selected.model.dataStart;
   const compressed=await new Response(selected.file.slice(0,n).stream().pipeThrough(new CompressionStream('gzip'))).blob();
   const bpw=compressed.size*8/n,target=number('optHeaderBpw');
   download('nexus-gguf-header.lossless.gz',compressed);
   el('headerStatus').textContent=`Lossless GZIP header: ${n.toLocaleString()} bytes → ${compressed.size.toLocaleString()} bytes; actual ${bpw.toFixed(3)} bits per original byte, `+
       `target ${target}. ${bpw<=target?'Target met.':'Target NOT met; lossless contents retained.'} `+
       `This is a sidecar only; the GGUF metadata remains intact for tokenizer/loader compatibility.`;
 }catch(e){error('headerStatus',e.message);}
};
window.nexusRecoveryStudio={recipe,corpusRecipe,renderPPL,updateBudget};
})();
