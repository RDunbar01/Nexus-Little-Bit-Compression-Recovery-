"""NEXUS LittleBit PyTorch factor converter.

Full local PyTorch compute (randomized SVD, residual, alternating least-squares)
uses the selected torch device, including ROCm/HIP RX 7900 XT through torch.cuda.
The binary factors are an initialization; recovery.py performs 5-stage QAT.
Produces the *same* signed 1-bit packed GGUF layout as the browser builder.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import tempfile
import time

import numpy as np
import torch
from gguf_factors import GGUF, sha256_file

LINEAR=re.compile(r'^blk\.(\d+)\.(attn_q|attn_k|attn_v|attn_output|ffn_gate|ffn_up|ffn_down)\.weight$')
EMBED={'token_embd.weight','output.weight'}


def event(kind,**kwargs):
    print(json.dumps({'event':kind,**kwargs},allow_nan=False),flush=True)


def dims_rank_plan(gg, weights_bpw, embedding_bpw, residual=True, split=.5, edge=1., kv=1.):
    groups={'projection':[],'embedding':[]}
    for t in gg.tensors.values():
        if t.type !=8 or len(t.shape)!=2:continue
        ma=LINEAR.match(t.name)
        if ma: key='projection'
        elif t.name in EMBED:key='embedding'
        else:continue
        m,n=t.shape
        if n % 8 or min(m,n)<8:continue
        boost=1.
        if ma:
            blocks=int(gg.metadata.get('llama.block_count',1))
            if int(ma.group(1)) in (0,blocks-1):boost*=edge
            if ma.group(2) in ('attn_k','attn_v'):boost*=kv
        groups[key].append({'name':t.name,'m':m,'n':n,'weight':boost})
    if not groups['projection']:raise ValueError('No eligible Q8 projection tensors in source GGUF')
    all_items=[];by_group={}
    for label, target in [('projection',weights_bpw),('embedding',embedding_bpw)]:
        group=groups[label]
        if not group:continue
        if not .1 <=target<=4.:raise ValueError('BPW target must be in [0.1,4]')
        def assign(beta):
            total=0
            for t in group:
                m,n=t['m'],t['n']; maxr=(min(m,n)//8)*8
                fixed=(32 if residual else 16)*(m+n)
                rho=max(0.,(target*m*n-fixed)/(m+n+16))
                requested=beta*t['weight']*rho
                a=requested*(1-split if residual else 1.)
                b=requested*split if residual else 0.
                t['r1']=max(8,min(maxr,int(a//8)*8))
                t['r2']=max(8,min(maxr,int(b//8)*8)) if residual else 0
                t['bits']=t['r1']*(m+n+16)+16*(m+n)
                if residual:t['bits']+=t['r2']*(m+n+16)+16*(m+n)
                total+=t['bits']
            return total
        total_weights=sum(t['m']*t['n'] for t in group)
        minimum=assign(0)/total_weights
        if minimum>target+1e-12:
            raise ValueError(f'{label} target {target:.4f} infeasible; packed 8-rank + FP16 scales require ≥{minimum:.4f} BPW')
        lo,hi=0.,8.
        for _ in range(48):
            mid=(lo+hi)*.5
            if assign(mid)<=target*total_weights:lo=mid
            else:hi=mid
        actual=assign(lo)/total_weights
        by_group[label]={'target_bpw':target,'actual_bpw':actual,'minimum_bpw':minimum,'matrix_count':len(group),'weights':total_weights}
        all_items.extend(group)
    return all_items,by_group


def orthogonal_initialization(W,rank,power=2,itq=0,return_magnitudes=False):
    q=min(min(W.shape),rank+8)
    # torch.svd_lowrank runs the randomized range search, QR and SVD on selected device.
    u,s,v=torch.svd_lowrank(W,q=q,niter=power)
    root=s[:rank].clamp(min=0).sqrt()
    a=u[:,:rank]*root[None,:];b=v[:,:rank]*root[None,:]
    if itq:
        x=torch.cat([a,b],0)
        rot=torch.eye(rank,device=W.device,dtype=torch.float32)
        for _ in range(itq):
            signs=torch.where(x@rot>=0,1.,-1.)
            su,ss,sv=torch.linalg.svd(x.T@signs,full_matrices=False)
            rot=su@sv
        a=a@rot;b=b@rot
    if return_magnitudes:return a,b
    return torch.where(a>=0,1.,-1.),torch.where(b.T>=0,1.,-1.)


def dual_svid(W, rank, power=2, itq=0):
    """Paper Eqs. 6–8: independent rank-one SVD of both factor magnitudes."""
    a,b=orthogonal_initialization(W,rank,power,itq,return_magnitudes=True)
    def magnitude_scales(x):
        u,s,vh=torch.linalg.svd(x.abs(),full_matrices=False)
        root=s[0].clamp(min=0).sqrt()
        # Magnitude matrices have a nonnegative leading singular pair.
        return u[:,0].abs()*root,vh[0].abs()*root
    h,lu=magnitude_scales(a);g,lv=magnitude_scales(b)
    return (torch.where(a>=0,1.,-1.),torch.where(b.T>=0,1.,-1.),h,g,lu*lv)


def reconstruct(p):
    u,v,h,g,l=p
    return ((u*(h[:,None]*l[None,:]))@v)*g[None,:]


def fit_path(W,u,v,iterations,initial=None):
    eps=1e-12
    m,n=W.shape
    h=W.square().mean(dim=1).sqrt().clamp(min=1e-6)
    g=torch.ones(n,device=W.device)
    l=torch.ones(u.shape[1],device=W.device)
    if initial is not None:
        h,g,l=(x.clone() for x in initial)
    for iteration in range(iterations+1):
        if iterations==0:break
        # Exact least-squares latent scale from the normal equations.
        H=h[:,None]*u;G=v*g[None,:]
        gram=(H.T@H)*(G@G.T)
        rhs=torch.diagonal(H.T@W@G.T)
        reg=torch.eye(l.numel(),device=W.device)*max(1e-6,float(torch.diagonal(gram).abs().mean().item())*1e-5)
        l=torch.linalg.solve(gram+reg,rhs)
        if iteration>=iterations:break
        z=(u*l[None,:])@v*g[None,:]
        h=(W*z).sum(1)/z.square().sum(1).clamp(min=eps)
        z=(u*(h[:,None]*l[None,:]))@v
        g=(W*z).sum(0)/z.square().sum(0).clamp(min=eps)
    # Resolve scale invariance to keep FP16 factors in range.
    sh=h.abs().mean().clamp(min=eps); h=h/sh; l=l*sh
    sg=g.abs().mean().clamp(min=eps);g=g/sg;l=l*sg
    if iterations==0:
        scales=(h,g,l)
        if not all(bool(torch.isfinite(x).all()) and bool((x.abs()<=65504).all()) for x in scales):
            raise FloatingPointError("Dual-SVID scales outside FP16 range")
        return u,v,h.half().float(),g.half().float(),l.half().float()
    # Re-estimate l after balancing h/g.
    H=h[:,None]*u;G=v*g[None,:]
    gram=(H.T@H)*(G@G.T)
    rhs=torch.diagonal(H.T@W@G.T)
    reg=torch.eye(l.numel(),device=W.device)*max(1e-6,float(torch.diagonal(gram).abs().mean().item())*1e-5)
    l=torch.linalg.solve(gram+reg,rhs)
    scales=(h,g,l)
    if not all(bool(torch.isfinite(x).all().item()) and bool((x.abs()<=65504).all().item()) for x in scales):
        raise FloatingPointError('Fitted FP16 scale not finite/range-safe')
    # Quantized reconstruction quality includes FP16 rounding, not master values.
    return (u,v,h.half().float(),g.half().float(),l.half().float())


def compression_paths(W,r1,r2,power=2,als=8,itq=0):
    paths=[];residual=W
    for rank in [r1]+([r2] if r2 else []):
        u,v,h,g,l=dual_svid(residual,rank,power,itq)
        fitted=fit_path(residual,u,v,als,initial=(h,g,l))
        paths.append(fitted)
        residual=residual-reconstruct(fitted)
    return paths


def packed_path(p):
    u,v,h,g,l=p
    def pack(x):return np.packbits((x.detach().cpu().numpy()<0).astype(np.uint8),axis=1,bitorder='little').tobytes()
    return {'u':pack(u),'vt':pack(v),
            'h':h.detach().cpu().numpy().astype('<f2').tobytes(),
            'g':g.detach().cpu().numpy().astype('<f2').tobytes(),
            'l':l.detach().cpu().numpy().astype('<f2').tobytes()}


def meta(name,typ,value):
    b=name.encode('utf-8');raw=bytearray(struct.pack('<Q',len(b))+b+struct.pack('<I',typ))
    if typ==8:
        z=value.encode('utf8');raw+=struct.pack('<Q',len(z))+z
    elif typ==4:raw+=struct.pack('<I',value)
    elif typ==6:raw+=struct.pack('<f',value)
    elif typ==9:
        subtype,seq=value;raw+=struct.pack('<IQ',subtype,len(seq))
        for x in seq:
            if subtype==4:raw+=struct.pack('<I',x)
            elif subtype==8:
                z=x.encode('utf8');raw+=struct.pack('<Q',len(z))+z
            else:raise ValueError('Unknown array subtype')
    else:raise ValueError('Metadata type unsupported')
    return bytes(raw)


def make_gguf(gg,output,items,by_group,config,actual_measurements):
    entries=[];raw_factors={}
    for item in items:
        for i,p in enumerate(item['paths']):
            encoded=packed_path(p)
            m,n=item['m'],item['n'];r=item['r1'] if i==0 else item['r2']
            base=item['name'].replace('.weight','')+f'.lb{i}.'
            for suffix,shape,typ in [('u',(m,r//8),24),('vt',(r,n//8),24),
                                     ('h',(m,),1),('g',(n,),1),('l',(r,),1)]:
                key=base+suffix
                raw_factors[key]=encoded[suffix]
                if np.prod(shape)* (2 if typ==1 else 1)!=len(raw_factors[key]):
                    raise ValueError('Factor tensor data length inconsistent: '+key)
                entries.append({'name':key,'shape':shape,'type':typ,'payload':raw_factors[key]})
    chosen=set(t['name'] for t in items)
    for t in gg.tensors.values():
        if t.name not in chosen: entries.append({'name':t.name,'shape':t.shape,'type':t.type,'source':t})
    entries.sort(key=lambda e:e['name'])
    packed_bits=sum(t['bits'] for t in items)
    weights=sum(t['m']*t['n'] for t in items)
    orig_weights=sum(int(np.prod(t.shape)) for t in gg.tensors.values())
    actual=packed_bits/weights
    newmeta={
        'littlebit.version':(4,1),
        'littlebit.builder_version':(8,'nexus-torch-2.3'),
        'littlebit.role':(8,'littlebit-factors'),
        'littlebit.scheme':(8,'W=diag(h)@sign(U)@diag(l)@sign(V).T@diag(g), plus optional residual'),
        'littlebit.paths':(4,2 if config.residual else 1),
        'littlebit.target_bpw':(6,float(config.weights_bpw)),
        'littlebit.bpw':(6,float(actual)),
        'littlebit.bpw_file':(6,0.),
        'littlebit.init':(8,f'Dual-SVID magnitude rank-1 SVD; torch.svd_lowrank niter={config.power}; GPU ALS={config.als}; ITQ={config.itq}; no QAT'),
        'littlebit.recovery_training':(8,'none (post-training init only; paper uses QAT + distillation)'),
        'littlebit.seed':(4,int(config.seed)),
        'littlebit.tensors':(9,(8,[it['name'] for it in items])),
        'littlebit.rank':(9,(4,[it['r1'] for it in items])),
        'littlebit.rank_res':(9,(4,[it['r2'] for it in items])),
    }
    alignment=int(gg.metadata.get('general.alignment',32))
    def write_header():
        retained=[z for k,z in gg.raw_metadata if not k.startswith('littlebit.')]
        mts=[meta(k,t,v) for k,(t,v) in newmeta.items()]
        header=bytearray(b'GGUF'+struct.pack('<IQQ',3,len(entries),len(retained)+len(mts)))
        for x in retained+mts:header+=x
        off=0
        for e in entries:
            off=(-(-off//alignment))*alignment
            e['offset']=off
            e['nbytes']=len(e['payload']) if 'payload' in e else e['source'].nbytes
            off+=e['nbytes']
            name=e['name'].encode('utf8');dims=tuple(reversed(e['shape']))
            header+=struct.pack('<Q',len(name))+name+struct.pack('<I',len(dims))
            for dim in dims:header+=struct.pack('<Q',dim)
            header+=struct.pack('<IQ',e['type'],e['offset'])
        header+=b'\0'*((-len(header))%alignment)
        return header,off
    header,payload_size=write_header()
    final_bytes=len(header)+payload_size
    newmeta['littlebit.bpw_file']=(6,float(8*final_bytes/orig_weights))
    header,payload_size=write_header()
    output=Path(output).expanduser().resolve()
    if output==gg.path:raise ValueError('Refusing to overwrite original model')
    output.parent.mkdir(parents=True,exist_ok=True)
    tmp=output.with_suffix(output.suffix+'.partial')
    try:
        with tmp.open('wb') as f:
            f.write(header)
            at=0
            for e in entries:
                if e['offset']>at:f.write(b'\0'*(e['offset']-at))
                if 'payload' in e:f.write(e['payload'])
                else:
                    source=e['source']
                    gg.file.seek(gg.data_start+source.offset)
                    remaining=source.nbytes
                    while remaining:
                        block=gg.file.read(min(4*1024*1024,remaining))
                        if not block:raise ValueError('Source GGUF truncated during copy')
                        f.write(block);remaining-=len(block)
                at=e['offset']+e['nbytes']
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,output)
    finally:tmp.unlink(missing_ok=True)
    return {'output':str(output),'file_sha256':sha256_file(output),
            'packed_bpw':actual,'whole_file_bpw':8*output.stat().st_size/orig_weights,
            'matrix_count':len(items),'weights_converted':weights,'source_weights':orig_weights,
            'by_group':by_group,'matrix_errors':actual_measurements,'source_sha256':sha256_file(gg.path),
            'algorithm':'Dual-SVID + binary residual compensation + optional GPU ALS; QAT recovery not yet performed',
            'backend':config.device_selected}


def run(args):
    if not (.0<args.split<1.) or not .1<=args.weights_bpw<=4 or not .1<=args.embeddings_bpw<=4:
        raise ValueError('Invalid compression fractions or BPW target')
    if args.als<0 or args.als>50 or args.power<0 or args.power>6 or args.itq<0 or args.itq>50:
        raise ValueError('Refinement parameters out of range')
    if args.device=='auto':device='cuda' if torch.cuda.is_available() else 'cpu'
    else:device=args.device
    if device=='cuda':
        if not torch.cuda.is_available():raise RuntimeError('ROCm/CUDA GPU unavailable in this PyTorch environment')
        x=torch.arange(1024,device='cuda',dtype=torch.float32).reshape(32,32)
        y=x@x.T;torch.cuda.synchronize()
        if not torch.isfinite(y).all().item():raise RuntimeError('GPU compute failed')
    if device not in ('cpu','cuda'):raise ValueError('device must be cpu,cuda,auto')
    args.device_selected=('ROCm/HIP ' if torch.version.hip else 'CUDA ') + torch.cuda.get_device_name(0) if device=='cuda' else 'CPU'
    torch.manual_seed(args.seed)
    t0=time.monotonic()
    with GGUF(args.q8_gguf) as gg:
        if gg.metadata.get('general.architecture')!='llama':raise ValueError('Expected Llama/SmolLM2 GGUF')
        items,by_group=dims_rank_plan(gg,args.weights_bpw,args.embeddings_bpw,args.residual,args.split,args.edge,args.kv)
        event('compression_start',device=args.device_selected,matrix_count=len(items),rank_bpw=by_group)
        results=[]
        with torch.no_grad():
            for i,it in enumerate(items,1):
                start=time.monotonic()
                W=torch.from_numpy(gg.array(it['name'])).to(device=device,dtype=torch.float32)
                paths=compression_paths(W,it['r1'],it['r2'],args.power,args.als,args.itq)
                reconstructed=sum((reconstruct(p) for p in paths))
                error=float(torch.linalg.vector_norm(W-reconstructed)/torch.linalg.vector_norm(W).clamp(min=1e-9))
                if not math.isfinite(error):raise FloatingPointError('Matrix reconstruction error not finite')
                it['paths']=paths
                result={'name':it['name'],'m':it['m'],'n':it['n'],'ranks':[it['r1'],it['r2']],
                        'bpw':it['bits']/(it['m']*it['n']),'relative_rmse':error,
                        'seconds':round(time.monotonic()-start,3)}
                results.append(result);event('tensor',done=i,total=len(items),**result)
                del W,reconstructed
                # Keep only CPU copies of factors between GPU tensors to bound VRAM usage.
                it['paths']=[tuple(t.detach().cpu() for t in path) for path in paths]
                del paths
        report=make_gguf(gg,args.output,items,by_group,args,results)
        report['seconds']=round(time.monotonic()-t0,3)
        report['torch_version']=torch.__version__
        report['hip_version']=torch.version.hip
        Path(args.output+'.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        event('compression_complete',report=str(args.output)+'.json',output=report['output'],sha256=report['file_sha256'],seconds=report['seconds'])
        return report

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='GPU-local LittleBit factorization via PyTorch ROCm/CUDA')
    ap.add_argument('--q8-gguf',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--weights-bpw',type=float,default=.5);ap.add_argument('--embeddings-bpw',type=float,default=2.)
    ap.add_argument('--device',choices=['cuda','cpu','auto'],default='cuda')
    ap.add_argument('--residual',dest='residual',action='store_true',default=True)
    ap.add_argument('--no-residual',dest='residual',action='store_false')
    ap.add_argument('--split',type=float,default=.5);ap.add_argument('--als',type=int,default=0)
    ap.add_argument('--power',type=int,default=2);ap.add_argument('--itq',type=int,default=0)
    ap.add_argument('--edge',type=float,default=1.);ap.add_argument('--kv',type=float,default=1.)
    ap.add_argument('--seed',type=int,default=20261007)
    a=ap.parse_args()
    try:run(a)
    except Exception as exc:
        event('error',message=f'{type(exc).__name__}: {exc}')
        raise
