# NEXUS LittleBit Recovery Studio — embedded corpus edition

Updated 7 October 2026. Includes a real, tokenizer-compiled recovery corpus inside the HTML. This is an experimental compression/recovery application, not an already-recovered SmolLM2 checkpoint.

## What changed

- **10,000,000 curriculum tokens are physically embedded in the HTML**, compressed as a ZIP and Base64 payload. They are not placeholder text, a word-count estimate, generated filler, or a remote download link.
- The corpus comprises **8,000,000 newly selected source-token positions plus 2,000,000 replay positions**. WikiText-2 contributes a separate **32,768-token validation stream**. Token counts use the actual SmolLM2-135M-Instruct tokenizer.
- Corrected PyTorch initialization to use **Dual-SVID**: truncated SVD, independent rank-one magnitude decomposition of both factors, and the product of their latent magnitude scales. The second path is initialized on the primary reconstruction residual.
- Defaults disable optional ALS, ITQ rotation and back-fitting, preserving the paper's initialization more closely. These remain optional extensions. Browser and PyTorch use different numerical SVD implementations and need not produce identical factors.
- Added **cosine learning-rate decay with 2% token-progress warm-up**. Schedule selection is recorded and checked on exact resume. Choose Constant for a legacy constant-LR checkpoint.
- Fixed the corpus source selection so **FineMath and InfiMM-WebMath each receive a quota**; grouping both into one bucket could previously allow one source to satisfy the entire mathematics quota.
- Recovery now checks the corpus tokenizer checksum against the local model tokenizer before training.
- Added checksum-verified corpus export, provenance display, and a first-launch Python extractor that refuses to overwrite different existing corpus files.

## Use the HTML

Open `NEXUS_LittleBit_Recovery_Studio.html` in Edge or Chrome. The standalone file supports browser factor compression, corpus ZIP export and provenance inspection. It contains approximately 18.3 MB of HTML and compressed corpus data; it does not include model weights.

Click **Export included corpus ZIP** to obtain the six token streams and `manifest.json`. There is no need to build/download the corpus again. It is stored as little-endian uint32 tokenizer IDs, not plain-text training documents.

**Full recovery and perplexity evaluation still run in the included local PyTorch program.** Embedding the corpus does not implement an in-browser transformer trainer. No hosted inference/training service is required.

## Run recovery

1. Extract the application ZIP.
2. Install a PyTorch build compatible with your device. For AMD/Radeon, use the current [AMD ROCm instructions and compatibility matrix](https://rocm.docs.amd.com/projects/radeon-ryzen/en/latest/docs/compatibility/compatibilityrad/wsl/wsl_compatibility.html). A generic CPU wheel will not accelerate the Radeon. Then install `requirements.txt` in the same Python environment.
3. Obtain a local `HuggingFaceTB/SmolLM2-135M-Instruct` model and tokenizer snapshot. The corpus tokenizer comes from revision `12fd25f77366fa6b3b4b768ec3050bf629380bac`; use that revision or an identical `tokenizer.json`:

   ```sh
   hf download HuggingFaceTB/SmolLM2-135M-Instruct --revision 12fd25f77366fa6b3b4b768ec3050bf629380bac --local-dir models/SmolLM2-135M-Instruct
   ```

4. Supply a Q8_0 GGUF derived from this same Instruct model. Do not mix base and Instruct weights. Create it using a compatible llama.cpp conversion/quantization tool if necessary.
5. Run `python launch.py` from the extracted application directory. The launcher extracts the included corpus to `corpus/` and verifies archive/file checksums. It opens `http://127.0.0.1:8765`.
6. Check model paths, run compression, then start a new recovery run. The default corpus and exposure budgets are already 10M. **Do not click Build and tokenize corpus unless you want to create a different corpus in another directory.**

The launcher needs Python; the full training backend additionally needs the model, tokenizer and dependencies. None of those are embedded in the HTML.

Manual corpus extraction without starting the server:

```sh
python embedded_corpus.py NEXUS_LittleBit_Recovery_Studio.html --output corpus
```

Use **Exact resume** with the original run folder, unchanged settings and its checkpoint. Use **Another recovery cycle** with a new output folder to continue from trained factors with a fresh optimizer. Recovery supports up to 100,000 million = 100 billion token exposures; higher budgets recycle the included corpus and do not add new source material.

## Included curriculum

| Stage | Token positions | Sources |
|---|---:|---|
| General language | 2,000,000 | 1.2M DCLM-Edu + 0.8M FineWeb-Edu |
| Structured text and code | 2,000,000 | 1M Cosmopedia V2 + 1M Stack-Edu |
| Mathematics | 2,000,000 | 1M FineMath + 1M InfiMM-WebMath |
| Instruction recovery | 2,000,000 | Smol-SmolTalk with official tokenizer chat formatting |
| Consolidation | 2,000,000 | Equal token replay from stages 1–4 |
| Separate validation | 32,768 | WikiText-2 raw validation |

Stages 1–3 use `EleutherAI/SmolLM2-135M-10B`, which samples the actual 135M pretraining mixture. Stage 4 uses **Smol-SmolTalk**, the small-model SmolTalk subset linked by the 135M-Instruct model card. It does not reproduce preference optimization/DPO. The stage balances are custom recovery choices.

The bundled selection uses 5,747 pretraining documents and 2,108 instruction conversations. Exact normalized-document duplicates were filtered during selection. Validation records matching selected training documents were excluded; near-duplicate/substring contamination was not audited. Final documents may be truncated to meet exact quotas. No claim is made that token strings are individually unique.

`manifest.json` records source revisions, source counts, file checksums and tokenizer checksum. Source dataset terms remain applicable; this package does not relicense the underlying material. See the source cards below.

## Relation to LittleBit

Implemented components: dual binary factor paths; row, column and latent FP16 scales; Dual-SVID initialization; residual compensation; SmoothSign surrogate gradients with k=100; Adam; cosine schedule and 2% warm-up; output distillation and hidden-state alignment.

**Remaining differences from the paper:** Q8 teacher instead of the original full-precision teacher; SmolLM2-135M rather than the paper's evaluated model sizes; the custom five-stage source curriculum instead of five epochs on WikiText-2/C4; short configurable sequence lengths (default 128, paper 2048); normalized hidden MSE at selected layers; additional next-token CE in stages 3–5; optional embedding/head factorization and optional initializer refinements. The hidden-loss weight is 10, but that does not make the normalized loss equivalent to the paper's raw MSE.

This is closer procedural alignment, **not a faithful reproduction or a claim of the paper's quality results**. A 0.1 BPW target can be infeasible at small dimensions because of mandatory rank/scale overhead. Whole-file BPW includes other tensors and metadata and differs from projection BPW. Mandatory GGUF metadata remains lossless. Packed factor GGUFs require the matching custom runtime and do not run directly in unmodified llama.cpp.

## Validation

The executable test suite covers synthetic tiny-model QAT, exact checkpoint resume and repeated recovery cycles, factor packing/loading, infeasible BPW rejection, GPU-required failure behavior, mathematical Dual-SVID initialization, residual targets, actual embedded corpus integrity and vocabulary/count checks, and refusing destructive corpus replacement.

```sh
PYTHONPATH=. python -m pytest -q tests/test_recovery_end_to_end.py tests/test_gpu_converter.py tests/test_source_recipe.py tests/test_embedded_and_dualsvid.py
```

**15/15 Python tests passed.** JavaScript syntax and jsdom interaction checks also passed for the recovery recipe, 100-billion exposure setting, provenance display, corpus export and archive SHA-256. jsdom is not a real browser. The results are recorded in `validation-results.txt`. Browser interaction tests are included, but Chromium launch was blocked in the build environment by its socket restrictions; those tests did not reach the application. Run them on a machine with Chromium:

```sh
NEXUS_TEST_BROWSER=1 CHROMIUM_PATH=/path/to/chromium PYTHONPATH=. python -m pytest -q tests/test_browser_integration.py
```

**Not measured:** full SmolLM2-135M recovery, real-model perplexity improvement, RX 7900 XT throughput/VRAM use, or Radeon WebGPU correctness. Pre/post perplexity controls are implemented, but no real-model result is bundled or claimed. NEXUS OS scheduler integration and LoRA training are outside this update.

## Rebuilding the embedded corpus

The final corpus is already included. For audit/rebuild, `compile_embedded_corpus.py` accepts pinned Parquet shards, source API revision records and the model tokenizer; `embed_corpus.py` packages compiled `corpus/` streams into the HTML. `corpus_builder.py` remains available for streaming a new corpus from Hugging Face or importing local text. Compiling from Parquet also requires `pyarrow`, provided by the datasets dependency.

## Primary sources

- [LittleBit paper, method and training settings](https://arxiv.org/html/2506.13771v1)
- [Official LittleBit implementation](https://github.com/SamsungLabs/LittleBit)
- [EleutherAI SmolLM2-135M-10B](https://huggingface.co/datasets/EleutherAI/SmolLM2-135M-10B)
- [SmolLM2-135M-Instruct model card](https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct)
- [Smol-SmolTalk](https://huggingface.co/datasets/HuggingFaceTB/smol-smoltalk)
- [WikiText](https://huggingface.co/datasets/Salesforce/wikitext)
