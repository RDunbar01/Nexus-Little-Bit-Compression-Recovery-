/* Five-stage offline WebGPU recovery controller and portable checkpoints. */
(function(root){'use strict';
const el=id=>document.getElementById(id),log=msg=>{el('qatProgress').textContent=msg;el('qatLog').textContent=(el('qatLog').textContent+msg+'\n').split('\n').slice(-201).join('\n');el('qatLog').scrollTop=el('qatLog').scrollHeight;};
const hash=async data=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),x=>x.toString(16).padStart(2,'0')).join('');
const download=(name,parts,type='application/octet-stream')=>{const url=URL.createObjectURL(new Blob(parts,{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);};
let task=null,stop=false,training=false,corpus=null;
async function readCorpus(){
 if(corpus)return corpus;
 const node=el('nexus-corpus-payload');if(!node)throw Error('Embedded corpus missing');
 const raw=Uint8Array.from(atob(node.textContent.trim()),c=>c.charCodeAt(0));if(await hash(raw)!==node.dataset.sha256)throw Error('Corpus archive checksum failed');
 const v=new DataView(raw.buffer),out={};let pos=0;
 while(v.getUint32(pos,true)===0x04034b50){const method=v.getUint16(pos+8,true),packed=v.getUint32(pos+18,true),namelen=v.getUint16(pos+26,true),extra=v.getUint16(pos+28,true),name=new TextDecoder().decode(raw.subarray(pos+30,pos+30+namelen)),start=pos+30+namelen+extra;const bytes=raw.slice(start,start+packed);out[name]=method===0?bytes:new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());pos=start+packed;}
 const manifest=JSON.parse(new TextDecoder().decode(out['manifest.json']));
 for(const [name,digest] of Object.entries(manifest.sha256)){if(!out[name]||await hash(out[name])!==digest)throw Error('Corpus file checksum failed: '+name);}
 corpus={manifest,stages:[1,2,3,4,5].map(i=>new Uint32Array(out['stage'+i+'.tokens.bin'].buffer)),validation:new Uint32Array(out['validation.tokens.bin'].buffer)};return corpus;
}
async function parsed(file){if(!file)throw Error('Select both original Q8 GGUF and compressed LittleBit GGUF');const r=await new NormalGGUFReader(file).init(),base=await parseGGUF(r),em=await buildExecutionModel(r,base);return {file,r,em};}
function config(em){
 if(em.meta['general.architecture']!=='llama')throw Error('Browser QAT supports SmolLM2 Llama graphs');const m=em.meta,c={layers:+m['llama.block_count'],dim:+m['llama.embedding_length'],heads:+m['llama.attention.head_count'],kv:+m['llama.attention.head_count_kv'],eps:+m['llama.attention.layer_norm_rms_epsilon'],theta:+m['llama.rope.freq_base'],vocab:em.meta['tokenizer.ggml.tokens'].length};c.hd=c.dim/c.heads;
 if(c.heads%c.kv||c.hd%2||!Object.values(c).every(x=>Number.isFinite(x)&&x>0))throw Error('Invalid model configuration');
 if(c.dim!==576||c.layers!==30||c.vocab!==49152||c.heads!==9||c.kv!==3)throw Error('This browser recovery profile is validated for SmolLM2-135M dimensions only');
 if(m['llama.rope.scaling.type']&&!['none','linear'].includes(m['llama.rope.scaling.type']))throw Error('Training RoPE scaling unsupported');
 if(Number(m['llama.rope.scaling.factor']||1)!==1)throw Error('Scaled RoPE recovery is not supported');return c;
}
async function vocabHash(em){return hash(new TextEncoder().encode(JSON.stringify({tokens:em.meta['tokenizer.ggml.tokens'],merges:em.meta['tokenizer.ggml.merges'],pre:em.meta['tokenizer.ggml.pre']})));}
async function setup(){
 const device=NexusEngineAPI.getDevice();if(!device)throw Error('WebGPU is unavailable. Recovery requires a real WebGPU device.');
 // Release the interactive engine before allocating teacher + optimizer state.
 if(NexusEngineAPI.getEngine())throw Error('Reload the page before recovery to release the chat model. Choose recovery files without loading a chat model.');
 const checkpointFile=el('qatCheckpoint').files[0],mode=el('qatMode').value;
 if(checkpointFile&&mode==='new')throw Error('Choose resume/cycle when using a checkpoint');
 if(!checkpointFile&&mode!=='new')throw Error('Select a checkpoint for resume/cycle');
 const teacher=await parsed(el('qatTeacher').files[0]),student=await parsed(el('qatStudent').files[0]);
 if(!student.em.meta['littlebit.version'])throw Error('Student must be a packed LittleBit factor GGUF from the Studio');
 const cfg=config(teacher.em);if(JSON.stringify(config(student.em))!==JSON.stringify(cfg))throw Error('Teacher/student architecture mismatch');
 if(await vocabHash(teacher.em)!==await vocabHash(student.em))throw Error('Teacher/student tokenizers differ');
 const source={teacher:await hash(await teacher.file.arrayBuffer()),student:await hash(await student.file.arrayBuffer())};
 const c=await readCorpus();
 // Verify GGUF vocabulary against the exact tokenizer used to compile the corpus.
 const expected=JSON.parse(el('nexus-tokenizer-check').textContent);if(await hash(new TextEncoder().encode(JSON.stringify(teacher.em.meta['tokenizer.ggml.tokens'])))!==expected.vocabHash)throw Error('GGUF vocabulary does not match embedded SmolLM2 tokenizer');
 for(const t of teacher.em.list)if(t.dims.length===2&&t.qt!==8)throw Error('Teacher matrices must be Q8_0 for the Q8 baseline');
 const seq=+el('qatSeq').value,budget=Math.round(+el('qatBudget').value*1e6),lr=+el('qatLR').value;
 if(!Number.isInteger(seq)||seq<8||seq>256||!Number.isSafeInteger(budget)||budget<5*seq||budget>1e11||!(lr>0&&lr<=.001))throw Error('Invalid recovery settings');
 const memoryMiB=+el('qatMemory').value;if(!Number.isFinite(memoryMiB)||memoryMiB<512||memoryMiB>16384)throw Error('Training allocation ceiling outside 512..16384 MiB');
 const evalTokens=+el('qatEvalTokens').value;if(!Number.isInteger(evalTokens)||evalTokens<8||evalTokens>32768)throw Error('Evaluation token cap outside 8..32768');
 const g=await new NexusQAT.GPUAutograd(device).init();g.maxBytes=memoryMiB*1024**2;
 const settings={seq,budget,lr,evalTokens,schedule:'cosine',warmup:.02,hiddenWeight:10,corpus:el('nexus-corpus-payload').dataset.sha256};
 const teacherModel=new NexusQAT.SmolTrainingModel(g,cfg),studentModel=new NexusQAT.SmolTrainingModel(g,cfg);
 try{await teacherModel.load(teacher.em,teacher.r,false);await studentModel.load(student.em,student.r,true);}catch(e){teacherModel.destroy();studentModel.destroy();g.destroy();throw e;}
 task={g,cfg,teacher,student,teacherModel,studentModel,source,settings,stage:0,position:0,exposures:0,steps:0,pre:null,baseline:null,post:null,lineage:null};
 const file=el('qatCheckpoint').files[0];if(file){if(el('qatMode').value==='new')throw Error('Choose resume/cycle when using a checkpoint');try{await restore(file,el('qatMode').value==='cycle');}catch(e){teacherModel.destroy();studentModel.destroy();g.destroy();task=null;throw e;}}else if(el('qatMode').value!=='new')throw Error('Select a checkpoint for resume/cycle');
 return task;
}
async function metric(model,maxTokens){const t=task,g=t.g,data=corpus.validation;let total=0,count=0;const cap=Math.min(maxTokens,data.length-1);
 for(let pos=0;pos<cap;pos+=t.settings.seq){el('qatProgress').textContent='Evaluating '+(model===t.teacherModel?'original Q8':'compressed student')+' · '+pos+' / '+cap+' tokens';el('qatBar').value=100*pos/cap;if(stop)throw Error('Evaluation stopped');const n=Math.min(t.settings.seq,cap-pos),ids=g.tensor(data.subarray(pos,pos+n),[n]),labels=g.tensor(data.subarray(pos+1,pos+n+1),[n]);const r=model.forward(ids,false),loss=g.run('nll',r.logits,labels,null,[n],[n,t.cfg.vocab],[n]);for(const value of await g.read(loss)){total+=value;count++;}await g.clear();await new Promise(r=>setTimeout(r,0));}
 if(!Number.isFinite(total)||!count)throw Error('Nonfinite/empty perplexity result');const nll=total/count;return {nll,ppl:nll<700?Math.exp(nll):null,tokens:count,sequence:t.settings.seq};}
function showMetrics(){const values={originalQ8:task?.baseline,compressedPre:task?.pre,compressedPost:task?.post};el('qatMetrics').textContent=JSON.stringify(values,null,2);el('qatMetricCards').replaceChildren(...Object.entries(values).map(([key,value])=>{const box=document.createElement('div');box.className='qatMetric';const title=document.createElement('span');title.textContent={originalQ8:'Original Q8',compressedPre:'Before recovery',compressedPost:'After recovery'}[key];const number=document.createElement('strong');number.textContent=Number.isFinite(value?.ppl)?value.ppl.toFixed(2):value?'See metric details':'Pending';box.append(title,number);return box;}));}
function updateControls(){const ready=!!el('qatTeacher').files[0]&&!!el('qatStudent').files[0]&&(el('qatMode').value==='new'||!!el('qatCheckpoint').files[0]);el('qatStart').disabled=training||(!task&&!ready);el('qatStop').disabled=!training;el('qatSave').disabled=el('qatExport').disabled=training||!task;for(const id of ['qatTeacher','qatStudent','qatCheckpoint','qatMode','qatBudget','qatSeq','qatLR','qatEvalTokens'])el(id).disabled=training||!!task;el('qatMemory').disabled=training;el('qatReset').disabled=training||!task;if(!task&&!training)el('qatProgress').textContent=ready?'Ready. Click Start recovery.':'Choose both model files'+(el('qatMode').value==='new'?'.':' and a checkpoint.');}
for(const id of ['qatTeacher','qatStudent','qatCheckpoint','qatMode'])el(id).addEventListener('change',updateControls);
showMetrics();updateControls();

function memoryStatus(){if(task)el('qatMemoryStatus').textContent='GPU tensor allocations: '+Math.ceil(task.g.memory/1048576)+' MiB · peak '+Math.ceil(task.g.peak/1048576)+' MiB · ceiling '+Math.round(task.g.maxBytes/1048576)+' MiB (excludes browser/driver overhead)';}
async function batch(){const t=task,g=t.g,c=corpus,stageBudget=Math.floor(t.settings.budget/5)+(t.stage<t.settings.budget%5?1:0);const length=Math.min(t.settings.seq,stageBudget-t.position),arr=c.stages[t.stage],start=t.position%(arr.length-length);const ids=g.tensor(arr.subarray(start,start+length),[length]),labels=g.tensor(arr.subarray(start+1,start+length+1),[length]);
 const teacher=t.teacherModel.forward(ids,false);await g.retain([ids,labels,teacher.logits,...teacher.hidden]);const student=t.studentModel.forward(ids,true),V=t.cfg.vocab,ps=g.softmax(student.logits,length,V);g.record=false;const pt=g.softmax(teacher.logits,length,V),ce=t.stage>=2?.2:0;
 const grad=g.run('logitgrad',ps,pt,labels,student.logits.shape,[length*V,V,NexusQAT.bits(ce),length]);const seeds=[[student.logits,grad]];
 const selected=[Math.max(0,Math.floor(t.cfg.layers/4)-1),Math.floor(t.cfg.layers/2)-1,t.cfg.layers-1];
 for(const i of selected){const a=student.hidden[i],b=teacher.hidden[i],sq=g.reduce(b,true),energy=(await g.read(sq))[0]/b.n,scale=20/(selected.length*a.n*Math.max(1e-4,energy));seeds.push([a,g.run('msegrad',a,b,null,a.shape,[a.n,NexusQAT.bits(scale)])]);}
 g.backward(seeds);const warm=Math.max(1,t.settings.budget*.02),progress=Math.max(0,(t.exposures-warm)/(t.settings.budget-warm)),factor=t.exposures<warm?Math.min(1,(t.exposures+length)/warm):.5*(1+Math.cos(Math.PI*progress));const nlls=await g.read(g.run('nll',student.logits,labels,null,[length],[length,V],[length]));const nll=nlls.reduce((a,b)=>a+b,0)/length;if(!Number.isFinite(nll))throw Error('Nonfinite model loss: update aborted');const gradNorm=await g.step(t.settings.lr*factor,t.steps+1);
 t.position+=length;t.exposures+=length;t.steps++;if(t.position===stageBudget){t.stage++;t.position=0;}
 await g.clear();memoryStatus();return {nll,gradNorm};
}
async function checkpoint(){if(!task)throw Error('No recovery state');const t=task,g=t.g,parts=[],entries=[];let offset=0;
 for(const p of g.params){const record={name:p.name,shape:p.shape,offset,n:p.n};for(const tensor of [p,p.m,p.v]){const data=await g.read(tensor);parts.push(data);offset+=data.byteLength;}entries.push(record);}
 const header={format:'NEXUS-WebGPU-QAT-1',source:t.source,settings:t.settings,stage:t.stage,position:t.position,exposures:t.exposures,steps:t.steps,baseline:t.baseline,pre:t.pre,post:t.post,lineage:t.lineage,entries};const bytes=new TextEncoder().encode(JSON.stringify(header)),prefix=new Uint8Array(12);prefix.set(new TextEncoder().encode('NQAT0001'));new DataView(prefix.buffer).setUint32(8,bytes.length,true);download('NEXUS-WebGPU-Recovery-'+t.exposures+'.nqat',[prefix,bytes,...parts]);return header;}
async function restore(file,cycle){const raw=await file.arrayBuffer(),v=new DataView(raw),n=v.getUint32(8,true),h=JSON.parse(new TextDecoder().decode(new Uint8Array(raw,12,n)));if(new TextDecoder().decode(new Uint8Array(raw,0,8))!=='NQAT0001'||h.format!=='NEXUS-WebGPU-QAT-1')throw Error('Invalid browser checkpoint');
 const t=task;if(JSON.stringify(h.source)!==JSON.stringify(t.source))throw Error('Checkpoint teacher/student hashes differ');if(!cycle&&JSON.stringify(h.settings)!==JSON.stringify(t.settings))throw Error('Exact resume settings differ');if(h.settings.corpus!==t.settings.corpus)throw Error('Checkpoint corpus differs');if(h.entries.length!==t.g.params.length)throw Error('Checkpoint parameter count differs');
 const writes=[];let expectedOffset=0;
 for(let i=0;i<h.entries.length;i++){const e=h.entries[i],p=t.g.params[i];if(e.name!==p.name||e.n!==p.n||JSON.stringify(e.shape)!==JSON.stringify(p.shape)||e.offset!==expectedOffset)throw Error('Checkpoint tensor mismatch');let off=12+n+e.offset;
 for(const tensor of [p,p.m,p.v]){const data=new Uint8Array(raw,off,p.n*4);const floats=new Float32Array(data.slice().buffer);if(!floats.every(Number.isFinite))throw Error('Checkpoint has nonfinite values');if(tensor===p.v&&floats.some(x=>x<0))throw Error('Checkpoint has invalid variance');if(!cycle||tensor===p)writes.push([tensor,data]);off+=p.n*4;expectedOffset+=p.n*4;}}
 if(12+n+expectedOffset!==raw.byteLength)throw Error('Checkpoint length mismatch');
 if(![h.stage,h.position,h.steps,h.exposures].every(Number.isSafeInteger)||h.stage<0||h.stage>5||h.position<0||h.steps<0)throw Error('Invalid checkpoint progress');
 const budgets=Array.from({length:5},(_,i)=>Math.floor(h.settings.budget/5)+(i<h.settings.budget%5?1:0));
 if(h.exposures!==budgets.slice(0,h.stage).reduce((a,b)=>a+b,0)+h.position||(h.stage===5?h.position!==0:h.position>=budgets[h.stage]))throw Error('Checkpoint exposure/progress mismatch');
 for(const [tensor,data] of writes)t.g.d.queue.writeBuffer(tensor.buf,0,data);
 t.lineage={name:file.name,sha256:await hash(raw),cycle};if(!cycle){for(const k of ['stage','position','exposures','steps','baseline','pre','post'])t[k]=h[k];}}
function toHalf(value){const f=new Float32Array([value]),v=new Uint32Array(f.buffer)[0],sign=(v>>>16)&0x8000;let exp=((v>>>23)&255)-127+15,m=v&0x7fffff;if(!Number.isFinite(value)||Math.abs(value)>65504)throw Error('Scale cannot be exported to FP16');if(exp<=0){if(exp< -10)return sign;m|=0x800000;const shift=14-exp;return sign+((m+(1<<(shift-1))-1+((m>>shift)&1))>>shift);}const rounded=m+0xfff+((m>>13)&1);if(rounded&0x800000){exp++;m=0;}else m=rounded;return sign|(exp<<10)|(m>>13);}
function markRecovered(bytes){
 const c=new RC(bytes),chunks=[];c.bytes(4);const version=c.u32(),count=c.u64(),metadata=c.u64();
 for(let i=0;i<metadata;i++){const start=c.p,key=c.str(),type=c.u32();readMeta(c,type,key);if(key!=='littlebit.recovery_training')chunks.push(bytes.slice(start,c.p));}
 const tensorStart=c.p;for(let i=0;i<count;i++){c.str();const dims=c.u32();for(let j=0;j<dims;j++)c.u64();c.u32();c.u64();}
 const tensorEnd=c.p,alignment=Number(task.student.em.meta['general.alignment']||32),oldOffset=task.student.em.dataOffset;
 const str=value=>{const data=new TextEncoder().encode(value),out=new Uint8Array(8+data.length);new DataView(out.buffer).setBigUint64(0,BigInt(data.length),true);out.set(data,8);return out;};
 const key=str('littlebit.recovery_training'),value=str('WebGPU QAT; '+task.exposures+' exposures; see companion report');const entry=new Uint8Array(key.length+4+value.length);entry.set(key);new DataView(entry.buffer).setUint32(key.length,8,true);entry.set(value,key.length+4);chunks.push(entry);
 const head=new Uint8Array(24),view=new DataView(head.buffer);head.set(new TextEncoder().encode('GGUF'));view.setUint32(4,version,true);view.setBigUint64(8,BigInt(count),true);view.setBigUint64(16,BigInt(chunks.length),true);
 const headerLength=24+chunks.reduce((n,b)=>n+b.length,0)+tensorEnd-tensorStart,newOffset=Math.ceil(headerLength/alignment)*alignment;const out=new Uint8Array(newOffset+bytes.length-oldOffset);let at=0;for(const chunk of [head,...chunks,bytes.slice(tensorStart,tensorEnd)]){out.set(chunk,at);at+=chunk.length;}out.set(bytes.subarray(oldOffset),newOffset);return out;
}
async function exportModel(){const t=task;if(!t)throw Error('No trained factors');const bytes=new Uint8Array(await t.student.file.arrayBuffer()),dv=new DataView(bytes.buffer);for(const [name,weight] of t.studentModel.weights){if(!weight.paths||name==='output.weight'&&!t.student.em.tensors.has(name))continue;const tensor=t.student.em.tensors.get(name);if(!tensor?.lb)continue;
 for(let i=0;i<weight.paths.length;i++){const p=weight.paths[i],desc=tensor.lb[i];for(const k of ['u','v','h','g','l']){const data=await t.g.read(p[k]),target=desc[k];if(k==='u'||k==='v'){bytes.fill(0,target.abs,target.abs+target.nbytes);for(let j=0;j<data.length;j++){if(!Number.isFinite(data[j]))throw Error('Nonfinite factor');if(data[j]<0)bytes[target.abs+(j>>3)]|=1<<(j&7);}}else for(let j=0;j<data.length;j++)dv.setUint16(target.abs+j*2,toHalf(data[j]),true);}}}
 const exported=markRecovered(bytes);download('SmolLM2-recovered-WebGPU.lb.gguf',[exported]);download('SmolLM2-recovered-WebGPU.report.json',[JSON.stringify({source:t.source,settings:t.settings,steps:t.steps,exposures:t.exposures,stage:t.stage,baseline:t.baseline,pre:t.pre,post:t.post,sha256:await hash(exported),lineage:t.lineage,note:'Browser WebGPU QAT; read measurements, no guaranteed quality improvement.'},null,2)],'application/json');}
async function start(){if(training)return;training=true;stop=false;updateControls();el('qatStart').disabled=true;el('qatTeacher').disabled=el('qatStudent').disabled=true;
 try{if(!task){log('Verifying corpus and loading GPU training state…');await setup();}const ceiling=+el('qatMemory').value;if(!Number.isFinite(ceiling)||ceiling<512||ceiling>16384)throw Error('Allocation ceiling must be 512..16384 MiB');task.g.maxBytes=ceiling*1048576;memoryStatus();log('GPU state ready. Training memory is larger than packed inference weights.');const n=task.settings.evalTokens;if(!Number.isInteger(n)||n<8||n>32768)throw Error('Evaluation tokens outside 8..32768');
 if(!task.baseline){log('Measuring original Q8 perplexity…');task.baseline=await metric(task.teacherModel,n);showMetrics();}
 if(!task.pre){log('Measuring compressed pre-recovery perplexity…');task.pre=await metric(task.studentModel,n);showMetrics();}
 while(task.stage<5&&!stop){el('qatBar').value=100*task.exposures/task.settings.budget;el('qatProgress').textContent='Training stage '+(task.stage+1)+'/5 · update '+(task.steps+1)+' · '+task.exposures.toLocaleString()+' tokens completed';if(task.steps===0||task.position===0)log(el('qatProgress').textContent);await new Promise(r=>setTimeout(r,0));const m=await batch();el('qatBar').value=100*task.exposures/task.settings.budget;el('qatProgress').textContent='Stage '+Math.min(5,task.stage+1)+'/5 · '+task.exposures.toLocaleString()+' / '+task.settings.budget.toLocaleString()+' tokens · NLL '+m.nll.toFixed(4);if(task.steps%25===0)log(el('qatProgress').textContent);await new Promise(r=>setTimeout(r,0));}
 if(stop){log('Stopped after completed update. Exporting resumable checkpoint.');await checkpoint();}else{log('Measuring post-recovery perplexity…');task.post=await metric(task.studentModel,n);showMetrics();await checkpoint();await exportModel();log('Recovery cycle complete. Checkpoint and recovered GGUF exported.');}
 }catch(e){if(task){await task.g.abort();memoryStatus();}log('ERROR: '+e.message);console.error(e);el('qatProgress').textContent='Stopped with error: '+e.message;}
 finally{training=false;const status=el('qatProgress').textContent;updateControls();el('qatProgress').textContent=status;}}
if(location.hash==='#recovery')el('qatPanel').style.display='block';
el('qatReset').onclick=async()=>{if(training||!task)return;await task.g.abort();task.teacherModel.destroy();task.studentModel.destroy();task.g.destroy();task=null;showMetrics();updateControls();el('qatMemoryStatus').textContent='GPU training state released. Choose settings and start again.';};
el('qatStart').onclick=start;el('qatStop').onclick=()=>{stop=true;};el('qatSave').onclick=async()=>{if(training){log('Stop training before exporting a checkpoint.');return;}try{await checkpoint();}catch(e){log(e.message);}};el('qatExport').onclick=async()=>{if(training){log('Stop training before exporting weights.');return;}try{await exportModel();}catch(e){log(e.message);}};
root.NexusBrowserRecovery={readCorpus,config,toHalf,getTask:()=>task,isActive:()=>training};
})(globalThis);
