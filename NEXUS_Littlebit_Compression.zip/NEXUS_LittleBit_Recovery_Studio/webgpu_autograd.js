/* Browser-native FP32 autograd for SmolLM2 LittleBit QAT.
   WebGPU is the compute backend. No Python, service, external JS or WASM required.
   Dense frozen teacher; factorized student. Training masters are FP32 and do NOT
   have the packed inference memory footprint. Batch dimension is folded into T.
*/
(function(root){'use strict';
const K={};
const head=`struct P{v:array<vec4<u32>,4>};
@group(0) @binding(0) var<storage,read> a:array<f32>;
@group(0) @binding(1) var<storage,read> b:array<f32>;
@group(0) @binding(2) var<storage,read> c:array<f32>;
@group(0) @binding(3) var<storage,read_write> o:array<f32>;
@group(0) @binding(4) var<uniform> p:P;
fn u(i:u32)->u32{return p.v[i/4u][i%4u];}
fn f(i:u32)->f32{return bitcast<f32>(u(i));}
`;
const elem=body=>head+'@compute @workgroup_size(256) fn main(@builtin(global_invocation_id) g:vec3<u32>,@builtin(num_workgroups) nw:vec3<u32>){let i=g.x+g.y*nw.x*256u;if(i>=u(0u)){return;}'+body+'}';
K.add=elem('o[i]=a[i]+b[i];');
K.mul=elem('o[i]=a[i]*b[i%u(1u)];');
K.mulgrad=elem('var s=0.0;for(var j=i;j<u(1u);j+=u(0u)){s+=a[j]*b[j];}o[i]=s;');
K.sign=elem('o[i]=select(-1.0,1.0,a[i]>=0.0);');
K.signgrad=elem('let t=tanh(100.0*a[i]);o[i]=b[i]*100.0*(1.0-t*t);');
K.half=elem('o[i]=unpack2x16float(pack2x16float(vec2<f32>(a[i],0.0))).x;');
K.silu=elem('o[i]=a[i]/(1.0+exp(-a[i]));');
K.silugrad=elem('let s=1.0/(1.0+exp(-a[i]));o[i]=b[i]*s*(1.0+a[i]*(1.0-s));');
K.scale=elem('o[i]=a[i]*f(1u);');
K.gather=elem('let cols=u(1u);let row=u32(b[i/cols]);o[i]=a[row*cols+i%cols];');
K.gathergrad=elem('let cols=u(1u);let row=i/cols;var s=0.0;for(var j=0u;j<u(2u);j++){if(u32(b[j])==row){s+=a[j*cols+i%cols];}}o[i]=s;');
K.broadcastRows=elem('o[i]=a[i/u(1u)];');
K.sumRows=elem('var s=0.0;for(var j=0u;j<u(1u);j++){s+=a[i*u(1u)+j];}o[i]=s;');
K.transpose=elem('let r=i/u(2u);let col=i%u(2u);o[i]=a[col*u(1u)+r];');
// Tiled GEMM; flags select transposed logical views without materialization.
K.mm=head+`var<workgroup> aa:array<f32,64>;var<workgroup> bb:array<f32,64>;
@compute @workgroup_size(8,8) fn main(@builtin(global_invocation_id) g:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){
 let row=g.y;let col=g.x;let M=u(0u);let N=u(1u);let D=u(2u);var sum=0.0;
 for(var base=0u;base<D;base+=8u){let ka=base+l.x;let kb=base+l.y;var av=0.0;var bv=0.0;
 if(row<M&&ka<D){av=a[select(row*D+ka,ka*M+row,u(3u)!=0u)];}
 if(col<N&&kb<D){bv=b[select(kb*N+col,col*D+kb,u(4u)!=0u)];}
 aa[l.y*8u+l.x]=av;bb[l.y*8u+l.x]=bv;workgroupBarrier();
 for(var k=0u;k<8u;k++){sum+=aa[l.y*8u+k]*bb[k*8u+l.x];}workgroupBarrier();}
 if(row<M&&col<N){o[row*N+col]=sum;}}
`;
K.rms=head+`var<workgroup> sums:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){let r=w.x;let n=u(1u);var s=0.0;for(var j=l.x;j<n;j+=256u){s+=a[r*n+j]*a[r*n+j];}sums[l.x]=s;workgroupBarrier();var st=128u;loop{if(l.x<st){sums[l.x]+=sums[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}let inv=inverseSqrt(sums[0]/f32(n)+f(2u));for(var j=l.x;j<n;j+=256u){o[r*n+j]=a[r*n+j]*inv*b[j];}}`;
K.rmsgrad=head+`var<workgroup> sx:array<f32,256>;var<workgroup> sd:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){let r=w.x;let n=u(1u);var xx=0.0;var dot=0.0;for(var j=l.x;j<n;j+=256u){xx+=a[r*n+j]*a[r*n+j];dot+=a[r*n+j]*b[r*n+j]*c[j];}sx[l.x]=xx;sd[l.x]=dot;workgroupBarrier();var st=128u;loop{if(l.x<st){sx[l.x]+=sx[l.x+st];sd[l.x]+=sd[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}let inv=inverseSqrt(sx[0]/f32(n)+f(2u));for(var j=l.x;j<n;j+=256u){o[r*n+j]=inv*(b[r*n+j]*c[j]-a[r*n+j]*inv*inv*sd[0]/f32(n));}}`;
K.rope=elem('let hd=u(1u);let width=u(2u);let t=i/width;let pair=(i%hd)/2u;let other=select(i+1u,i-1u,i%2u==1u);let theta=f32(t)*pow(f(3u),-2.0*f32(pair)/f32(hd));let sn=sin(theta)*f(4u);let cs=cos(theta);o[i]=a[i]*cs+select(-a[other]*sn,a[other]*sn,i%2u==1u);');
K.score=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let j=i%T;let t=(i/T)%T;let h=i/(T*T);var v=0.0;if(j>t){o[i]=-1e30;return;}for(var k=0u;k<D;k++){v+=a[t*H*D+h*D+k]*b[j*KV*D+(h/(H/KV))*D+k];}o[i]=v*inverseSqrt(f32(D));');
K.scoreq=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let t=i/(H*D);let h=(i/D)%H;let k=i%D;var v=0.0;for(var j=0u;j<=t;j++){v+=a[h*T*T+t*T+j]*b[j*KV*D+(h/(H/KV))*D+k];}o[i]=v*inverseSqrt(f32(D));');
K.scorek=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let j=i/(KV*D);let kh=(i/D)%KV;let k=i%D;var v=0.0;for(var h=kh*(H/KV);h<(kh+1u)*(H/KV);h++){for(var t=j;t<T;t++){v+=a[h*T*T+t*T+j]*b[t*H*D+h*D+k];}}o[i]=v*inverseSqrt(f32(D));');
K.att=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let t=i/(H*D);let h=(i/D)%H;let k=i%D;var v=0.0;for(var j=0u;j<=t;j++){v+=a[h*T*T+t*T+j]*b[j*KV*D+(h/(H/KV))*D+k];}o[i]=v;');
K.attp=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let j=i%T;let t=(i/T)%T;let h=i/(T*T);var v=0.0;if(j>t){o[i]=0.0;return;}for(var k=0u;k<D;k++){v+=a[t*H*D+h*D+k]*b[j*KV*D+(h/(H/KV))*D+k];}o[i]=v;');
K.attv=elem('let T=u(1u);let H=u(2u);let KV=u(3u);let D=u(4u);let j=i/(KV*D);let kh=(i/D)%KV;let k=i%D;var v=0.0;for(var h=kh*(H/KV);h<(kh+1u)*(H/KV);h++){for(var t=j;t<T;t++){v+=a[h*T*T+t*T+j]*b[t*H*D+h*D+k];}}o[i]=v;');
K.softmax=head+`var<workgroup> s:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){let row=w.x;let n=u(1u);var mx=-1e30;for(var j=l.x;j<n;j+=256u){mx=max(mx,a[row*n+j]);}s[l.x]=mx;workgroupBarrier();var st=128u;loop{if(l.x<st){s[l.x]=max(s[l.x],s[l.x+st]);}workgroupBarrier();if(st==1u){break;}st/=2u;}let m=s[0];workgroupBarrier();var sum=0.0;for(var j=l.x;j<n;j+=256u){sum+=exp(a[row*n+j]-m);}s[l.x]=sum;workgroupBarrier();st=128u;loop{if(l.x<st){s[l.x]+=s[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}for(var j=l.x;j<n;j+=256u){o[row*n+j]=exp(a[row*n+j]-m)/s[0];}}`;
K.softmaxgrad=head+`var<workgroup> s:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){let row=w.x;let n=u(1u);var v=0.0;for(var j=l.x;j<n;j+=256u){v+=a[row*n+j]*b[row*n+j];}s[l.x]=v;workgroupBarrier();var st=128u;loop{if(l.x<st){s[l.x]+=s[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}for(var j=l.x;j<n;j+=256u){let ix=row*n+j;o[ix]=a[ix]*(b[ix]-s[0]);}}`;
K.logitgrad=elem('let V=u(1u);let row=i/V;let y=u32(c[row]);o[i]=((a[i]-b[i])+f(2u)*(a[i]-select(0.0,1.0,i%V==y)))/f32(u(3u));');
K.msegrad=elem('o[i]=f(1u)*(a[i]-b[i]);');
K.squareReduce=head+`var<workgroup> s:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>,@builtin(num_workgroups) nw:vec3<u32>){let group=w.x+w.y*nw.x;let i=group*256u+l.x;var v=0.0;if(i<u(0u)){v=a[i]*a[i];}s[l.x]=v;workgroupBarrier();var st=128u;loop{if(l.x<st){s[l.x]+=s[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}if(l.x==0u&&group<(u(0u)+255u)/256u){o[group]=s[0];}}`;
K.sumReduce=head+`var<workgroup> s:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>,@builtin(num_workgroups) nw:vec3<u32>){let group=w.x+w.y*nw.x;let i=group*256u+l.x;var v=0.0;if(i<u(0u)){v=a[i];}s[l.x]=v;workgroupBarrier();var st=128u;loop{if(l.x<st){s[l.x]+=s[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}if(l.x==0u&&group<(u(0u)+255u)/256u){o[group]=s[0];}}`;
K.mse=elem('let v=a[i]-b[i];o[i]=v*v;');
// Stable next-token NLL from raw logits, including low-probability targets.
K.nll=head+`var<workgroup> s:array<f32,256>;
@compute @workgroup_size(256) fn main(@builtin(workgroup_id) w:vec3<u32>,@builtin(local_invocation_id) l:vec3<u32>){let row=w.x;let n=u(1u);var mx=-1e30;for(var j=l.x;j<n;j+=256u){mx=max(mx,a[row*n+j]);}s[l.x]=mx;workgroupBarrier();var st=128u;loop{if(l.x<st){s[l.x]=max(s[l.x],s[l.x+st]);}workgroupBarrier();if(st==1u){break;}st/=2u;}let m=s[0];workgroupBarrier();var v=0.0;for(var j=l.x;j<n;j+=256u){v+=exp(a[row*n+j]-m);}s[l.x]=v;workgroupBarrier();st=128u;loop{if(l.x<st){s[l.x]+=s[l.x+st];}workgroupBarrier();if(st==1u){break;}st/=2u;}if(l.x==0u){o[row]=m+log(s[0])-a[row*n+u32(b[row])];}}`;
// Adam uses separate read/write buffers to stay within portable binding limits.
K.adamM=elem('o[i]=0.9*a[i]+0.1*b[i]*f(1u);');
K.adamV=elem('let grad=b[i]*f(1u);o[i]=0.999*a[i]+0.001*grad*grad;');
K.adamW=elem('let m=b[i]/f(2u);let v=c[i]/f(3u);var x=a[i]-f(1u)*m/(sqrt(v)+1e-8);if(u(4u)==1u){x=clamp(x,-0.05,0.05);}else{x=clamp(x,-65000.0,65000.0);}o[i]=x;');
const bits=x=>{const a=new Float32Array([x]);return new Uint32Array(a.buffer)[0];};
class GPUAutograd{
 constructor(device){this.d=device;this.pipes={};this.temp=[];this.tape=[];this.record=true;this.encoder=null;this.params=[];this.memory=0;this.peak=0;this.maxBytes=2*1024**3;this.failure=null;device.addEventListener?.('uncapturederror',e=>{this.failure=this.failure||e.error?.message||'WebGPU validation error';});device.lost?.then(info=>{this.failure='WebGPU device lost: '+(info.message||info.reason);});}
 async init(){const bindLayout=this.d.createBindGroupLayout({entries:[0,1,2,3,4].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding===4?'uniform':binding===3?'storage':'read-only-storage'}}))});const layout=this.d.createPipelineLayout({bindGroupLayouts:[bindLayout]});for(const [name,code] of Object.entries(K)){const mod=this.d.createShaderModule({code,label:'QAT '+name});const info=await mod.getCompilationInfo();const errors=info.messages.filter(x=>x.type==='error');if(errors.length)throw Error(name+': '+errors.map(x=>x.message).join('\n'));this.pipes[name]=await this.d.createComputePipelineAsync({layout,compute:{module:mod,entryPoint:'main'}});}this.zero=this.tensor([0],[1],false,true);return this;}
 tensor(data,shape,grad=false,persistent=false){const n=shape.reduce((a,b)=>a*b,1);if(!Number.isSafeInteger(n)||n<1)throw Error('Invalid tensor shape');const size=n*4;if(size>this.d.limits.maxStorageBufferBindingSize)throw Error('Tensor exceeds device storage binding limit');if(this.memory+size>this.maxBytes)throw Error('Training allocation ceiling reached: '+Math.ceil((this.memory+size)/1048576)+' MiB requested, '+Math.round(this.maxBytes/1048576)+' MiB allowed. Increase the allocation ceiling if your GPU has room, or reduce sequence length.');const buf=this.d.createBuffer({size,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC});this.memory+=size;this.peak=Math.max(this.peak,this.memory);const t={buf,shape,n,requiresGrad:grad,grad:null,persistent};if(data)this.d.queue.writeBuffer(buf,0,data instanceof Float32Array?data:Float32Array.from(data));if(!persistent)this.temp.push(t);return t;}
 parameter(data,shape,name){const t=this.tensor(data,shape,true,true);t.name=name;t.m=this.tensor(null,shape,false,true);t.v=this.tensor(null,shape,false,true);this.params.push(t);return t;}
 run(name,a,b,c,shape,values,dispatch){const out=this.tensor(null,shape);this.into(name,a,b,c,out,values,dispatch);return out;}
 into(name,a,b,c,out,values,dispatch){if(!this.encoder)this.encoder=this.d.createCommandEncoder();const p=this.d.createBuffer({size:64,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});this.d.queue.writeBuffer(p,0,new Uint32Array([...values,...Array(16-values.length).fill(0)]));this.temp.push({buf:p,n:0});const pipeline=this.pipes[name];const bg=this.d.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[a||this.zero,b||this.zero,c||this.zero,out,{buf:p}].map((t,binding)=>({binding,resource:{buffer:t.buf}}))});const pass=this.encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bg);let groups=dispatch||[Math.ceil(out.n/256)];const limit=this.d.limits.maxComputeWorkgroupsPerDimension||65535;if(groups.length===1&&groups[0]>limit){groups=[limit,Math.ceil(groups[0]/limit)];}if(groups.some(n=>n>limit))throw Error(name+': dispatch exceeds GPU limit');pass.dispatchWorkgroups(...groups);pass.end();}
 flush(){if(this.failure)throw Error(this.failure);if(this.encoder){this.d.queue.submit([this.encoder.finish()]);this.encoder=null;}}
 async read(t){this.flush();const b=this.d.createBuffer({size:t.n*4,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const e=this.d.createCommandEncoder();e.copyBufferToBuffer(t.buf,0,b,0,t.n*4);this.d.queue.submit([e.finish()]);await b.mapAsync(GPUMapMode.READ);const a=new Float32Array(b.getMappedRange().slice(0));b.unmap();b.destroy();return a;}
 async retain(keep){this.flush();await this.d.queue.onSubmittedWorkDone();const retained=new Set(keep);this.temp=this.temp.filter(t=>{if(retained.has(t))return true;t.buf.destroy();this.memory-=t.n*4;return false;});}
 async abort(){this.encoder=null;await this.d.queue.onSubmittedWorkDone().catch(()=>{});for(const t of this.temp){t.buf.destroy();this.memory-=t.n*4;}this.temp=[];this.tape=[];for(const p of this.params)p.grad=null;}
 async clear(){this.flush();await this.d.queue.onSubmittedWorkDone();for(const t of this.temp){t.buf.destroy();this.memory-=t.n*4;}this.temp=[];this.tape=[];for(const p of this.params)p.grad=null;}
 track(out,inputs,back){out.requiresGrad=this.record&&inputs.some(x=>x.requiresGrad);if(out.requiresGrad)this.tape.push(()=>back(out.grad));return out;}
 accum(t,g){if(!t.requiresGrad||!g)return;t.grad=t.grad?this.run('add',t.grad,g,null,t.shape,[t.n]):g;}
 backward(seeds){for(const [t,g] of seeds)this.accum(t,g);for(let i=this.tape.length-1;i>=0;i--)this.tape[i]();}
 unary(name,x){const y=this.run(name,x,null,null,x.shape,[x.n]);return this.track(y,[x],g=>{if(!g)return;this.accum(x,name==='half'?g:this.run(name+'grad',x,g,null,x.shape,[x.n]));});}
 add(a,b){const y=this.run('add',a,b,null,a.shape,[a.n]);return this.track(y,[a,b],g=>{this.accum(a,g);this.accum(b,g);});}
 mul(a,b){if(a.n%b.n)throw Error('Invalid broadcast');const y=this.run('mul',a,b,null,a.shape,[a.n,b.n]);return this.track(y,[a,b],g=>{if(!g)return;this.accum(a,this.run('mul',g,b,null,a.shape,[a.n,b.n]));this.accum(b,this.run('mulgrad',g,a,null,b.shape,[b.n,a.n]));});}
 mmRaw(a,b,M,N,D,ta=0,tb=0){return this.run('mm',a,b,null,[M,N],[M,N,D,ta,tb],[Math.ceil(N/8),Math.ceil(M/8)]);}
 mm(a,b,tb=false){const [M,D]=a.shape,N=tb?b.shape[0]:b.shape[1];if(D!==(tb?b.shape[1]:b.shape[0]))throw Error('GEMM dimensions mismatch');const y=this.mmRaw(a,b,M,N,D,0,+tb);return this.track(y,[a,b],g=>{if(!g)return;this.accum(a,this.mmRaw(g,b,M,D,N,0,tb?0:1));this.accum(b,tb?this.mmRaw(g,a,N,D,M,1,0):this.mmRaw(a,g,D,N,M,1,0));});}
 gather(a,ids){const cols=a.shape.length===1?1:a.shape[1],y=this.run('gather',a,ids,null,[ids.n,cols],[ids.n*cols,cols]);return this.track(y,[a],g=>{if(g)this.accum(a,this.run('gathergrad',g,ids,null,a.shape,[a.n,cols,ids.n]));});}
 rowScale(a,h){const expanded=this.run('broadcastRows',h,null,null,a.shape,[a.n,a.shape[1]]);this.track(expanded,[h],g=>{if(g)this.accum(h,this.run('sumRows',g,null,null,h.shape,[h.n,a.shape[1]]));});return this.mul(a,expanded);}
 rms(x,w,eps){const [T,D]=x.shape,y=this.run('rms',x,w,null,x.shape,[T,D,bits(eps)],[T]);return this.track(y,[x],g=>{if(g)this.accum(x,this.run('rmsgrad',x,g,w,x.shape,[T,D,bits(eps)],[T]));});}
 rope(x,hd,theta){const y=this.run('rope',x,null,null,x.shape,[x.n,hd,x.shape[1],bits(theta),bits(1)]);return this.track(y,[x],g=>{if(g)this.accum(x,this.run('rope',g,null,null,x.shape,[x.n,hd,x.shape[1],bits(theta),bits(-1)]));});}
 softmax(x,rows,cols){const y=this.run('softmax',x,null,null,x.shape,[rows,cols],[rows]);return this.track(y,[x],g=>{if(g)this.accum(x,this.run('softmaxgrad',y,g,null,x.shape,[rows,cols],[rows]));});}
 attention(q,k,v,T,H,KV,D){const shape=[H*T,T],params=[H*T*T,T,H,KV,D];const s=this.run('score',q,k,null,shape,params);this.track(s,[q,k],g=>{if(!g)return;this.accum(q,this.run('scoreq',g,k,null,q.shape,[q.n,T,H,KV,D]));this.accum(k,this.run('scorek',g,q,null,k.shape,[k.n,T,H,KV,D]));});const p=this.softmax(s,H*T,T);const y=this.run('att',p,v,null,[T,H*D],[T*H*D,T,H,KV,D]);return this.track(y,[p,v],g=>{if(!g)return;this.accum(p,this.run('attp',g,v,null,shape,params));this.accum(v,this.run('attv',p,g,null,v.shape,[v.n,T,H,KV,D]));});}
 reduce(x,square=false){let t=this.run(square?'squareReduce':'sumReduce',x,null,null,[Math.ceil(x.n/256)],[x.n],[Math.ceil(x.n/256)]);while(t.n>1)t=this.run('sumReduce',t,null,null,[Math.ceil(t.n/256)],[t.n],[Math.ceil(t.n/256)]);return t;}
 async step(lr,index,clip=1){const sums=this.params.filter(p=>p.grad).map(p=>this.reduce(p.grad,true));const packed=this.tensor(null,[Math.max(1,sums.length)]);for(let i=0;i<sums.length;i++)this.encoder.copyBufferToBuffer(sums[i].buf,0,packed.buf,i*4,4);let total=0;for(const value of await this.read(packed))total+=value;if(!Number.isFinite(total))throw Error('Nonfinite gradient: update aborted');const scale=Math.min(1,clip/Math.max(1e-12,Math.sqrt(total)));
  // Free completed graph buffers and allocate all optimizer scratch before mutating parameters.
  this.tape=[];await this.retain(this.params.map(p=>p.grad).filter(Boolean));
  const count=Math.max(1,...this.params.filter(p=>p.grad).map(p=>p.n));
  const scratch=Array.from({length:3},()=>this.tensor(null,[count]));
  for(const p of this.params){if(!p.grad)continue;const [m,v,w]=scratch.map(t=>({...t,n:p.n,shape:p.shape}));this.into('adamM',p.m,p.grad,null,m,[p.n,bits(scale)]);this.into('adamV',p.v,p.grad,null,v,[p.n,bits(scale)]);this.into('adamW',p,m,v,w,[p.n,bits(lr),bits(1-Math.pow(.9,index)),bits(1-Math.pow(.999,index)),p.name.endsWith('/u')||p.name.endsWith('/v')?1:0]);for(const [src,dst] of [[m,p.m],[v,p.v],[w,p]])this.encoder.copyBufferToBuffer(src.buf,0,dst.buf,0,p.n*4);}
  this.flush();return Math.sqrt(total);
 }
 destroy(){this.encoder=null;for(const t of this.temp)t.buf.destroy();for(const p of this.params){p.buf.destroy();p.m.buf.destroy();p.v.buf.destroy();}if(this.zero)this.zero.buf.destroy();}
}
class SmolTrainingModel{
 constructor(g,config){this.g=g;this.c=config;this.weights=new Map();this.frozen=[];}
 async load(em,reader,trainable){const g=this.g;
  for(const [name,t] of em.tensors){if(!name.endsWith('.weight'))continue;if(t.lb){const paths=await root.NexusEngineAPI.loadFactorCPU(reader,t),loaded=[];for(let j=0;j<paths.length;j++){const p=paths[j],mk=(data,shape,k)=>trainable?g.parameter(data,shape,name+'/'+j+'/'+k):this.constant(data,shape);const unpack=(a,n)=>Float32Array.from({length:n},(_,i)=>((a[i>>3]>>(i&7))&1)?-.01:.01);loaded.push({u:mk(unpack(p.u,p.rows*p.rank),[p.rows,p.rank],'u'),v:mk(unpack(p.v,p.rank*p.cols),[p.rank,p.cols],'v'),h:mk(p.h,[p.rows],'h'),g:mk(p.g,[p.cols],'g'),l:mk(p.l,[p.rank],'l')});}this.weights.set(name,{paths:loaded});}else{const arr=root.NexusEngineAPI.dequant(await reader.read(t.abs,t.nbytes),t.qt);this.weights.set(name,{dense:this.constant(arr,t.dims.slice().reverse())});}}
  if(!this.weights.has('output.weight'))this.weights.set('output.weight',this.weights.get('token_embd.weight'));return this;
 }
 constant(data,shape){const t=this.g.tensor(data,shape,false,true);this.frozen.push(t);return t;}
 factors(p){if(this.factorCache?.has(p))return this.factorCache.get(p);const g=this.g;const result={u:g.unary('sign',p.u),v:g.unary('sign',p.v),h:g.unary('half',p.h),g:g.unary('half',p.g),l:g.unary('half',p.l)};this.factorCache?.set(p,result);return result;}
 linear(name,x){const w=this.weights.get(name);if(!w)throw Error('Missing training tensor '+name);const g=this.g;if(w.dense)return g.mm(x,w.dense,true);let sum=null;for(const original of w.paths){const p=this.factors(original);let z=g.mm(g.mul(x,p.g),p.v,true);z=g.mul(z,p.l);let y=g.mul(g.mm(z,p.u,true),p.h);sum=sum?g.add(sum,y):y;}return sum;}
 embedding(ids){const w=this.weights.get('token_embd.weight'),g=this.g;if(w.dense)return g.gather(w.dense,ids);let sum=null;for(const original of w.paths){const p=this.factors(original);const u=g.gather(p.u,ids),h=g.gather(p.h,ids);let y=g.rowScale(g.mul(g.mm(g.mul(u,p.l),p.v),p.g),h);sum=sum?g.add(sum,y):y;}return sum;}
 forward(ids,record=true){const g=this.g,c=this.c;g.record=record;this.factorCache=new Map();let x=this.embedding(ids);const hidden=[];
  for(let i=0;i<c.layers;i++){const b='blk.'+i+'.',norm=n=>this.weights.get(b+n+'.weight').dense;let a=g.rms(x,norm('attn_norm'),c.eps);const q=g.rope(this.linear(b+'attn_q.weight',a),c.hd,c.theta),k=g.rope(this.linear(b+'attn_k.weight',a),c.hd,c.theta),v=this.linear(b+'attn_v.weight',a);x=g.add(x,this.linear(b+'attn_output.weight',g.attention(q,k,v,ids.n,c.heads,c.kv,c.hd)));a=g.rms(x,norm('ffn_norm'),c.eps);x=g.add(x,this.linear(b+'ffn_down.weight',g.mul(g.unary('silu',this.linear(b+'ffn_gate.weight',a)),this.linear(b+'ffn_up.weight',a))));hidden.push(x);}
  const final=g.rms(x,this.weights.get('output_norm.weight').dense,c.eps);hidden[hidden.length-1]=final;const logits=this.linear('output.weight',final);return {logits,hidden};
 }
 destroy(){for(const t of this.frozen){t.buf.destroy();this.g.memory-=t.n*4;}}
}
root.NexusQAT={GPUAutograd,SmolTrainingModel,kernels:K,bits};
})(globalThis);
