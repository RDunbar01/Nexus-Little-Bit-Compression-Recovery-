"""SmolLM2-135M recovery corpus compiler.

Online mode uses a pinned revision of an EleutherAI sample of the *actual*
SmolLM2-135M pretraining mixture, HF Smol-SmolTalk for SFT and WikiText-2 validation.
Stage 5 is deliberate replay. Failure to obtain enough real data is fatal.
Tokenized uint32 shards and checksums are written atomically, with provenance.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import numpy as np

REPOS = {
    'pretrain': ('EleutherAI/SmolLM2-135M-10B', None, 'train'),
    'instruction': ('HuggingFaceTB/smol-smoltalk', None, 'train'),
    'holdout': ('Salesforce/wikitext', 'wikitext-2-raw-v1', 'validation'),
}
TARGET_SOURCES = ('dclm', 'fineweb', 'cosmopedia', 'stack', 'finemath', 'infimm')


def note(event, **kw):
    print(json.dumps({'event': event, **kw}, ensure_ascii=False), flush=True)


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()


def normalize(row):
    if isinstance(row,str):return row.strip()
    if not isinstance(row,dict):return ''
    s=row.get('text')
    if isinstance(s,str):return s.strip()
    messages=row.get('messages') or row.get('conversations')
    if isinstance(messages,list):
        out=[]
        for msg in messages:
            if not isinstance(msg,dict):continue
            role=msg.get('role',msg.get('from','unknown'))
            content=msg.get('content',msg.get('value',''))
            if isinstance(content,list):content=' '.join(item.get('text','') for item in content if isinstance(item,dict))
            if isinstance(content,str) and content.strip():out.append(f'{role}: {content.strip()}')
        return '\n'.join(out)
    return ''


def encode(row, tok, conversations=False):
    if conversations and isinstance(row,dict) and isinstance(row.get('messages'),list) and hasattr(tok,'apply_chat_template'):
        try:
            ids=tok.apply_chat_template(row['messages'],tokenize=True,add_generation_prompt=False)
            if hasattr(ids,'tolist'):ids=ids.tolist()
            if ids:return [int(x) for x in ids]
        except (ValueError,TypeError,KeyError,AttributeError):pass
    text=normalize(row)
    if len(text)<32:return []
    ids=tok.encode(text,add_special_tokens=False)
    if tok.eos_token_id is not None:ids.append(tok.eos_token_id)
    return ids


def category(source):
    s=str(source or '').lower().replace('-','_')
    if 'dclm' in s:return 'dclm'
    if 'fineweb' in s:return 'fineweb'
    if 'cosmopedia' in s:return 'cosmopedia'
    if 'stack' in s:return 'stack'
    if 'infimm' in s:return 'infimm'
    if 'finemath' in s:return 'finemath'
    return None


def stage_mix(group, quota):
    """Exact 5-stage 10M-token curriculum from matching source categories."""
    if group==0:return {'dclm':(quota*3)//5,'fineweb':quota-(quota*3)//5}
    if group==1:return {'cosmopedia':quota//2,'stack':quota-quota//2}
    if group==2:return {'finemath':quota//2,'infimm':quota-quota//2}
    return {}


def datasets_stream(repo, subset, split, revision):
    from datasets import load_dataset
    kw={'split':split,'streaming':True,'revision':revision}
    return load_dataset(repo,subset,**kw) if subset else load_dataset(repo,**kw)


def online_download(tok,quota,validation_tokens,seed,max_rows=750_000):
    from huggingface_hub import HfApi
    api=HfApi(); hashes={}; revisions={}
    for name,(repo,subset,split) in REPOS.items():
        sha=api.dataset_info(repo).sha
        if not sha:raise RuntimeError('Unable to resolve immutable revision: '+repo)
        revisions[name]={'repo':repo,'subset':subset,'split':split,'revision':sha}
    # In this sample the source column has six values corresponding to the
    # real pretraining datasets. Math sources are combined in Stage 3.
    quota_by_source={}
    for stage in range(3):
        for key,n in stage_mix(stage,quota).items():quota_by_source[key]=quota_by_source.get(key,0)+n
    chunks={k:[] for k in quota_by_source}
    counts={k:0 for k in quota_by_source}
    docs={k:0 for k in quota_by_source}
    ds=datasets_stream(*REPOS['pretrain'][:2],REPOS['pretrain'][2],revisions['pretrain']['revision'])
    # Deterministic iteration and finite maximum scan. Source mixes not faked.
    for idx,row in enumerate(ds):
        if idx>=max_rows:break
        k=category(row.get('source') if isinstance(row,dict) else '')
        if not k or counts[k]>=quota_by_source[k]:continue
        content=normalize(row)
        if len(content)<32:continue
        key=hashlib.sha256(content.encode('utf-8')).digest()
        if key in hashes:continue
        values=encode(row,tok)
        if not values:continue
        hashes[key]=True
        values=values[:quota_by_source[k]-counts[k]]
        chunks[k].extend(values);counts[k]+=len(values);docs[k]+=1
        if idx%20000==0:note('pretrain_progress',records=idx,tokens=counts,goals=quota_by_source)
        if all(counts[q]>=quota_by_source[q] for q in counts):break
    short={k:quota_by_source[k]-counts[k] for k in counts if counts[k]<quota_by_source[k]}
    if short:raise RuntimeError(f'Pretraining sample scan exhausted; missing real tokens {short}. Increase --max-rows; no synthetic filler.')
    stages=[]
    for i in range(3):
        pools=[]
        for k,n in stage_mix(i,quota).items():
            # In default recipe stage 1/2/3 consume disjoint data types.
            pools.append(np.array(chunks[k][:n],dtype='<u4'))
        stages.append(interleave(pools,quota))
        note('stage_ready',stage=i+1,tokens=len(stages[-1]),sources=list(stage_mix(i,quota)))
    ds=datasets_stream(*REPOS['instruction'][:2],REPOS['instruction'][2],revisions['instruction']['revision'])
    instruction=[];seen=set(hashes)
    for idx,row in enumerate(ds):
        if idx>=max_rows:break
        content=normalize(row)
        if len(content)<32:continue
        h=hashlib.sha256(content.encode('utf-8')).digest()
        if h in seen:continue
        ids=encode(row,tok,conversations=True)
        if not ids:continue
        seen.add(h);instruction.extend(ids[:quota-len(instruction)])
        if len(instruction)>=quota:break
    if len(instruction)<quota:raise RuntimeError('Not enough Smol-SmolTalk instructional tokens; no filler used')
    stages.append(np.array(instruction,dtype='<u4'))
    note('stage_ready',stage=4,tokens=quota,sources=['HuggingFaceTB/smol-smoltalk'])
    # Stage 5 is balanced replay from the four previously selected stages.
    stages.append(interleave([stages[i] for i in range(4)],quota,seed=seed))
    note('stage_ready',stage=5,tokens=quota,sources=['replay stage1..stage4'])
    held=[]
    ds=datasets_stream(*REPOS['holdout'][:2],REPOS['holdout'][2],revisions['holdout']['revision'])
    for row in ds:
        ids=encode(row,tok)
        if not ids:continue
        held.extend(ids[:validation_tokens-len(held)])
        if len(held)>=validation_tokens:break
    if len(held)<validation_tokens:raise RuntimeError('WikiText-2 validation split had fewer tokens than requested')
    provenance={'revisions':revisions,'sample_counts':counts,'sample_documents':docs,
        'stage1':'60% DCLM-Edu + 40% FineWeb-Edu from sampled SmolLM2-135M pretraining mixture',
        'stage2':'50% Cosmopedia V2 + 50% Stack-Edu',
        'stage3':'50% FineMath + 50% InfiMM-WebMath; custom recovery proportions',
        'stage4':'Smol-SmolTalk instruction samples, train split',
        'stage5':'Explicit replay of prior four stages; 0 new independent tokens',
        'holdout':'WikiText-2 raw validation; never drawn from the training split',
        'source_licenses':'Review source dataset cards and each underlying dataset license; no universal relicensing granted'}
    return stages,np.array(held,dtype='<u4'),provenance


def interleave(pools, quota, seed=0):
    """Interleave source slices while preserving EXACT input source proportions.

    For consolidation only, explicit replay is allowed if the requested count
    exceeds a source. No synthetic filler or implicit source inflation occurs.
    """
    pools=[np.asarray(p,dtype='<u4') for p in pools]
    if not pools or any(not len(p) for p in pools):raise ValueError('Empty source pool')
    if quota<1:raise ValueError('Quota must be positive')
    counts=[(quota*len(p))//sum(map(len,pools)) for p in pools]
    # Largest-remainder allocation preserves exactly quota tokens.
    rem=quota-sum(counts)
    fracs=sorted(range(len(pools)),key=lambda i:(quota*len(pools[i]))%sum(map(len,pools)),reverse=True)
    for i in fracs[:rem]:counts[i]+=1
    rng=np.random.default_rng(seed);parts=[];left=list(counts);offsets=[0]*len(pools)
    while any(left):
        for i,p in enumerate(pools):
            if not left[i]:continue
            take=min(2048,left[i],len(p))
            off=offsets[i]
            if off+take>len(p):off=int(rng.integers(0,len(p)-take+1))
            parts.append(p[off:off+take]);offsets[i]=off+take;left[i]-=take
    return np.concatenate(parts)


def local_import(source_dir, quota, validation_tokens, tok):
    source_dir=Path(source_dir)
    arrays=[]
    for i in range(1,6):
        file=source_dir/f'stage{i}.txt'
        if not file.is_file():raise FileNotFoundError(file)
        ids=encode({'text':file.read_text(encoding='utf8')},tok)
        if len(ids)<quota:raise ValueError(f'Stage {i} has {len(ids)} tokens; requires {quota}.')
        arrays.append(np.asarray(ids[:quota],dtype='<u4'))
    p=source_dir/'validation.txt'
    if not p.is_file():raise FileNotFoundError(p)
    ids=encode({'text':p.read_text(encoding='utf8')},tok)
    if len(ids)<validation_tokens:raise ValueError('Too few held-out validation tokens')
    return arrays,np.asarray(ids[:validation_tokens],dtype='<u4'),{'import_dir':str(source_dir.resolve()),'warning':'Holdout separation is user-provided; verify no leakage'}


def build(args):
    from transformers import AutoTokenizer
    if args.tokens_per_stage<8 or args.validation_tokens<8:raise ValueError('Token targets must be >=8')
    base=Path(args.hf_model).expanduser().resolve()
    if not base.is_dir():raise FileNotFoundError('Local HF tokenizer directory required')
    tok=AutoTokenizer.from_pretrained(base,local_files_only=True,use_fast=True)
    out=Path(args.output).expanduser().resolve();out.mkdir(parents=True,exist_ok=True)
    if not args.overwrite and any(out.glob('*.tokens.bin')):raise FileExistsError('Corpus exists; use a new folder or explicit --overwrite')
    if args.import_dir:
        stages,held,provenance=local_import(args.import_dir,args.tokens_per_stage,args.validation_tokens,tok)
    elif args.download:
        stages,held,provenance=online_download(tok,args.tokens_per_stage,args.validation_tokens,args.seed,args.max_rows)
    else:raise ValueError('Choose --download or --import-dir')
    files={}
    for i,ar in enumerate(stages,1):
        f=out/f'stage{i}.tokens.bin';tmp=out/f'.{f.name}.partial'
        np.asarray(ar,dtype='<u4').tofile(tmp);os.replace(tmp,f);files[f.name]=sha256(f)
    f=out/'validation.tokens.bin';tmp=out/f'.{f.name}.partial'
    np.asarray(held,dtype='<u4').tofile(tmp);os.replace(tmp,f);files[f.name]=sha256(f)
    tokenfile=base/'tokenizer.json'
    manifest={'format':2,'source':'SmolLM2-135M actual pretraining-mixture sample plus Smol-SmolTalk',
        'tokens_per_stage':args.tokens_per_stage,'validation_tokens':len(held),
        'total_stage_exposures':sum(len(s) for s in stages),
        'new_source_tokens':sum(len(s) for s in stages[:4]),
        'stage5_replay':True,'tokenizer_sha256':sha256(tokenfile) if tokenfile.is_file() else None,
        'vocab_size':tok.vocab_size,'provenance':provenance,'sha256':files,
        'warning':'This is a sampled recovery curriculum, NOT the original SmolLM2 training run; honor dataset licenses.'}
    tmp=out/'.manifest.json.partial';tmp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8');os.replace(tmp,out/'manifest.json')
    note('corpus_complete',tokens=sum(len(s) for s in stages),heldout=len(held),manifest=str(out/'manifest.json'))
    return manifest


if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Compile five real-data SmolLM2 recovery streams')
    ap.add_argument('--hf-model',required=True,help='Local Hugging Face model/tokenizer folder')
    ap.add_argument('--output',required=True)
    grp=ap.add_mutually_exclusive_group(required=True)
    grp.add_argument('--download',action='store_true',help='Stream revision-pinned public HF datasets')
    grp.add_argument('--import-dir',help='stage1.txt ... stage5.txt plus validation.txt')
    ap.add_argument('--tokens-per-stage',type=int,default=2_000_000)
    ap.add_argument('--validation-tokens',type=int,default=32768)
    ap.add_argument('--max-rows',type=int,default=750_000)
    ap.add_argument('--seed',type=int,default=20261007)
    ap.add_argument('--overwrite',action='store_true')
    a=ap.parse_args()
    try:build(a)
    except Exception as ex:note('error',message=str(ex));raise
