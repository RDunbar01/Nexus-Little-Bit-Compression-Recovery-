"""Compile downloaded, revision-pinned Parquet shards into the embedded curriculum.
Input downloads/ contains *-info.json from HF APIs and source Parquet files.
This reproducible compiler preserves source provenance and exact tokenizer IDs.
"""
from pathlib import Path
import json,hashlib,argparse
import numpy as np
import pyarrow.parquet as pq
from transformers import AutoTokenizer
from corpus_builder import encode,normalize,interleave,sha256

def compile(source,out,quota=2_000_000):
    source=Path(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    tok=AutoTokenizer.from_pretrained(source,local_files_only=True)
    goals={'dclm_edu':quota*3//5,'fineweb_edu':quota-quota*3//5,'cosmopedia_v2':quota//2,'stack_edu':quota-quota//2,'finemath':quota//2,'infimm_webmath':quota-quota//2}
    pools={k:[] for k in goals};docs={k:0 for k in goals};seen=set()
    for batch in pq.ParquetFile(source/'train-00000-of-00085.parquet').iter_batches(batch_size=256):
        for row in batch.to_pylist():
            k=row['source']
            if k not in goals or len(pools[k])>=goals[k]:continue
            h=hashlib.sha256(normalize(row).encode()).digest()
            if h in seen:continue
            ids=encode(row,tok)
            if not ids:continue
            seen.add(h);pools[k].extend(ids[:goals[k]-len(pools[k])]);docs[k]+=1
        if all(len(pools[k])==goals[k] for k in goals):break
    short={k:goals[k]-len(pools[k]) for k in goals if len(pools[k])<goals[k]}
    if short:raise ValueError(f'Insufficient source tokens: {short}')
    print('pretraining ready',docs,flush=True)
    stages=[interleave([pools[k] for k in keys],quota) for keys in [('dclm_edu','fineweb_edu'),('cosmopedia_v2','stack_edu'),('finemath','infimm_webmath')]]
    instruction=[];ndocs=0
    for batch in pq.ParquetFile(source/'instruction.parquet').iter_batches(batch_size=128):
        for row in batch.to_pylist():
            h=hashlib.sha256(normalize(row).encode()).digest()
            if h in seen:continue
            ids=encode(row,tok,True)
            if not ids:continue
            seen.add(h);instruction.extend(ids[:quota-len(instruction)]);ndocs+=1
            if len(instruction)==quota:break
        if len(instruction)==quota:break
    if len(instruction)!=quota:raise ValueError('Not enough instruction data')
    stages.append(np.asarray(instruction,dtype='<u4'));stages.append(interleave(stages,quota,seed=20261007))
    held=[]
    for row in pq.read_table(source/'validation.parquet').to_pylist():
        if hashlib.sha256(normalize(row).encode()).digest() in seen:continue
        held.extend(encode(row,tok)[:32768-len(held)])
        if len(held)==32768:break
    if len(held)!=32768:raise ValueError('Insufficient heldout data')
    files={}
    for i,ar in enumerate(stages+[held]):
        f=out/(f'stage{i+1}.tokens.bin' if i<5 else 'validation.tokens.bin')
        np.asarray(ar,dtype='<u4').tofile(f);files[f.name]=sha256(f)
    revisions={k:json.loads((source/(k+'-info.json')).read_text())['sha'] for k in ['pretrain','instruction','holdout','tokenizer']}
    manifest={'format':2,'source':'EleutherAI/SmolLM2-135M-10B + HuggingFaceTB/smol-smoltalk', 'tokens_per_stage':quota,'validation_tokens':len(held),'total_stage_exposures':5*quota,'new_source_tokens':4*quota,'stage5_replay':True,'tokenizer_sha256':sha256(source/'tokenizer.json'),'vocab_size':tok.vocab_size,'sha256':files,'provenance':{'revisions':revisions,'source_tokens':goals,'source_documents':docs,'instruction_documents':ndocs,'pretrain_file':'data/train-00000-of-00085.parquet','instruction_file':'data/train-00000-of-00004.parquet','holdout':'Salesforce/wikitext wikitext-2-raw-v1 validation','math_mix':'50% FineMath / 50% InfiMM-WebMath (custom recovery balance)','dedup':'Exact normalized document SHA256 across selected training records and validation; near duplicates not checked','tokenizer':'HuggingFaceTB/SmolLM2-135M-Instruct','instruction_format':'Official tokenizer chat template; all tokens trained, no assistant-only masking'},'warning':'Custom five-stage recovery curriculum; not original pretraining or exact LittleBit experiment. 8M newly selected token positions plus 2M replay. Dataset licenses remain with source owners.'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2),flush=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('source');a.add_argument('output');args=a.parse_args();compile(args.source,args.output)
