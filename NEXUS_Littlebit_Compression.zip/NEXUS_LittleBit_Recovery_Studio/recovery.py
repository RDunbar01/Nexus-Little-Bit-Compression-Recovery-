"""Local five-stage QAT recovery for a LittleBit GGUF produced by NEXUS builder.

All perplexities come from autoregressive next-token NLL on *the same* held-out
uint32 token stream. Exact resume restores optimizer + RNG + window position;
a new cycle starts from a prior checkpoint with new optimizer and NLL baseline.

Requires a locally cached HuggingFace SmolLM2 model, tokenizer and PyTorch.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
import os
import random
import time
import traceback
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from gguf_factors import GGUF, sha256_file

STAGE_NAMES=['General language • DCLM-Edu + FineWeb-Edu',
             'Structured and code • Cosmopedia V2 + Stack-Edu',
             'Mathematics • FineMath + InfiMM-WebMath',
             'Instruction • Smol-SmolTalk', 'Consolidation • mixed replay']
MAX_EXPOSURES=100_000_000_000

class SmoothSign(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x):
        ctx.save_for_backward(x)
        return torch.where(x>=0,torch.ones_like(x),-torch.ones_like(x))
    @staticmethod
    def backward(ctx,grad):
        (x,)=ctx.saved_tensors
        slope=100.0
        return grad*(slope*(1-torch.tanh(slope*x).square()))

class FactorPath(nn.Module):
    """Binary signs + h,g,l scales. FP16 rounding in forward matches packed export."""
    def __init__(self,p):
        super().__init__()
        self.u=nn.Parameter(torch.from_numpy(p['u'].copy()).float()*0.01)
        self.v=nn.Parameter(torch.from_numpy(p['v'].copy()).float()*0.01)
        self.h=nn.Parameter(torch.from_numpy(p['h'].copy()).float())
        self.g=nn.Parameter(torch.from_numpy(p['g'].copy()).float())
        self.l=nn.Parameter(torch.from_numpy(p['l'].copy()).float())
    @staticmethod
    def round_half(v):
        # Numerical correspondence with stored FP16 parameters. FP16 may overflow;
        # fail the export if values are nonfinite.
        r=v.to(torch.float16).to(torch.float32)
        return v + (r-v).detach()
    def forward(self,x):
        g,h,l=[self.round_half(z).to(x.dtype) for z in (self.g,self.h,self.l)]
        v=SmoothSign.apply(self.v).to(x.dtype)
        u=SmoothSign.apply(self.u).to(x.dtype)
        x=F.linear(x*g,v)
        return F.linear(x*l,u)*h
    @torch.no_grad()
    def packed(self):
        p={}
        for k in ('u','v'):
            raw=getattr(self,k).detach().cpu().numpy(); p[k]=np.where(raw>=0,1.,-1.).astype(np.float32)
        for k in ('h','g','l'):
            raw=getattr(self,k).detach().cpu().numpy()
            if not np.isfinite(raw).all() or abs(raw).max(initial=0)>65504: raise ValueError('Invalid FP16 export scale')
            p[k]=raw.astype('<f2')
        return p

class Factors(nn.Module):
    def __init__(self,paths):
        super().__init__()
        self.paths=nn.ModuleList(FactorPath(x) for x in paths)
        if not self.paths: raise ValueError('Empty factor path')
        self.out_features=self.paths[0].h.numel()
        self.in_features=self.paths[0].g.numel()
    def forward(self,x):
        s=None
        for p in self.paths:
            y=p(x)
            s=y if s is None else s+y
        return s
    def packed(self): return [p.packed() for p in self.paths]

class LBLinear(nn.Module):
    def __init__(self,fx,n_heads=0):
        super().__init__(); self.factor=fx; self.n_heads=n_heads
    def forward(self,x):
        y=self.factor(x)
        if self.n_heads:
            hd=self.factor.out_features//self.n_heads
            if hd%2: raise ValueError('RoPE q/k output incompatible')
            # Convert GGUF llama.cpp Q/K row-permuted coordinates to HF order.
            shape=y.shape[:-1]
            y=y.reshape(*shape,self.n_heads,hd//2,2)
            y=y.transpose(-1,-2).reshape(*shape,self.factor.out_features)
        return y

class LBEmbedding(nn.Module):
    def __init__(self,fx):
        super().__init__(); self.factor=fx
        self.num_embeddings=fx.out_features; self.embedding_dim=fx.in_features
    def forward(self,ids):
        # Only reconstruct requested rows of U. Avoid a full vocab x hidden matrix.
        result=None
        for p in self.factor.paths:
            us=SmoothSign.apply(p.u)[ids]
            vs=SmoothSign.apply(p.v)
            h=FactorPath.round_half(p.h)[ids]
            g=FactorPath.round_half(p.g)
            l=FactorPath.round_half(p.l)
            e=torch.matmul(us*l,vs)*h.unsqueeze(-1)*g
            result=e if result is None else result+e
        return result

class LBHead(nn.Module):
    def __init__(self,fx): super().__init__(); self.factor=fx
    def forward(self,x): return self.factor(x)

NAME_MAP={'attn_q':'self_attn.q_proj','attn_k':'self_attn.k_proj',
          'attn_v':'self_attn.v_proj','attn_output':'self_attn.o_proj',
          'ffn_gate':'mlp.gate_proj','ffn_up':'mlp.up_proj','ffn_down':'mlp.down_proj'}

def _unpermute_weights(W,n_heads):
    hd=W.shape[0]//n_heads
    if W.shape[0]%n_heads or hd%2: raise ValueError('Bad Q/K head dimensions')
    return W.reshape(n_heads,hd//2,2,-1).transpose(0,2,1,3).reshape(W.shape)

def hf_module(model,name):
    """Map GGUF name to Llama HF dotted module name."""
    import re
    m=re.fullmatch(r'blk\.(\d+)\.([a-z_]+)\.weight',name)
    if m:
        idx,part=m.groups()
        if part in NAME_MAP: return f'model.layers.{idx}.{NAME_MAP[part]}'
        if part=='attn_norm': return f'model.layers.{idx}.input_layernorm'
        if part=='ffn_norm': return f'model.layers.{idx}.post_attention_layernorm'
    return {'token_embd.weight':'model.embed_tokens','output.weight':'lm_head',
            'output_norm.weight':'model.norm'}.get(name)

def _nested_get(obj,route):
    for component in route.split('.'):
        obj=getattr(obj,component) if not component.isdecimal() else obj[int(component)]
    return obj

def _nested_set(obj,route,child):
    items=route.split('.'); parent=_nested_get(obj,'.'.join(items[:-1])) if len(items)>1 else obj
    setattr(parent,items[-1],child)

def load_q8_teacher(model,q8_file):
    """Overwrite HF model weights with original Q8 GGUF, strictly checking shapes.
    Uses HF config/tokenizer for the graph, Q8 tensor payload for numeric baseline.
    """
    import re
    n_assigned=0; missing=[]
    with GGUF(q8_file) as q:
        if q.metadata.get('general.architecture')!='llama': raise ValueError('Expected llama GGUF')
        for name in q.tensors:
            route=hf_module(model,name)
            if not route: continue
            try: target=_nested_get(model,route)
            except (KeyError,AttributeError,IndexError): missing.append(name); continue
            w=q.array(name).astype(np.float32)
            if re.search(r'\.attn_[qk]\.weight$',name):
                heads=model.config.num_attention_heads if '.attn_q.' in name else model.config.num_key_value_heads
                w=_unpermute_weights(w,heads)
            if tuple(target.weight.shape)!=tuple(w.shape):
                raise ValueError(f'GGUF/HF tensor shape mismatch {name}: {w.shape} / {tuple(target.weight.shape)}')
            with torch.no_grad(): target.weight.copy_(torch.from_numpy(w).to(target.weight.dtype))
            n_assigned+=1
        if missing: raise ValueError('Unknown HF mapping for Q8 source: '+repr(missing[:10]))
        expected={'token_embd.weight','output_norm.weight'}
        for i in range(model.config.num_hidden_layers):
            expected.update(f'blk.{i}.{field}.weight' for field in
                ('attn_q','attn_k','attn_v','attn_output','ffn_gate','ffn_up','ffn_down','attn_norm','ffn_norm'))
        absent=expected-set(q.tensors)
        if absent:raise ValueError('Incomplete original Q8 source: '+repr(sorted(absent)[:12]))
    if n_assigned<10: raise ValueError('Insufficient Q8 weights mapped; refusing to label as Q8 baseline')
    return n_assigned

def apply_littlebit(student, factor_gguf):
    mapping={}; shared=None
    with GGUF(factor_gguf) as gg:
        names=gg.factor_names()
        if not names: raise ValueError('No LittleBit factor matrices found')
        for name in names:
            route=hf_module(student,name)
            if not route: raise ValueError('Unknown factor mapping: '+name)
            ps=gg.factor(name)
            if not ps: raise ValueError('Missing factors: '+name)
            fx=Factors(ps)
            orig=_nested_get(student,route)
            m,n=fx.out_features,fx.in_features
            if name=='token_embd.weight':
                if tuple(orig.weight.shape)!=(m,n): raise ValueError('Embedding shape mismatch')
                shared=fx
                _nested_set(student,route,LBEmbedding(fx))
                if getattr(student.config,'tie_word_embeddings',False):
                    _nested_set(student,'lm_head',LBHead(fx))
            elif name=='output.weight':
                if getattr(student.config,'tie_word_embeddings',False) and shared is not None:
                    raise ValueError('Tied output and embedding cannot use independently factorized tensors')
                if tuple(orig.weight.shape)!=(m,n): raise ValueError('Head shape mismatch')
                _nested_set(student,route,LBHead(fx))
            else:
                if tuple(orig.weight.shape)!=(m,n): raise ValueError(f'Linear shape mismatch: {name}')
                head=0
                if name.endswith('.attn_q.weight'): head=student.config.num_attention_heads
                if name.endswith('.attn_k.weight'): head=student.config.num_key_value_heads
                _nested_set(student,route,LBLinear(fx,head))
            mapping[name]=fx
    return mapping


def build_networks(recipe,device):
    try: from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as e: raise RuntimeError('Install requirements.txt to enable real-model QAT') from e
    local=recipe['hf_model']
    if not Path(local).is_dir(): raise ValueError('hf_model must be a local model/tokenizer folder (offline mode)')
    teacher=AutoModelForCausalLM.from_pretrained(local,torch_dtype=torch.float32,local_files_only=True)
    tokenizer=AutoTokenizer.from_pretrained(local,local_files_only=True,use_fast=True)
    if teacher.config.model_type!='llama': raise ValueError('Expected SmolLM2 Llama-type model')
    if tokenizer.vocab_size > teacher.config.vocab_size: raise ValueError('Tokenizer exceeds vocabulary')
    source=recipe.get('q8_gguf')
    if not source: raise ValueError('Original Q8 GGUF required for honest 3-way perplexity')
    if source:
        load_q8_teacher(teacher,source)
        baseline_label='Original Q8_0 GGUF in HF graph'
    else: baseline_label='Original HF teacher (not Q8)'
    student=copy.deepcopy(teacher)
    mapping=apply_littlebit(student,recipe['factor_gguf'])
    teacher.eval().requires_grad_(False)
    student.requires_grad_(False)
    # Only factor parameters train; norms + non-factor tensors remain fixed.
    for fx in set(mapping.values()): fx.requires_grad_(True)
    teacher.to(device);student.to(device)
    teacher.config.use_cache=False;student.config.use_cache=False
    return teacher,student,tokenizer,mapping,baseline_label


def corpus_info(recipe):
    corpus=Path(recipe['corpus_dir']).expanduser().resolve()
    if not corpus.is_dir(): raise FileNotFoundError(f'Corpus directory missing: {corpus}')
    files=[corpus/f'stage{i}.tokens.bin' for i in range(1,6)]+[corpus/'validation.tokens.bin']
    for f in files:
        if not f.is_file() or f.stat().st_size<8 or f.stat().st_size%4: raise ValueError('Missing/incomplete token stream: '+str(f))
    arrays=[np.memmap(f,dtype='<u4',mode='r') for f in files]
    meta=corpus/'manifest.json'
    if meta.exists():
        data=json.loads(meta.read_text(encoding='utf-8'))
        for f in files:
            expected=data.get('sha256',{}).get(f.name)
            if expected and sha256_file(f)!=expected: raise ValueError('Corpus SHA256 mismatch: '+f.name)
    return arrays, {f.name:sha256_file(f) for f in files}


def perplexity(model,heldout,device,seq_len=128,max_tokens=32768):
    """True next-token teacher-forced perplexity with identical windows and labels."""
    model.eval(); nll=0.; targets=0
    upto=min(len(heldout),max_tokens)
    with torch.inference_mode():
        # Non-overlapping strides, one overlap input token to score each target.
        for st in range(0,upto-1,seq_len):
            en=min(st+seq_len+1,upto)
            if en-st<2: break
            ids=torch.tensor(np.asarray(heldout[st:en],dtype=np.int64).copy(),dtype=torch.long,device=device)[None,:]
            logits=model(input_ids=ids,use_cache=False).logits
            loss=F.cross_entropy(logits[:,:-1,:].float().reshape(-1,logits.size(-1)),ids[:,1:].reshape(-1),reduction='sum')
            nll+=loss.item(); targets+=ids.numel()-1
    if targets<2: raise ValueError('Too few held-out next-token labels')
    nll/=targets
    # JSON has no portable Infinity value; preserve the real NLL on overflow.
    return {'nll':nll,'ppl':float(math.exp(nll)) if nll<700 else None,'tokens':targets}


def fingerprint(recipe):
    paths={'factor_gguf':recipe['factor_gguf']}
    if recipe.get('q8_gguf'): paths['q8_gguf']=recipe['q8_gguf']
    # Local Hugging Face model identity: hash config and weight manifests, not 500 MB each run.
    for name in ('config.json','tokenizer.json','tokenizer.model','model.safetensors.index.json'):
        f=Path(recipe['hf_model'])/name
        if f.exists(): paths[name]=str(f)
    return {k:sha256_file(v) for k,v in paths.items()}


def start_rng(seed):
    random.seed(seed);np.random.seed(seed%(2**32));torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)

def rng_state():
    return {'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),
            'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}

def load_rng(d):
    random.setstate(d['python']); np.random.set_state(d['numpy']);torch.set_rng_state(d['torch'])
    if torch.cuda.is_available() and d.get('cuda') is not None:torch.cuda.set_rng_state_all(d['cuda'])

def atomic_save(state,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.partial')
    torch.save(state,tmp)
    os.replace(tmp,path)

def emit(run,kind,**data):
    line={'ts':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'event':kind,**data}
    print(json.dumps(line,allow_nan=False),flush=True)
    with (run/'events.jsonl').open('a',encoding='utf8') as f: f.write(json.dumps(line,allow_nan=False)+'\n')

def compare_fingerprint(old,new):
    if old!=new: raise ValueError('Model or tokenizer identity mismatch with checkpoint')

def checkpoint_record(run,student,optimizer,steps,stage,stage_pos,exposures,pre,baseline,recipe,source_fp,corpus_fp,keep=5):
    # Store only learned low-rank factors. Dense Q8 model weights are immutable and
    # rebuilt from the source GGUF on resume; this avoids multi-gigabyte checkpoints.
    factors={k:v for k,v in student.state_dict().items() if '.factor.paths.' in k}
    if not factors:raise ValueError('No trainable LittleBit factors for checkpoint')
    state={'format':3,'factor_state':factors, 'optimizer':optimizer.state_dict(),
           'steps':steps,'stage':stage,'stage_pos':stage_pos,'exposures':exposures,
           'rng':rng_state(),'pre':pre,'baseline':baseline,'recipe':recipe,
           'source_fp':source_fp,'corpus_fp':corpus_fp}
    latest=run/'latest.pt'; atomic_save(state,latest)
    if steps==0 or steps%int(recipe['checkpoint_every'])==0:
        num=run/f'checkpoint-{steps:09d}.pt'
        atomic_save(state,num)
        older=sorted(run.glob('checkpoint-*.pt'))
        if len(older)>keep:
            for x in older[1:-keep]: x.unlink(missing_ok=True)
    emit(run,'checkpoint',steps=steps,exposures=exposures,path=str(latest))


def _window(arr,index,seq):
    if len(arr)<seq: raise ValueError('Training stage corpus shorter than sequence length')
    # deterministic cyclic stride: data recycling is explicit in metrics
    positions=max(1,len(arr)-seq+1)
    start=(index*seq)%positions
    return np.asarray(arr[start:start+seq],dtype=np.int64).copy()

def train_loss(teacher,student,inputs,stage,hidden_ids,temperature=1.0):
    with torch.no_grad():
        t=teacher(input_ids=inputs,output_hidden_states=True,use_cache=False)
    s=student(input_ids=inputs,output_hidden_states=True,use_cache=False)
    sl=s.logits.float();tl=t.logits.float()
    kl=F.kl_div(F.log_softmax(sl/temperature,dim=-1),F.softmax(tl/temperature,dim=-1),reduction='batchmean')
    # Normalize by sequence length because batchmean only divides by batch size.
    kl=kl/sl.size(1)*(temperature*temperature)
    hid=[]
    for i in hidden_ids:
        a=s.hidden_states[i].float();b=t.hidden_states[i].float()
        # Normalize MSE by teacher hidden variance to reduce layer scale skew.
        hid.append((a-b).square().mean() / b.square().mean().clamp(min=1e-4))
    h=torch.stack(hid).mean() if hid else kl*0
    ce=F.cross_entropy(sl[:,:-1,:].reshape(-1,sl.size(-1)),inputs[:,1:].reshape(-1))
    # Five-stage adaptation: stages 1/2 pure KD + hidden alignment, 3/4/5 CE mix.
    weight=0.2 if stage>=2 else 0.0
    loss=kl+10.0*h+weight*ce
    return loss,{'kl':float(kl.detach()),'hidden':float(h.detach()),'ce':float(ce.detach())}


def run(recipe):
    recipe=dict(recipe)
    mode=recipe.get('mode','new')
    if mode not in ('new','resume','cycle'): raise ValueError('mode must be new/resume/cycle')
    recipe.setdefault('batch_size',1)
    recipe.setdefault('checkpoint_every',25)
    recipe.setdefault('retain',5)
    recipe.setdefault('lr_schedule','cosine')
    recipe.setdefault('warmup_ratio',0.02)
    if recipe['lr_schedule'] not in ('cosine','constant'):raise ValueError('Unknown LR schedule')
    if not 0<=float(recipe['warmup_ratio'])<1:raise ValueError('warmup_ratio outside [0,1)')
    if not 1 <= int(recipe['batch_size']) <= 32: raise ValueError('batch_size outside 1..32')
    if not 1 <= int(recipe['retain']) <= 100: raise ValueError('retain outside 1..100')
    target=int(recipe.get('budget_tokens',10_000_000)); seq=int(recipe.get('seq_len',128))
    if target<10 or target>MAX_EXPOSURES: raise ValueError('Token budget outside 10..100,000,000,000')
    if seq<8 or seq>2048: raise ValueError('Sequence length must be 8..2048')
    if int(recipe.get('checkpoint_every',25))<1: raise ValueError('Checkpoint interval must be positive')
    recipe['checkpoint_every']=int(recipe.get('checkpoint_every',25))
    recipe['budget_tokens']=target; recipe['seq_len']=seq
    recipe['batch_size']=int(recipe.get('batch_size',1))
    if recipe['batch_size']<1 or recipe['batch_size']>32: raise ValueError('batch_size 1..32')
    seed=int(recipe.get('seed',20261007));start_rng(seed)
    run_dir=Path(recipe['output_dir']).expanduser().resolve();run_dir.mkdir(parents=True,exist_ok=True)
    marker=run_dir/'recipe.json'
    if mode!='resume' and marker.exists():raise FileExistsError('Output folder already has a run; use new empty folder or exact resume')
    stopfile=run_dir/'STOP';stopfile.unlink(missing_ok=True)
    device=recipe.get('device','auto')
    if device=='auto': device='cuda' if torch.cuda.is_available() else 'cpu'
    if device=='cuda' and not torch.cuda.is_available(): raise ValueError('CUDA/ROCm torch unavailable')
    if device=='cuda':
        try:
            xx=torch.ones((32,32),device='cuda',dtype=torch.float32)
            zz=xx@xx
            torch.cuda.synchronize()
            if not torch.isfinite(zz).all().item():raise ValueError('GPU matmul returned nonfinite')
        except Exception as exc:raise RuntimeError('Torch accelerator failed real FP32 matmul: '+str(exc)) from exc
    if device not in ('cpu','cuda'): raise ValueError('device must be auto, cpu, or cuda')
    arrays,corpus_fp=corpus_info(recipe)
    t0=time.monotonic(); emit(run_dir,'loading',device=device,mode=mode)
    teacher,student,tok,mapping,baseline_label=build_networks(recipe,device)
    for a in arrays:
        if a.max(initial=0)>=student.config.vocab_size: raise ValueError('Corpus token ID >= model vocab; check tokenizer provenance')
    manifest=Path(recipe['corpus_dir'])/'manifest.json'
    if manifest.exists():
        expected=json.loads(manifest.read_text()).get('tokenizer_sha256')
        tokenfile=Path(recipe['hf_model'])/'tokenizer.json'
        if expected and (not tokenfile.is_file() or sha256_file(tokenfile)!=expected):
            raise ValueError('Corpus tokenizer SHA256 does not match model tokenizer')
    source_fp=fingerprint(recipe)
    ckpt=None; steps=0; stage=0; stage_pos=0; exposures=0
    if mode in ('resume','cycle'):
        source=Path(recipe['checkpoint']).expanduser().resolve()
        if not source.is_file(): raise FileNotFoundError(source)
        # `weights_only=False` is intentional for our own signed/local checkpoint;
        # never load checkpoints from untrusted sources.
        ckpt=torch.load(source,map_location='cpu',weights_only=False)
        if ckpt.get('format') not in (2,3): raise ValueError('Unrecognized recovery checkpoint format')
        compare_fingerprint(ckpt['source_fp'],source_fp)
        compare_fingerprint(ckpt['corpus_fp'],corpus_fp)
        if ckpt['format']==2:
            student.load_state_dict(ckpt['student'],strict=True)
        else:
            expected={k for k in student.state_dict() if '.factor.paths.' in k}
            if set(ckpt['factor_state'])!=expected:
                raise ValueError('Factor-only checkpoint incompatible with model architecture')
            result=student.load_state_dict(ckpt['factor_state'],strict=False)
            if result.unexpected_keys:raise ValueError('Unexpected factor keys in checkpoint')
        if mode=='resume':
            old=ckpt['recipe']
            old.setdefault('lr_schedule','constant')
            old.setdefault('warmup_ratio',0.02)
            immutable=('factor_gguf','q8_gguf','hf_model','corpus_dir','budget_tokens','seq_len','batch_size','seed','device','lr','validation_tokens','lr_schedule','warmup_ratio')
            for k in immutable:
                if str(old.get(k))!=str(recipe.get(k)):
                    raise ValueError('Exact resume configuration changed: '+k)
            if source.parent!=run_dir: raise ValueError('Exact resume must use the original run folder')
            steps=int(ckpt['steps']);stage=int(ckpt['stage']);stage_pos=int(ckpt['stage_pos']);exposures=int(ckpt['exposures'])
            if marker.exists() is False: raise ValueError('Missing run recipe.json')
    student.train()
    optim=torch.optim.Adam((p for p in student.parameters() if p.requires_grad),lr=float(recipe.get('lr',3e-5)),betas=(0.9,0.999))
    if mode=='resume':
        optim.load_state_dict(ckpt['optimizer']);load_rng(ckpt['rng'])
        # use initial PPL recorded at run start for the same heldout corpus
        pre=ckpt['pre'];baseline=ckpt['baseline']
    else:
        # Both teacher and compressed student measured, not extrapolated.
        validation=arrays[-1]
        baseline=perplexity(teacher,validation,device,seq_len=min(seq,512),max_tokens=int(recipe.get('validation_tokens',32768)))
        pre=perplexity(student,validation,device,seq_len=min(seq,512),max_tokens=int(recipe.get('validation_tokens',32768)))
        student.train()
        marker.write_text(json.dumps(recipe,indent=2)+'\n')
        checkpoint_record(run_dir,student,optim,0,0,0,0,pre,baseline,recipe,source_fp,corpus_fp,int(recipe.get('retain',5)))
    emit(run_dir,'baseline',baseline_label=baseline_label,baseline=baseline,pre=pre,mode=mode,
         new_cycle=(mode=='cycle'),parent_checkpoint=recipe.get('checkpoint') if mode=='cycle' else None)
    stage_budgets=[target//5+(1 if i<target%5 else 0) for i in range(5)]
    if any(n<seq for n in stage_budgets):raise ValueError('Each stage needs at least one sequence; increase budget or lower seq_len')
    history=[]; hidden_count=student.config.num_hidden_layers
    hidden_ids=sorted(set([max(1,hidden_count//4),max(1,hidden_count//2),hidden_count]))
    for si in range(stage,5):
        budget=stage_budgets[si]; pos=stage_pos if si==stage else 0
        emit(run_dir,'stage_start',stage=si+1,name=STAGE_NAMES[si],budget=budget,position=pos)
        while pos<budget:
            if stopfile.exists():
                checkpoint_record(run_dir,student,optim,steps,si,pos,exposures,pre,baseline,recipe,source_fp,corpus_fp,int(recipe.get('retain',5)))
                emit(run_dir,'paused',stage=si+1,exposures=exposures)
                return {'status':'paused','exposures':exposures}
            batch=[]
            capacity=min(recipe['batch_size'],max(1,(budget-pos)//seq))
            remaining=budget-pos
            length=min(seq,remaining//capacity)
            if length<2:
                # Count only tokens used in real forward passes, never invent an exposure.
                break
            index=pos//seq
            for k in range(capacity):batch.append(_window(arrays[si],index+k,length))
            ids=torch.tensor(np.stack(batch),device=device,dtype=torch.long)
            # Token-progress schedule is deterministic across exact resumes.
            if recipe.get('lr_schedule','cosine')=='cosine':
                warmup=max(1,int(target*float(recipe.get('warmup_ratio',0.02))))
                progress=min(1.,max(0.,(exposures-warmup)/max(1,target-warmup)))
                multiplier=(exposures+capacity*length)/warmup if exposures<warmup else 0.5*(1+math.cos(math.pi*progress))
                for group in optim.param_groups:group['lr']=float(recipe.get('lr',3e-5))*min(1.,multiplier)
            optim.zero_grad(set_to_none=True)
            loss,parts=train_loss(teacher,student,ids,si,hidden_ids)
            if not torch.isfinite(loss).item(): raise FloatingPointError('Nonfinite QAT loss; checkpoint retained')
            loss.backward();torch.nn.utils.clip_grad_norm_((p for p in student.parameters() if p.requires_grad),1.)
            optim.step()
            # Stable training masters; exported representation remains binary + FP16.
            with torch.no_grad():
                for fx in set(mapping.values()):
                    for path in fx.paths:
                        path.u.clamp_(-0.05,0.05);path.v.clamp_(-0.05,0.05)
            actual=capacity*length;pos+=actual;exposures+=actual;steps+=1
            if steps % int(recipe.get('log_every',5))==0 or pos>=budget:
                emit(run_dir,'progress',stage=si+1,steps=steps,stage_tokens=pos,stage_budget=budget,
                     exposures=exposures,total_target=target,loss=float(loss.detach()),**parts,
                     reuse=round(exposures/sum(len(x) for x in arrays[:5]),5))
            if steps % recipe['checkpoint_every']==0:
                checkpoint_record(run_dir,student,optim,steps,si,pos,exposures,pre,baseline,recipe,source_fp,corpus_fp,int(recipe.get('retain',5)))
        if pos<budget:
            emit(run_dir,'unspent_tail',stage=si+1,remaining=budget-pos)
        stage_pos=0
        checkpoint_record(run_dir,student,optim,steps,si+1,0,exposures,pre,baseline,recipe,source_fp,corpus_fp,int(recipe.get('retain',5)))
        emit(run_dir,'stage_end',stage=si+1,exposures=exposures)
    post=perplexity(student,arrays[-1],device,seq_len=min(seq,512),max_tokens=int(recipe.get('validation_tokens',32768)))
    student.eval()
    destination=run_dir/'recovered.lb.gguf'
    packed={name:fx.packed() for name,fx in mapping.items()}
    report={'status':'complete','baseline_label':baseline_label,'original_baseline':baseline,
        'pre':pre,'post':post,'exposures':exposures,'requested_exposures':target,
        'reuse_factor':exposures/sum(len(x) for x in arrays[:5]), 'steps':steps,
        'stage_names':STAGE_NAMES,'source_sha256':source_fp,'corpus_sha256':corpus_fp,
        'holdout_file':str(Path(recipe['corpus_dir'])/'validation.tokens.bin'),
        'holdout_tokens':post['tokens'],'checkpoint':str(run_dir/'latest.pt'),
        'mode':mode,'parent_checkpoint':recipe.get('checkpoint') if mode=='cycle' else None,
        'parent_checkpoint_sha256':sha256_file(recipe['checkpoint']) if mode=='cycle' else None,
        'seconds':round(time.monotonic()-t0,3),'passed_2x_baseline':bool(post['ppl'] is not None and baseline['ppl'] is not None and post['ppl'] <= 2*baseline['ppl']),
        'checkpoint_format':3}
    with GGUF(recipe['factor_gguf']) as gg:
        report['recovered_file_sha256']=gg.rewrite_with_factors(destination,packed,{'report':'report.json', 'mode':mode})
    report['recovered_file']=str(destination)
    (run_dir/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    emit(run_dir,'complete',baseline=baseline,pre=pre,post=post,exposures=exposures,report=str(run_dir/'report.json'))
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--recipe',required=True)
    ns=parser.parse_args()
    try:
        answer=run(json.loads(Path(ns.recipe).read_text(encoding='utf-8')))
        print(json.dumps({'result':answer['status']},allow_nan=False),flush=True)
    except Exception as exc:
        traceback.print_exc()
        print(json.dumps({'error':str(exc)}),flush=True)
        raise
