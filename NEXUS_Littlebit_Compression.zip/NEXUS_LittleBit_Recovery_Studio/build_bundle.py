from pathlib import Path
import re,json,hashlib
R=Path(__file__).parent
p=R/'Nexus_Web_LLM.html';s=p.read_text()
# Replace extension in place, so rebuilding never duplicates code.
s=re.sub(r'<script>/\* SmolLM2 ChatML, LittleBit packed-factor inference.*?</script>',lambda m:'<script>'+ (R/'smol_integration.js').read_text()+'</script>',s,flags=re.S)
s=re.sub(r'<!-- NEXUS_QAT_BEGIN -->.*?<!-- NEXUS_QAT_END -->','',s,flags=re.S)
studio_path=R/'NEXUS_LittleBit_Recovery_Studio.html'
if not studio_path.exists():studio_path=R.parent/'studio/NEXUS_LittleBit_Recovery_Studio/NEXUS_LittleBit_Recovery_Studio.html'
studio=studio_path.read_text()
corpus='\n'.join(re.findall(r'<script id="nexus-corpus-manifest".*?</script>|<script src="\./nexus_corpus_payload\.js"></script>',studio,re.S))
if 'nexus_corpus_payload.js' not in corpus:raise ValueError('Shared corpus reference missing from Studio')
fingerprint='ecc2f33f7cdf683196646ea97b005f82398e5ddbb0e143fbe95a402277eb1788'
ui='''<style>
#qatPanel{position:fixed;inset:12px;z-index:1000;overflow:auto;background:#101722;color:#e6edf3;border:1px solid #52647b;border-radius:14px;padding:22px;font:15px/1.5 system-ui,sans-serif;box-sizing:border-box}
#qatPanel *{box-sizing:border-box}#qatPanel h2{margin:0;font-size:23px}#qatPanel h3{margin:16px 0 8px}#qatPanel p{color:#b9c9dd}
#qatPanel button,#qatPanel input,#qatPanel select{font:inherit;color:#edf5ff;background:#223147;border:1px solid #60748e;border-radius:7px;padding:9px;max-width:100%;min-width:0;opacity:1}
#qatPanel button{cursor:pointer}#qatPanel button:disabled{background:#26303e;color:#9ba9bc;cursor:not-allowed}#qatPanel #qatStart{background:#176bce;color:white;font-weight:700}#qatPanel input[type=file]{display:block;width:100%}#qatPanel input::file-selector-button{background:#355983;color:white;border:0;padding:7px;border-radius:4px;margin-right:8px}
#qatPanel label{display:flex;flex-direction:column;gap:7px;min-width:0}#qatPanel .qatGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:18px}#qatPanel .qatActions{position:sticky;bottom:0;background:#101722;padding:14px 0;display:flex;gap:10px;flex-wrap:wrap;border-top:1px solid #52647b}
#qatPanel .qatStatus{background:#172d46;border:1px solid #4879aa;border-radius:9px;padding:14px;margin:16px 0}#qatPanel #qatProgress{color:#ffffff;font-weight:600;white-space:pre-wrap;margin:0}#qatPanel progress{width:100%;height:14px;margin-top:10px}#qatPanel pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#17202d;padding:12px;border-radius:8px;max-height:230px;overflow:auto}#qatPanel .qatMetrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}#qatPanel .qatMetric{padding:12px;border:1px solid #52647b;border-radius:8px}#qatPanel .qatMetric strong{display:block;font-size:22px}#qatPanel summary{cursor:pointer;color:#83c6ff}
</style><section id="qatPanel" style="display:none" aria-label="Browser recovery">
<div style="display:flex;justify-content:space-between;gap:12px"><h2>Recover your compressed model</h2><button onclick="document.getElementById('qatPanel').style.display='none'">Close</button></div>
<p>1. Choose both models. 2. Keep New recovery selected. 3. Click Start recovery below. The 10M-token corpus is already included. Use a fresh page without a chat model loaded.</p>
<div class="qatStatus" role="status" aria-live="polite"><div id="qatProgress">Choose your original Q8 and compressed .lb.gguf to begin.</div><div id="qatMemoryStatus"></div><progress id="qatBar" value="0" max="100"></progress></div>
<h3>1 · Select files</h3><div class="qatGrid">
<label>Original Q8 GGUF (teacher)<input id="qatTeacher" type="file" accept=".gguf"></label>
<label>Compressed .lb.gguf (student)<input id="qatStudent" type="file" accept=".gguf"></label>
<label>Mode<select id="qatMode"><option value="new">New recovery</option><option value="resume">Resume checkpoint</option><option value="cycle">Another cycle from checkpoint</option></select></label>
<label>Checkpoint (only for resume / another cycle)<input id="qatCheckpoint" type="file" accept=".nqat"></label>
<label>Training budget (million token exposures)<input id="qatBudget" type="number" value="10" min="0.001" max="100000" step="0.001"></label></div>
<details style="margin:18px 0"><summary>Advanced training settings</summary><div class="qatGrid" style="margin-top:14px">
<label>Sequence length<select id="qatSeq"><option>16</option><option selected>32</option><option>64</option><option>128</option><option>256</option></select></label>
<label>Learning rate<input id="qatLR" type="number" value="0.00003" min="0.0000001" max="0.001" step="0.000001"></label>
<label>Training allocation ceiling (MiB)<input id="qatMemory" type="number" value="4096" min="512" max="16384" step="256"></label>
<label>Evaluation token cap<input id="qatEvalTokens" type="number" value="1024" min="8" max="32768"></label></div><p>Training masters and optimizer state use more memory than the packed model. Save checkpoints during long runs. Full recovery quality and GPU throughput remain unverified.</p></details>
<h3>2 · Perplexity results (lower is better)</h3><div id="qatMetricCards" class="qatMetrics"></div><details><summary>Metric details</summary><pre id="qatMetrics"></pre></details>
<h3>Activity log</h3><pre id="qatLog">Ready. No recovery has started.\n</pre>
<div class="qatActions"><button id="qatStart" disabled>Start recovery</button><button id="qatStop" disabled>Stop after current step</button><button id="qatReset" type="button" title="Discards unsaved training state. Save a checkpoint first.">Reset / change settings</button><button id="qatSave" disabled>Save checkpoint</button><button id="qatExport" disabled>Export packed GGUF</button></div></section>'''

s=s.replace('<div class="topR">','''<div class="topR"><button id="openQAT" onclick="document.getElementById('qatPanel').style.display='block'">Recovery</button>''',1) if 'id="openQAT"' not in s else s
block='<!-- NEXUS_QAT_BEGIN -->'+ui+corpus+'<script id="nexus-tokenizer-check" type="application/json">'+json.dumps({'vocabHash':fingerprint})+'</script>'
for file in ['webgpu_autograd.js','browser_recovery.js']:block+='<script>'+ (R/file).read_text()+'</script>'
block+='<!-- NEXUS_QAT_END -->';s=s.replace('</body>',block+'</body>');p.write_text(s)
print('Bundle bytes:',p.stat().st_size,'vocabulary fingerprint:',fingerprint)
