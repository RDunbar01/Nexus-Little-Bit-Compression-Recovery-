"""Local-only HTTP bridge for recovery + corpus jobs. No cloud inference service.
Run `python launch.py`, then open http://127.0.0.1:8765.
"""
from __future__ import annotations
import argparse
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import platform
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser

ROOT=Path(__file__).resolve().parent
HTML=ROOT/'NEXUS_LittleBit_Recovery_Studio.html'
MAX_JOB_JSON=1_000_000

def app_path(value):
    path=Path(value).expanduser()
    return (path if path.is_absolute() else ROOT/path).resolve()


class Jobs:
    def __init__(self):
        self.lock=threading.Lock();self.proc=None;self.kind=None;self.run=None;self.logfile=None
        self.pid=None;self.created=None;self.compressed_output=None
    def running(self):return bool(self.proc and self.proc.poll() is None)
    def start(self,kind,args,run=None):
        with self.lock:
            if self.running():raise ValueError('A local recovery/corpus job is already running')
            self.kind=kind;self.run=app_path(run) if run else None;self.compressed_output=None
            if self.run:self.run.mkdir(parents=True,exist_ok=True)
            logdir=self.run if self.run else ROOT/'corpus'
            logdir.mkdir(parents=True,exist_ok=True)
            self.logfile=logdir/f'{kind}-console.jsonl'
            logfile=open(self.logfile,'ab',buffering=0)
            try:
                self.proc=subprocess.Popen([sys.executable,*args],cwd=ROOT,stdout=logfile,stderr=subprocess.STDOUT)
            finally:logfile.close()
            self.created=time.time();self.pid=self.proc.pid
            return self.pid
    def stop(self):
        with self.lock:
            if not self.running():raise ValueError('No active job')
            if self.kind=='recovery':
                (self.run/'STOP').touch()
                return 'Cooperative checkpoint request created. Run will stop after the next update.'
            # Dataset iterator may be blocked on remote retrieval; terminate it.
            self.proc.terminate()
            return 'Compression/corpus process termination requested. Partial output is not marked complete.'
    def status(self):
        with self.lock:
            code=self.proc.poll() if self.proc else None
            events=[]
            if self.logfile and self.logfile.is_file():
                # Avoid loading entire multi-billion-exposure log into memory.
                with self.logfile.open('rb') as f:
                    f.seek(0,os.SEEK_END);end=f.tell();f.seek(max(0,end-120_000))
                    for line in f.read().decode('utf8','replace').splitlines()[-55:]:
                        try:events.append(json.loads(line))
                        except ValueError:events.append({'event':'log','message':line[-1000:]})
            report=None;compress_report=None
            if self.kind=='compress' and self.compressed_output is not None:
                sidecar=Path(str(self.compressed_output)+'.json')
                if sidecar.is_file():
                    try:compress_report=json.loads(sidecar.read_text())
                    except (OSError,ValueError):pass
            if self.kind=='recovery' and self.run and (self.run/'report.json').is_file():
                try:report=json.loads((self.run/'report.json').read_text())
                except Exception:pass
            return {'active':self.running(),'pid':self.pid,'job':self.kind,'returncode':code,
                'run_folder':str(self.run) if self.run else None,'started_at':self.created,
                'last_events':events,'report':report,'compress_report':compress_report}

JOB=Jobs()

def probe_hardware():
    """Reports execution capability, not merely driver detection."""
    import torch
    backend='CPU';ok=False;name=None;detail='Only CPU PyTorch available.'
    if torch.cuda.is_available():
        backend='ROCm / HIP' if torch.version.hip else 'CUDA'
        name=torch.cuda.get_device_name(0)
        try:
            with torch.no_grad():
                x=torch.arange(1024,dtype=torch.float32,device='cuda').reshape(32,32)
                y=x@x.T
                torch.cuda.synchronize()
                ok=bool(torch.isfinite(y).all().item() and y.shape==(32,32))
            detail='Real GPU tensor allocation and FP32 matmul '+('succeeded.' if ok else 'failed numerical check.')
        except Exception as exc: detail='GPU allocation/matmul failed: '+str(exc)
    return {'backend':backend,'torch_version':torch.__version__,'hip_version':torch.version.hip,
            'cuda_runtime':torch.version.cuda,'gpu_name':name,'gpu_matmul_ok':ok,
            'platform':platform.platform(),'detail':detail,
            'recommended_device':'cuda' if ok else 'cpu'}


def clean_string(value,key,required=True):
    v=str(value or '').strip()
    if required and not v:raise ValueError(f'{key} required')
    if len(v)>4096 or '\x00' in v:raise ValueError(f'Invalid {key}')
    return v

class Handler(BaseHTTPRequestHandler):
    server_version='NEXUS-LittleBit/2.0'
    def log_message(self,fmt,*args):
        print('%s - %s'%(self.address_string(),fmt%args))
    def send(self,status,data,kind='application/json'):
        raw=(json.dumps(data,ensure_ascii=False,allow_nan=False)+'\n').encode() if kind=='application/json' else data
        self.send_response(status)
        self.send_header('Content-Type',kind+'; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"frame-ancestors 'none'")
        self.end_headers();self.wfile.write(raw)
    def allowed_origin(self):
        origin=self.headers.get('Origin','')
        if not origin:return True
        return origin in ('http://127.0.0.1:8765','http://localhost:8765')
    def do_GET(self):
        path=urllib.parse.urlparse(self.path).path
        if path in ('/','/index.html','/NEXUS_LittleBit_Recovery_Studio.html'):
            if not HTML.is_file(): return self.send(404,{'error':'HTML missing'})
            return self.send(200,HTML.read_bytes(),'text/html')
        if path=='/nexus_corpus_payload.js':
            shared=ROOT/'nexus_corpus_payload.js'
            if not shared.is_file():return self.send(404,{'error':'Shared corpus asset is missing'})
            return self.send(200,shared.read_bytes(),'text/javascript')
        if path=='/Nexus_Web_LLM.html':
            engine=ROOT/'Nexus_Web_LLM.html'
            if not engine.is_file():return self.send(404,{'error':'Extract the complete package: Nexus_Web_LLM.html is missing'})
            return self.send(200,engine.read_bytes(),'text/html')
        if path=='/api/health':return self.send(200,{'online':True,'local':True,'version':'2.1','max_budget':100_000_000_000})
        if path=='/api/hardware':
            try: return self.send(200,probe_hardware())
            except Exception as exc:return self.send(500,{'error':'PyTorch hardware probe failed: '+str(exc)})
        if path=='/api/corpus-info':
            manifest=ROOT/'corpus'/'manifest.json'
            return self.send(200,json.loads(manifest.read_text()) if manifest.is_file() else {'ready':False})
        if path=='/api/status':return self.send(200,JOB.status())
        return self.send(404,{'error':'Not found'})
    def do_POST(self):
        if not self.allowed_origin():return self.send(403,{'error':'Cross-origin API access rejected'})
        n=int(self.headers.get('Content-Length',0))
        if n<1 or n>MAX_JOB_JSON:return self.send(413,{'error':'JSON body invalid/too large'})
        try:
            x=json.loads(self.rfile.read(n))
            if not isinstance(x,dict):raise ValueError('Expected JSON object')
            route=urllib.parse.urlparse(self.path).path
            if route=='/api/stop':
                return self.send(200,{'message':JOB.stop()})
            if route=='/api/compress':
                inp=clean_string(x.get('q8_gguf'),'q8_gguf');out=clean_string(x.get('output_gguf'),'output_gguf')
                src=app_path(inp);dest=app_path(out)
                if not src.is_file():raise FileNotFoundError('Original Q8 GGUF missing: '+str(src))
                if src==dest:raise ValueError('Refusing to overwrite source GGUF')
                if dest.exists():raise ValueError('Output file already exists. Choose a new output path.')
                w=float(x.get('weights_bpw',.5));emb=float(x.get('embeddings_bpw',2))
                if not (.1<=w<=4 and .1<=emb<=4):raise ValueError('BPW outside 0.1–4')
                device=x.get('device','cuda')
                if device not in ('cuda','auto','cpu'):raise ValueError('Invalid PyTorch device')
                als=int(x.get('als',0));power=int(x.get('power',2));itq=int(x.get('itq',0))
                split=float(x.get('split',.5));kv=float(x.get('kv',1.));edge=float(x.get('edge',1.))
                if not (0<split<1 and .25<=kv<=8 and .25<=edge<=4):raise ValueError('Invalid rank allocation')
                if not (0<=als<=50 and 0<=power<=6 and 0<=itq<=50):raise ValueError('Invalid refinement setting')
                cmd=['-u',str(ROOT/'torch_compress.py'),'--q8-gguf',str(src),'--output',str(dest),
                     '--weights-bpw',str(w),'--embeddings-bpw',str(emb),'--device',device,
                     '--split',str(split),'--als',str(als),'--power',str(power),'--itq',str(itq),
                     '--edge',str(edge),'--kv',str(kv),'--seed',str(int(x.get('seed',20261007)))]
                if not bool(x.get('residual',True)):cmd.append('--no-residual')
                dest.parent.mkdir(parents=True,exist_ok=True)
                pid=JOB.start('compress',cmd,dest.parent)
                JOB.compressed_output=dest
                return self.send(202,{'started':True,'pid':pid,'output_gguf':str(dest)})
            if route=='/api/recovery':
                mode=x.get('mode','new')
                if mode not in ('new','resume','cycle'):raise ValueError('Invalid recovery mode')
                for key in ('factor_gguf','hf_model','corpus_dir','output_dir'):x[key]=clean_string(x.get(key),key)
                x['q8_gguf']=clean_string(x.get('q8_gguf'),'q8_gguf',False)
                if mode in ('resume','cycle'):x['checkpoint']=clean_string(x.get('checkpoint'),'checkpoint')
                for key in ('factor_gguf','q8_gguf','hf_model','corpus_dir','output_dir','checkpoint'):
                    if x.get(key):x[key]=str(app_path(x[key]))
                x['budget_tokens']=int(x.get('budget_tokens',10_000_000))
                if not 10<=x['budget_tokens']<=100_000_000_000:raise ValueError('Budget out of range')
                out=app_path(x['output_dir']);out.mkdir(parents=True,exist_ok=True)
                if mode=='new' and (out/'recipe.json').exists():raise ValueError('Run folder exists: use exact resume or a new folder')
                recipe_name=f'input-{mode}-{int(time.time())}.json'
                path=out/recipe_name
                path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
                pid=JOB.start('recovery',['-u',str(ROOT/'recovery.py'),'--recipe',str(path)],out)
                return self.send(202,{'started':True,'pid':pid,'recipe_path':str(path),'output_folder':str(out)})
            if route=='/api/corpus':
                mod=clean_string(x.get('hf_model'),'hf_model');out=clean_string(x.get('corpus_dir'),'corpus_dir')
                mode=x.get('mode','download')
                if mode not in ('download','import'):raise ValueError('Corpus mode must be download/import')
                args=['-u',str(ROOT/'corpus_builder.py'),'--hf-model',mod,'--output',out,
                    '--tokens-per-stage',str(int(x.get('per_stage',2_000_000))),
                    '--validation-tokens',str(int(x.get('validation',32768))),
                    '--seed',str(int(x.get('seed',20261007))),'--max-rows',str(int(x.get('max_rows',750000)))]
                if mode=='download':args.append('--download')
                else:args.extend(['--import-dir',clean_string(x.get('import_dir'),'import_dir')])
                if x.get('overwrite'):args.append('--overwrite')
                pid=JOB.start('corpus',args,run=app_path(out))
                return self.send(202,{'started':True,'pid':pid,'corpus_folder':str(app_path(out))})
            return self.send(404,{'error':'Unknown API'})
        except (ValueError,KeyError,TypeError,FileNotFoundError) as exc:return self.send(400,{'error':str(exc)})
        except Exception as exc:return self.send(500,{'error':str(exc)})

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=8765);ap.add_argument('--no-browser',action='store_true')
    args=ap.parse_args()
    if args.port!=8765:raise ValueError('Use port 8765; local origin guard is configured for this port')
    from embedded_corpus import extract
    if not (ROOT/'corpus'/'manifest.json').exists():
        extract(HTML,ROOT/'corpus')
        print('Embedded 10M-token corpus extracted and verified.',flush=True)
    http=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
    print('NEXUS LittleBit local app: http://127.0.0.1:8765',flush=True)
    if not args.no_browser:
        threading.Timer(0.5,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
    try:http.serve_forever()
    except KeyboardInterrupt:pass
    finally:http.server_close()
