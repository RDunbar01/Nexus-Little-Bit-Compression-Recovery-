# Validation record — 7 October 2026

Reference: llama.cpp bd4eeaa047006cb1fe71999fbd11134b5836e167; SmolLM2-135M-Instruct revision 12fd25f77366fa6b3b4b768ec3050bf629380bac.

| Check | Result |
|---|---|
| Tokenization | Seven multilingual/numeric/whitespace/contraction cases match Hugging Face and llama.cpp exactly; ChatML Hello prompt matches HF |
| Real 135M model, two-token CPU JS forward | All 49,152 logits compared; PyTorch max absolute difference 1.9550e-5, RMS 6.3970e-6 |
| Arithmetic-matched llama.cpp | Same dequantized Q8 weights in F32 GGUF, F32 KV: max absolute difference 1.5259e-5, RMS 3.2635e-6; same argmax 282 |
| Native Q8 llama.cpp | Different arithmetic path: max difference 0.9061, RMS 0.2711, cosine 0.999929; same argmax; not bit parity |
| Recovery WGSL | 35 kernels compile; complete tiny factorized GQA transformer forward and all 40 gradients match PyTorch, max gradient error 2.7940e-9 |
| Optimizer/loss | KL+CE gradients, stable NLL, three Adam updates match PyTorch |
| Inference WGSL | 11 pipelines compile; packed factor projection, embedding lookup and Q8 dot products match NumPy |
| Browser DOM | Recovery controls, verified 10M-token extraction, checkpoint round-trip, cycle behavior, wrong-source rejection, FP16 serialization pass |
| Recovered GGUF header | Metadata insertion/replacement retains tensor bytes and aligned tensor-data offset |
| Optional Python Studio | 15 regression tests pass |

WGSL execution used native wgpu with the Mesa llvmpipe OpenGL **software adapter**. Chromium launch was blocked by environment socket restrictions. No full-model browser GPU generation, Radeon performance measurement or complete 10M-token recovery was performed. No recovery quality improvement is claimed. Two-token CPU parity is a limited architecture/loading check, not a broad generation benchmark.

## Reproduce focused tests

Install Node.js with jsdom (`npm install jsdom`), and Python dependencies (`pip install numpy torch wgpu pytest`). Run from the extracted package directory:

```sh
node tests/workflow_test.cjs
node tests/record_autograd.cjs
python tests/test_gpu_math.py
node tests/extract_inference_shaders.cjs
python tests/test_inference_kernels.py
node tests/engine_reference.cjs /absolute/path/to/smol-q8.gguf
```

The native wgpu adapter depends on your installed graphics stack. Captured trace/shader JSON and numerical result files are included. The C++ reference runner source is `tests/llama_reference.cpp`; build against the cited llama.cpp checkout. Model weights and third-party test dependencies are not bundled. CPU logit output and recorded token cases are included; reference comparisons must use the same weights and precision settings described above.
