/* SmolLM2 ChatML, LittleBit packed-factor inference and inspection API. */
function augmentLittleBit(em){
 if(!em.meta['littlebit.version'])return em;
 const groups=new Map();
 for(const t of em.list){const m=t.name.match(/^(.*)\.lb([01])\.h$/);if(!m)continue;
  const base=m[1],p=+m[2],get=k=>{const x=em.tensors.get(base+'.lb'+p+'.'+k);if(!x)throw Error('Missing LittleBit component '+base+'.'+k);return x;};
  const h=get('h'),g=get('g'),l=get('l'),u=get('u'),v=get('vt'),rows=h.dims[0],cols=g.dims[0],rank=l.dims[0];
  if(h.qt!==1||g.qt!==1||l.qt!==1||u.qt!==24||v.qt!==24||rank%8||cols%8||u.dims[0]!==rank/8||u.dims[1]!==rows||v.dims[0]!==cols/8||v.dims[1]!==rank)throw Error('Invalid packed factor shape/types: '+base);
  if(!groups.has(base))groups.set(base,[]);groups.get(base)[p]={h,g,l,u,v,rows,cols,rank};
 }
 for(const [base,paths] of groups){
  if(!paths[0]||(paths[1]&&(paths[1].rows!==paths[0].rows||paths[1].cols!==paths[0].cols)))throw Error('Invalid residual paths: '+base);
  const name=base+'.weight';if(em.tensors.has(name))throw Error('Conflicting dense/factor tensor '+name);
  em.tensors.set(name,{name,dims:[paths[0].cols,paths[0].rows],qt:-1,lb:paths,nbytes:paths.reduce((s,p)=>s+p.u.nbytes+p.v.nbytes+p.h.nbytes+p.g.nbytes+p.l.nbytes,0)});
 }
 if(!groups.size)throw Error('LittleBit metadata present but no factors found');return em;
}
async function loadFactorCPU(reader,t){
 if(t._lbCPU)return t._lbCPU;
 t._lbCPU=await Promise.all(t.lb.map(async p=>({rank:p.rank,rows:p.rows,cols:p.cols,
  u:await reader.read(p.u.abs,p.u.nbytes),v:await reader.read(p.v.abs,p.v.nbytes),
  h:dequant(await reader.read(p.h.abs,p.h.nbytes),1),g:dequant(await reader.read(p.g.abs,p.g.nbytes),1),l:dequant(await reader.read(p.l.abs,p.l.nbytes),1)})));
 return t._lbCPU;
}
function bitSign(b,index){return ((b[index>>3]>>(index&7))&1)?-1:1;}
async function factorRow(reader,t,row){
 const paths=await loadFactorCPU(reader,t),out=new Float32Array(t.dims[0]);
 for(const p of paths)for(let j=0;j<p.cols;j++){let v=0;for(let k=0;k<p.rank;k++)v+=bitSign(p.u,row*p.rank+k)*p.l[k]*bitSign(p.v,k*p.cols+j);out[j]+=p.h[row]*p.g[j]*v;}
 return out;
}
class PackedFactorGPU{
 constructor(device){this.d=device;this.cache=new Map();}
 async init(){
  const code=`struct P{cols:u32,rows:u32,mode:u32,add:u32};
@group(0) @binding(0) var<storage,read> bits:array<u32>;
@group(0) @binding(1) var<storage,read> x:array<f32>;
@group(0) @binding(2) var<storage,read> si:array<f32>;
@group(0) @binding(3) var<storage,read> so:array<f32>;
@group(0) @binding(4) var<storage,read_write> y:array<f32>;
@group(0) @binding(5) var<uniform> p:P;
var<workgroup> sums:array<f32,64>;
@compute @workgroup_size(64) fn main(@builtin(workgroup_id) wid:vec3<u32>,@builtin(local_invocation_id) lid:vec3<u32>){
 let row=wid.x;let lane=lid.x;var sum=0.0;
 for(var j=lane;j<p.cols;j+=64u){let ix=row*p.cols+j;let sign=select(1.0,-1.0,((bits[ix/32u]>>(ix%32u))&1u)!=0u);var v=x[j];if(p.mode==0u){v*=si[j];}sum+=sign*v;}
 sums[lane]=sum;workgroupBarrier();var stride=32u;loop{if(lane<stride){sums[lane]+=sums[lane+stride];}workgroupBarrier();if(stride==1u){break;}stride/=2u;}
 if(lane==0u){let value=sums[0]*so[row];if(p.add!=0u){y[row]+=value;}else{y[row]=value;}}
}`;
  const mod=this.d.createShaderModule({code});const info=await mod.getCompilationInfo();const errors=info.messages.filter(m=>m.type==='error');if(errors.length)throw Error(errors.map(e=>e.message).join('\n'));
  this.pipeline=await this.d.createComputePipelineAsync({layout:'auto',compute:{module:mod,entryPoint:'main'}});return this;
 }
 buffer(data){const a=data instanceof Uint8Array?data:new Uint8Array(data.buffer,data.byteOffset,data.byteLength),b=this.d.createBuffer({size:Math.max(4,Math.ceil(a.byteLength/4)*4),usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});const padded=new Uint8Array(b.size);padded.set(a);this.d.queue.writeBuffer(b,0,padded);return b;}
 async preload(r,t){
  if(this.cache.has(t.name))return;
  const paths=await loadFactorCPU(r,t),records=[];
  for(const p of paths)records.push({u:this.buffer(p.u),v:this.buffer(p.v),h:this.buffer(p.h),g:this.buffer(p.g),l:this.buffer(p.l),rank:p.rank,rows:p.rows,cols:p.cols});
  this.cache.set(t.name,records);
  AMD_PROFILE.residentBytes+=records.reduce((sum,p)=>sum+p.u.size+p.v.size+p.h.size+p.g.size+p.l.size,0);
 }
 makeOp(t,input,output){
  const paths=this.cache.get(t.name);if(!paths)throw Error('Factor GPU weights not resident');const ops=[];
  for(let k=0;k<paths.length;k++){const p=paths[k],z=this.d.createBuffer({size:p.rank*4,usage:GPUBufferUsage.STORAGE});
   for(const [bits,x,si,so,y,cols,rows,mode,add] of [[p.v,input,p.g,p.l,z,p.cols,p.rank,0,0],[p.u,z,p.l,p.h,output,p.rank,p.rows,1,k?1:0]]){
    const param=this.d.createBuffer({size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});this.d.queue.writeBuffer(param,0,new Uint32Array([cols,rows,mode,add]));
    const bg=this.d.createBindGroup({layout:this.pipeline.getBindGroupLayout(0),entries:[bits,x,si,so,y,param].map((buffer,binding)=>({binding,resource:{buffer}}))});ops.push({bg,rows,param});
   }
  }return {factor:true,ops};
 }
 encode(enc,op){for(const x of op.ops){const pass=enc.beginComputePass();pass.setPipeline(this.pipeline);pass.setBindGroup(0,x.bg);pass.dispatchWorkgroups(x.rows);pass.end();}}
}
const densePreload=TensorOps.prototype.preload;
TensorOps.prototype.preload=async function(tensors,status){
 const unique=[...new Set(tensors)];await densePreload.call(this,unique.filter(t=>!t.lb),status);
 if(unique.some(t=>t.lb)&&gpu.available){this.factorGPU=await new PackedFactorGPU(gpu.device).init();for(const t of unique.filter(t=>t.lb))await this.factorGPU.preload(this.r,t);}
};
const denseRow=TensorOps.prototype.row;
TensorOps.prototype.row=async function(t,i){return t.lb?factorRow(this.r,t,i):denseRow.call(this,t,i);};
const denseMatvec=TensorOps.prototype.matvec;
TensorOps.prototype.matvec=async function(t,x){if(!t.lb)return denseMatvec.call(this,t,x);const out=new Float32Array(t.dims[1]);for(let i=0;i<out.length;i++){const w=await factorRow(this.r,t,i);let a=0;for(let j=0;j<w.length;j++)a+=w[j]*x[j];out[i]=a;}return out;};
const denseMany=TensorOps.prototype.matvecMany;
TensorOps.prototype.matvecMany=async function(ts,x){if(ts.some(t=>t.lb))return Promise.all(ts.map(t=>this.matvec(t,x)));return denseMany.call(this,ts,x);};
const denseMake=FinalMistralGraph.prototype.makeMatOp;
FinalMistralGraph.prototype.makeMatOp=function(t,x,y){return t.lb?this.e.ops.factorGPU.makeOp(t,x,y):denseMake.call(this,t,x,y);};
const denseEncode=FinalMistralGraph.prototype.encodeMat;
FinalMistralGraph.prototype.encodeMat=function(enc,op){if(op.factor)this.e.ops.factorGPU.encode(enc,op);else denseEncode.call(this,enc,op);};
const denseEncodes=FinalMistralGraph.prototype.encodeMats;
FinalMistralGraph.prototype.encodeMats=function(enc,ops){if(ops.some(x=>x.factor))for(const op of ops)this.encodeMat(enc,op);else denseEncodes.call(this,enc,ops);};
MistralEngine.prototype.generateSmol=async function(text,hist,maxNew,temp,topK,onToken,status){
 this.resetSession();const messages=[];
 for(const h of hist||[]){if(h.role&&h.content!=null)messages.push({role:h.role,content:h.content});else if(h.user!=null){messages.push({role:'user',content:h.user});if(h.assistant!=null)messages.push({role:'assistant',content:h.assistant});}}
 if(messages.at(-1)?.role!=='user'||messages.at(-1)?.content!==text)messages.push({role:'user',content:text});
 const ids=this.tok.chatML?this.tok.chatIds(messages):this.tok.encode(text,true);
 const ctx=this.graph?this.graph.ctx:Number(mget(this.em,'llama','context_length',8192));
 if(ids.length+maxNew>ctx)throw Error('Prompt plus requested output exceeds context. Start a new chat or reduce output tokens.');
 const start=performance.now();let logits;
 if(this.graph){const p=await this.graph.prefill(ids,0,status);this.pos=p.pos;logits=p.logits;}else logits=await this.consume(ids,status);
 const preSec=(performance.now()-start)/1000,dec=performance.now(),decoder=new TextDecoder();let out='',n=0;
 const sampler=new LlamaStyleSampler(this.tok);sampler.beginTurn();
 for(;n<maxNew;n++){
  if(NEXUS_ABORT)break;
  const id=temp===0?logits.reduce((best,v,i)=>v>logits[best]?i:best,0):sampler.sample(logits);sampler.observe(id);
  if(id===this.tok.eos)break;
  const piece=decoder.decode(this.tok.bytesFor(id),{stream:true});out+=piece;if(piece)onToken(piece);
  if(this.graph){const p=await this.graph.decode(id,this.pos,status);this.pos=p.pos;logits=p.logits;}else logits=await this.consume([id],status);
 }
 const tail=decoder.decode();if(tail){out+=tail;onToken(tail);}
 this.lastStats={prefillTokens:ids.length,prefillSec:preSec,decodeTokens:n,decodeSec:(performance.now()-dec)/1000,reasonTokens:0};return out;
};
window.NexusEngineAPI={Tok,parseGGUF,buildExecutionModel,augmentLittleBit,MistralEngine,MistralFinalGPU,FinalMistralGraph,QuantGPU,TensorOps,PackedFactorGPU,ropeGGMLYarn,dequant,loadFactorCPU,factorRow,
 getEngine:()=>engine,getDevice:()=>gpu.device,getModel:()=>executionModel,getReader:()=>reader,
 async load(file){await loadFile(file);if(!engine)throw Error('Engine failed to load');return engine;}};
// Packed embedding lookup also stays on-device; only the token ID is uploaded.
const initFactor=PackedFactorGPU.prototype.init;
PackedFactorGPU.prototype.init=async function(){await initFactor.call(this);const code=`
struct P{cols:u32,rank:u32,token:u32,add:u32};
@group(0) @binding(0) var<storage,read> U:array<u32>;
@group(0) @binding(1) var<storage,read> V:array<u32>;
@group(0) @binding(2) var<storage,read> h:array<f32>;
@group(0) @binding(3) var<storage,read> g:array<f32>;
@group(0) @binding(4) var<storage,read> l:array<f32>;
@group(0) @binding(5) var<storage,read_write> y:array<f32>;
@group(0) @binding(6) var<uniform> p:P;
@compute @workgroup_size(256) fn main(@builtin(global_invocation_id) id:vec3<u32>){let col=id.x;if(col>=p.cols){return;}var sum=0.0;for(var k=0u;k<p.rank;k++){let ui=p.token*p.rank+k;let vi=k*p.cols+col;let us=select(1.0,-1.0,((U[ui/32u]>>(ui%32u))&1u)!=0u);let vs=select(1.0,-1.0,((V[vi/32u]>>(vi%32u))&1u)!=0u);sum+=us*vs*l[k];}let value=sum*h[p.token]*g[col];if(p.add!=0u){y[col]+=value;}else{y[col]=value;}}
`;const module=this.d.createShaderModule({code,label:'Packed LittleBit embedding'});this.embeddingPipe=await this.d.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'main'}});this.embeddingBindings=new Map();return this;};
PackedFactorGPU.prototype.encodeEmbedding=function(enc,t,id,out){
 if(!Number.isInteger(id)||id<0||id>=t.dims[1])throw Error('Embedding token out of range');let bindings=this.embeddingBindings.get(t.name);
 if(!bindings){bindings=this.cache.get(t.name).map((p,i)=>{const param=this.d.createBuffer({size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),bg=this.d.createBindGroup({layout:this.embeddingPipe.getBindGroupLayout(0),entries:[p.u,p.v,p.h,p.g,p.l,out,param].map((buffer,binding)=>({binding,resource:{buffer}}))});return {p,param,bg,i};});this.embeddingBindings.set(t.name,bindings);}
 for(const {p,param,bg,i} of bindings){this.d.queue.writeBuffer(param,0,new Uint32Array([p.cols,p.rank,id,i?1:0]));const pass=enc.beginComputePass();pass.setPipeline(this.embeddingPipe);pass.setBindGroup(0,bg);pass.dispatchWorkgroups(Math.ceil(p.cols/256));pass.end();}
};
