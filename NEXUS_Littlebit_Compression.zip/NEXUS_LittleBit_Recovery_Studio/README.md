# NEXUS WebGPU SmolLM2 + LittleBit recovery

7 October 2026. Browser-native inference and experimental browser-native recovery, with an embedded 10M-token curriculum. No Python training server is needed for the browser workflow. Extract the entire ZIP before opening either HTML file; both HTML pages depend on the adjacent `nexus_corpus_payload.js` file.

## Start here

1. Open `Nexus_Web_LLM.html` in a WebGPU-capable Edge/Chrome browser. Check that the GPU indicator succeeds. Your browser/driver must expose WebGPU; the app cannot install GPU drivers.
2. For ordinary chat, load your **SmolLM2-135M-Instruct Q8_0 GGUF**. SmolLM2's ChatML formatting and byte-level BPE are now selected instead of the Foundry prompt convention. A base model without the ChatML template uses completion formatting.
3. To compress, open `NEXUS_LittleBit_Recovery_Studio.html` from the same folder. Load the same Q8 model and export the packed LittleBit GGUF. The defaults are 0.5 projection BPW and 2 embedding/head BPW, subject to representable ranks and scale overhead. Optional ALS/ITQ/back-fitting remain disabled by default.
4. Open/reload `Nexus_Web_LLM.html`, click **Recovery**, and select the original Q8 teacher plus the packed LittleBit student. Do this before loading a chat model. The app prevents simultaneous chat-model and recovery-model allocation.
5. Start recovery. The 10M-token corpus is supplied in the shared `nexus_corpus_payload.js` file alongside the HTML pages. Default sequence length is 32, evaluation cap 1,024 held-out tokens, and training allocation ceiling 4,096 MiB. These conservative defaults bound memory; adjust them to the capacity exposed by your browser. Training FP32 masters/gradients/Adam state are much larger than packed inference weights.
6. **Stop after update** exports a browser `.nqat` checkpoint. At completion, the app exports a checkpoint, recovered packed GGUF, and measurement report. Keep those downloads. There is currently no automatic background checkpoint persistence: save regularly during long runs.
7. Reload the page to free training buffers, then load the recovered GGUF for chat. Packed factors execute directly on WebGPU; the application does not expand every matrix into dense inference weights.

For an interrupted run, reload, select the same original teacher/student files, identical settings and the `.nqat` checkpoint, and choose **Exact resume**. For more recovery after a completed cycle, choose **Another cycle from checkpoint**. That preserves learned factors and resets Adam. Python `.pt` checkpoints are a different format and cannot be imported as `.nqat`.

The included Python Studio backend remains an optional alternative. Its setup documentation is `PYTORCH_STUDIO_README.md`.

## Fixes and additions

- SmolLM2 is no longer treated as a Foundry-trained Llama solely because `general.architecture` is `llama`.
- SmolLM2 byte-level pre-tokenization now splits individual numeric characters before GPT-2 ByteLevel splitting. ChatML uses the model's system/user/assistant convention and end-of-turn marker. Conversation history is included.
- Tied token embeddings/output heads, 9 query heads / 3 KV heads, 64-wide heads, RMSNorm epsilon and RoPE frequency are taken from model metadata. The configured GPU context is capped by the model context limit.
- Q8 matrices participate in independent GPU row validation at startup. SmolLM2 skips the old name/size-based shortcut certificate and runs the health probes afresh.
- The Studio's packed LittleBit tensor format now loads as virtual projection/embedding tensors. Two-stage factor multiplication and packed embedding lookup run directly on WebGPU, with resident factors/scales and reusable pipelines.
- Recovery adds WebGPU forward/backward operations for factor projections, tied embeddings, RMSNorm, SwiGLU, grouped-query causal attention, RoPE, softmax, distillation and next-token loss. Only the factor masters and scales train; other tensors remain frozen.
- Adam, global gradient clipping, cosine LR decay, 2% warm-up, five corpus stages, pre/post/Q8 perplexity, stop/continue, source-checked checkpoints and packed GGUF export are implemented in JavaScript/WGSL.
- Training uses SmoothSign k=100 and FP16 scale rounding in the forward pass. The original Q8 teacher remains a deliberate difference from LittleBit's full-precision teacher.
- Corpus/teacher/student vocabulary checks reject mismatches. Checkpoint checks cover source hashes, corpus identity, settings, tensor names/shapes, finite values, optimizer variance, lengths and progress counters. Recovery state is rejected before writes if validation fails.
- Studio WebGPU SVD products now use tiled multiplication and upload each weight matrix once per SVD instead of once per power-iteration projection. QR/eigensolve/rank-one fitting and optional ALS remain CPU work. No measured compression speedup is claimed.

This implements the operations needed for this SmolLM2 recovery profile. It does not implement all model architectures, quantization formats or training features in llama.cpp/PyTorch. Browser recovery currently enforces **SmolLM2-135M dimensions**, Q8_0 teacher matrices and unscaled RoPE. Other existing inference paths were preserved, but were not broadly revalidated on their full models.

## Included corpus

The bundled shared JavaScript corpus asset supplies **10,000,000 training-token positions**, not download instructions:

| Stage | Tokens | Source |
|---|---:|---|
| General language | 2M | 60% DCLM-Edu / 40% FineWeb-Edu |
| Structured text/code | 2M | 50% Cosmopedia V2 / 50% Stack-Edu |
| Mathematics | 2M | 50% FineMath / 50% InfiMM-WebMath |
| Instructions | 2M | Smol-SmolTalk, official small-model chat template |
| Consolidation | 2M | Equal replay of the first four stages |

Stages 1–3 come from EleutherAI/SmolLM2-135M-10B. This is **8M newly selected source-token positions + 2M deliberate replay**. A separate 32,768-token WikiText-2 validation stream is included. Archive/file hashes, source revisions, tokenizer hash and selection counts are embedded in the manifest. The browser verifies the GGUF vocabulary against the corpus tokenizer's vocabulary. Exact selected document duplicates were filtered; near-duplicate contamination was not audited.

Budgets up to 100 billion exposures recycle this fixed corpus. The five stages are a custom recovery curriculum, not reproduction of SmolLM2 pretraining or the paper's five-epoch experiment. Dataset terms remain with their source owners.

## What was actually tested

See `VALIDATION.md` and `tests/` for results and reproducible reference code.

- Real SmolLM2-135M-Instruct weights were converted with the official llama.cpp converter, quantized to Q8_0, and loaded by this HTML's JavaScript parser/CPU transformer graph.
- Seven tokenization cases matched **both llama.cpp and Hugging Face exactly**, including multilingual text, whitespace, contractions and numbers. The tested ChatML prompt matched Hugging Face exactly.
- A real-model two-token forward test compared all 49,152 output logits with PyTorch and llama.cpp. The arithmetic-matched llama.cpp check used the same dequantized Q8 weights and FP32 KV cache. Ordinary native Q8 llama.cpp arithmetic was recorded separately; it is not bit-identical to the app's FP32 activation path.
- All 35 recovery WGSL kernels and 11 inference pipelines compiled on native WebGPU using Mesa llvmpipe/OpenGL, a **software adapter**.
- A complete small factorized transformer's forward pass and all 40 parameter gradients matched PyTorch. GPU tests also covered distillation/CE gradients, NLL, three Adam updates, packed factor projections, packed embedding lookup and Q8 dot products.
- DOM tests covered opening Recovery, extracting/checking all corpus bytes, checkpoint round-trip, cycle optimizer behavior, wrong-source rejection and FP16 serialization. Fifteen existing Python Studio regressions passed.

**Not established:** successful full 10M-token browser recovery, real-model recovery improvement, end-to-end browser GPU generation on the full 135M model, Radeon throughput/VRAM use, or parity across other models. Chromium launch was blocked by the execution environment's socket restrictions. The software-adapter kernel tests are actual WebGPU execution, but they do not substitute for your browser/GPU acceptance test.

Stop and save a checkpoint if loss diverges. A smaller packed model is not automatically a better model. Compare the pre/post metrics on the same evaluation settings before using recovered weights.

## Backend structure

- `Nexus_Web_LLM.html`: browser engine, recovery controls and shaders. Keep the shared `nexus_corpus_payload.js` beside it.
- `NEXUS_LittleBit_Recovery_Studio.html`: standalone factor compressor and corpus export.
- `smol_integration.js`: editable ChatML/factor runtime extensions.
- `webgpu_autograd.js`: editable GPU tensor/autograd/optimizer backend.
- `browser_recovery.js`: editable five-stage runner, checkpointing and export.
- The rest of the Python modules support the optional PyTorch workflow.
- `tests/`: CPU/reference code, native WebGPU replay and numerical tests. Test dependencies are not needed to use the HTML files.

The training backend uses FP32 operations for portability. FP16 inference KV storage follows the existing engine; the precision-controlled reference comparison explicitly uses FP32 KV instead. No custom bitwise-training speed or cache-residency claim is made.

## Sources

- [LittleBit paper](https://arxiv.org/html/2506.13771v1)
- [llama.cpp](https://github.com/ggml-org/llama.cpp), tested source commit `bd4eeaa047006cb1fe71999fbd11134b5836e167`
- [SmolLM2-135M-Instruct](https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct), downloaded revision `12fd25f77366fa6b3b4b768ec3050bf629380bac`
- [EleutherAI corpus sample](https://huggingface.co/datasets/EleutherAI/SmolLM2-135M-10B)
- [Smol-SmolTalk](https://huggingface.co/datasets/HuggingFaceTB/smol-smoltalk)

## v11 memory recovery fix
Tied embedding factors share one forward transformation. Teacher intermediates are released before the student graph; completed graph buffers are released before Adam, which reuses three scratch buffers. Memory ceiling errors discard unfinished commands and release temporary buffers. Adjust the allocation ceiling under Advanced settings to retry, or use Reset / change settings to release training state and change sequence length. Reset discards unsaved recovery progress; save a checkpoint first if updates have completed. The memory display counts tensor allocations, excluding browser and driver overhead. Do not assume a larger ceiling guarantees available GPU memory.

The v11 changes passed tiny-model WGSL/PyTorch gradient comparisons and memory lifecycle tests. Full SmolLM2 recovery on AMD hardware and completion of the 10M-token curriculum remain unverified.

## Distribution size optimization (8 October 2026)

This sub-25 MB distribution stores the same SHA-256-verified 10-million-token corpus **once** instead of embedding identical base64 copies in two different HTML pages. No token data was removed or downsampled. The source ZIP was otherwise retained. To preserve full offline functionality, **extract all files**, leave `nexus_corpus_payload.js` alongside both HTML files, and open either HTML app. Modern Edge/Chrome allow adjacent classic JavaScript files to load locally; no fetch API or web server is required. The optional Python launcher also serves this file. Do not open an HTML file directly from within the ZIP, or separate it from the shared script.
