Generated data and model weights are deliberately not distributed here. See README.md.
