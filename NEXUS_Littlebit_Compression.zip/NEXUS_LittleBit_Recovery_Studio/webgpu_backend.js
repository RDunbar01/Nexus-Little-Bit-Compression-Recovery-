/* Actual WebGPU compute used by browser-side randomized SVD projections.
 * The ALS/sign-fitting stages remain on Web Workers (CPU); PyTorch QAT runs
 * on the selected CPU or ROCm GPU. GPU availability is never inferred.
 */
(function(root){
'use strict';
let session=null;
const wgsl=`
struct Params { m:u32, n:u32, l:u32, trans:u32 };
@group(0) @binding(0) var<storage,read> W:array<f32>;
@group(0) @binding(1) var<storage,read> B:array<f32>;
@group(0) @binding(2) var<storage,read_write> O:array<f32>;
@group(0) @binding(3) var<uniform> p:Params;
var<workgroup> wa:array<f32,64>;var<workgroup> ba:array<f32,64>;
@compute @workgroup_size(8,8) fn main(@builtin(global_invocation_id) t:vec3<u32>,@builtin(local_invocation_id) q:vec3<u32>){
 let col=t.x;let row=t.y;let rows=select(p.m,p.n,p.trans!=0u);let inner=select(p.n,p.m,p.trans!=0u);var v=0.0;
 for(var base=0u;base<inner;base+=8u){let a=base+q.x;let b=base+q.y;var x=0.0;var y=0.0;
 if(row<rows&&a<inner){x=W[select(row*p.n+a,a*p.n+row,p.trans!=0u)];}
 if(col<p.l&&b<inner){y=B[b*p.l+col];}
 wa[q.y*8u+q.x]=x;ba[q.y*8u+q.x]=y;workgroupBarrier();
 for(var k=0u;k<8u;k++){v+=wa[q.y*8u+k]*ba[k*8u+q.x];}workgroupBarrier();}
 if(row<rows&&col<p.l){O[row*p.l+col]=v;}
}`;
async function getSession(){
  if(session)return session;
  if(!self.navigator || !navigator.gpu)throw new Error('WebGPU not available in this worker/browser');
  let adapter=await navigator.gpu.requestAdapter({powerPreference:'high-performance'});
  if(!adapter)throw new Error('WebGPU adapter unavailable');
  const device=await adapter.requestDevice();
  const mod=device.createShaderModule({code:wgsl});
  const pipeline=device.createComputePipeline({layout:'auto',compute:{module:mod,entryPoint:'main'}});
  session={adapter,device,pipeline};
  device.lost.then(()=>{session=null;});
  return session;
}
function asF32(x){return x instanceof Float32Array?x:Float32Array.from(x);}
async function projection(runtime,W,m,n,B,L,trans,matrix){
  const {device,pipeline}=runtime;
  const rows=trans?n:m, inner=trans?m:n;
  if(B.length!==inner*L)throw new Error('Bad WebGPU SVD input dimensions');
  let sizeW=W.length*4,sizeB=B.length*4,sizeO=rows*L*4;
  if(Math.max(sizeW,sizeB,sizeO)>device.limits.maxStorageBufferBindingSize)
    throw new Error('WebGPU storage buffer limit insufficient for matrix; use PyTorch compression');
  const U=GPUBufferUsage, M=GPUMapMode;

  const vec=device.createBuffer({size:sizeB,usage:U.STORAGE|U.COPY_DST});
  const result=device.createBuffer({size:sizeO,usage:U.STORAGE|U.COPY_SRC});
  const readback=device.createBuffer({size:sizeO,usage:U.COPY_DST|U.MAP_READ});
  const params=device.createBuffer({size:16,usage:U.UNIFORM|U.COPY_DST});
  try{

    device.queue.writeBuffer(vec,0,asF32(B));
    device.queue.writeBuffer(params,0,new Uint32Array([m,n,L,trans?1:0]));
    const entries=[matrix,vec,result,params].map((b,i)=>({binding:i,resource:{buffer:b}}));
    const bg=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries});
    const cmd=device.createCommandEncoder(),pass=cmd.beginComputePass();
    pass.setPipeline(pipeline);pass.setBindGroup(0,bg);
    pass.dispatchWorkgroups(Math.ceil(L/8),Math.ceil(rows/8));pass.end();
    cmd.copyBufferToBuffer(result,0,readback,0,sizeO);
    device.queue.submit([cmd.finish()]);
    await readback.mapAsync(M.READ);
    const out=new Float64Array(rows*L);
    const raw=new Float32Array(readback.getMappedRange());
    for(let i=0;i<raw.length;i++)out[i]=raw[i];
    readback.unmap();
    return out;
  }finally{vec.destroy();result.destroy();readback.destroy();params.destroy();}
}
async function svd(W,m,n,k,over,power,rng){
  const R=await getSession(),h=root.LittleBit._math;
  const L=Math.min(k+over,m,n);
  const report=s=>{if(root.lbProgress)root.lbProgress(s);};report('SVD rank '+k+' · '+m+' × '+n);
  const matrix=R.device.createBuffer({size:W.length*4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});
  R.device.queue.writeBuffer(matrix,0,asF32(W));
  try{
  let Omega=new Float64Array(n*L);
  for(let i=0;i<Omega.length;i++)Omega[i]=rng.gauss();
  report('GPU initial projection / CPU QR');
  let Y=h.orthonormalize(await projection(R,W,m,n,Omega,L,false,matrix),m,L), Z;
  for(let step=0;step<power;step++){
    report('SVD power iteration '+(step+1)+'/'+power+' (GPU products, CPU QR)');
    Z=h.orthonormalize(await projection(R,W,m,n,Y,L,true,matrix),n,L);
    Y=h.orthonormalize(await projection(R,W,m,n,Z,L,false,matrix),m,L);
  }
  Z=await projection(R,W,m,n,Y,L,true,matrix);
  report('CPU eigensolve');
  const eig=h.jacobiEig(h.gram(Z,n,L),L),r=Math.min(k,L);
  const E=new Float64Array(L*r);
  for(let i=0;i<L;i++)for(let j=0;j<r;j++)E[i*r+j]=eig.V[i*L+j];
  let U=h.matmul(Y,E,m,L,r), V=h.matmul(Z,E,n,L,r),S=new Float64Array(r);
  for(let j=0;j<r;j++){
    const s=Math.sqrt(Math.max(eig.w[j],0));S[j]=s;
    const inv=s>1e-30?1/s:0;
    for(let i=0;i<n;i++)V[i*r+j]*=inv;
  }
  return {U,S,V,k:r};
  }finally{matrix.destroy();}
}
root.LittleBitGPU={getSession,svd};
})(typeof self!=='undefined'?self:globalThis);
