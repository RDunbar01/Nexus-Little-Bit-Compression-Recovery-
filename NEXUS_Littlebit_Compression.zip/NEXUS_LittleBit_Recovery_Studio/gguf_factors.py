"""Read Q8_0 GGUF and NEXUS LittleBit packed-factor GGUF, and export QAT scales/signs.
Implements exactly the audited builder's .lb{0,1}.{u,vt,h,g,l} layout.
No assumption that a packed GGUF is executable in stock llama.cpp.
"""
from __future__ import annotations
import hashlib
import json
import mmap
import os
import struct
from dataclasses import dataclass
from pathlib import Path
import numpy as np

DTYPE_BYTES = {0: (1,4), 1: (1,2), 2:(32,18), 3:(32,20), 6:(32,22), 7:(32,24),
               8:(32,34), 9:(32,36), 24:(1,1), 25:(1,2), 26:(1,4), 27:(1,8), 28:(1,8)}

@dataclass
class Tensor:
    name: str
    shape: tuple
    type: int
    offset: int
    nbytes: int

class GGUF:
    def __init__(self, path):
        self.path = Path(path).expanduser().resolve()
        self.file = self.path.open('rb')
        self.mm = mmap.mmap(self.file.fileno(), 0, access=mmap.ACCESS_READ)
        self.pos=0
        assert self._read(4)==b'GGUF', 'Not GGUF'
        self.version=self.u32()
        if self.version !=3:
            raise ValueError(f'GGUF v3 required, got {self.version}')
        tensor_count=self.u64(); kv_count=self.u64()
        if tensor_count > 100000 or kv_count > 100000: raise ValueError('Suspicious counts')
        self.metadata={}; self.string_positions={}; self.raw_metadata=[]
        for _ in range(kv_count):
            entry_start=self.pos
            key=self.string(); typ=self.u32()
            if typ ==8:
                n=self.u64(); st=self.pos
                if n>64*1024*1024: raise ValueError('Metadata too large')
                val=self._read(n).decode('utf-8')
                self.string_positions[key]=(st,n)
            else: val=self.value(typ)
            if key in self.metadata: raise ValueError('Duplicate metadata: '+key)
            self.metadata[key]=val
            self.raw_metadata.append((key, bytes(self.mm[entry_start:self.pos])))
        self.tensors={}
        for _ in range(tensor_count):
            name=self.string(); nd=self.u32()
            if nd>8: raise ValueError('Bad dims')
            dims=[self.u64() for _ in range(nd)]
            typ=self.u32(); off=self.u64()
            if typ not in DTYPE_BYTES: raise ValueError(f'Unsupported ggml tensor type {typ}: {name}')
            q,per=DTYPE_BYTES[typ]
            elements=int(np.prod(dims,dtype=np.int64))
            if elements % q: raise ValueError('Block alignment error: '+name)
            nbytes=elements//q*per
            if name in self.tensors: raise ValueError('Duplicate tensor: '+name)
            self.tensors[name]=Tensor(name,tuple(reversed(dims)),typ,off,nbytes)
        alignment=int(self.metadata.get('general.alignment',32))
        if alignment < 1 or alignment>4096 or alignment & (alignment-1): raise ValueError('Bad alignment')
        self.data_start=(self.pos+alignment-1)//alignment*alignment
        for t in self.tensors.values():
            if self.data_start + t.offset + t.nbytes > len(self.mm): raise ValueError(f'Truncated tensor {t.name}')
    def close(self): self.mm.close(); self.file.close()
    def __enter__(self): return self
    def __exit__(self,*_): self.close()
    def _read(self,n):
        if n<0 or self.pos+n>len(self.mm): raise ValueError('Truncated GGUF')
        b=self.mm[self.pos:self.pos+n]; self.pos+=n; return b
    def u32(self): return struct.unpack('<I',self._read(4))[0]
    def u64(self): return struct.unpack('<Q',self._read(8))[0]
    def string(self):
        n=self.u64()
        if n>64*1024*1024: raise ValueError('Oversized GGUF string')
        return self._read(n).decode('utf-8')
    def value(self,t):
        fmt={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'B',10:'Q',11:'q',12:'d'}
        if t in fmt:
            f='<'+fmt[t]; return struct.unpack(f,self._read(struct.calcsize(f)))[0]
        if t==9:
            inner=self.u32(); n=self.u64()
            if n>5000000: raise ValueError('Oversized GGUF array')
            return [self.string() if inner==8 else self.value(inner) for _ in range(n)]
        raise ValueError(f'Unsupported metadata type {t}')
    def payload(self,name):
        t=self.tensors[name]; start=self.data_start+t.offset
        return self.mm[start:start+t.nbytes]
    def array(self,name):
        t=self.tensors[name]; data=self.payload(name)
        if t.type in (0,1,24,25,26,27,28):
            dt={0:'<f4',1:'<f2',24:'i1',25:'<i2',26:'<i4',27:'<i8',28:'<f8'}[t.type]
            return np.frombuffer(data,dtype=dt).copy().reshape(t.shape)
        if t.type==8:
            blocks=np.frombuffer(data,dtype=np.uint8).reshape(-1,34)
            scales=blocks[:,:2].copy().view('<f2').astype(np.float32)
            values=blocks[:,2:].copy().view(np.int8).astype(np.float32)
            return (scales*values).reshape(t.shape)
        raise ValueError('Cannot decode type '+str(t.type))
    def factor(self,base):
        paths=[]
        for p in (0,1):
            pre=base.replace('.weight','') + f'.lb{p}.'
            if pre+'u' not in self.tensors: continue
            ut=self.tensors[pre+'u']; vt=self.tensors[pre+'vt']
            m=ut.shape[0]; rank=ut.shape[1]*8; n=vt.shape[1]*8
            if vt.shape[0]!=rank: raise ValueError('Factor rank mismatch: '+base)
            def unpack(field,rows,cols):
                dat=np.frombuffer(self.payload(pre+field),dtype=np.uint8).reshape(rows,cols//8)
                sign=1-2*np.unpackbits(dat,axis=1,bitorder='little').astype(np.float32)
                return sign
            paths.append(dict(u=unpack('u',m,rank), v=unpack('vt',rank,n),
                              h=self.array(pre+'h').astype(np.float32),
                              g=self.array(pre+'g').astype(np.float32),
                              l=self.array(pre+'l').astype(np.float32)))
        return paths
    def factor_names(self):
        names=self.metadata.get('littlebit.tensors')
        if names is not None: return list(names)
        return [n.replace('.lb0.u','.weight') for n in self.tensors if n.endswith('.lb0.u')]
    def rewrite_with_factors(self, destination, factors, provenance=None):
        """Copy original packed file and overwrite fixed-size tensor payloads + same-length training marker.
        `factors` maps base name to list of path dictionaries containing +/-1 u/v & FP16 scales.
        """
        destination=Path(destination)
        if destination.resolve()==self.path: raise ValueError('Refusing to overwrite source GGUF')
        destination.parent.mkdir(parents=True,exist_ok=True)
        tmp=destination.with_suffix(destination.suffix+'.partial')
        with self.path.open('rb') as src, tmp.open('wb') as dst:
            while b:=src.read(4*1024*1024): dst.write(b)
            for base,paths in factors.items():
                if len(paths)!=len(self.factor(base)): raise ValueError('Factor path count changed: '+base)
                for i,p in enumerate(paths):
                    pre=base.replace('.weight','')+f'.lb{i}.'
                    for name in ('u','vt','h','g','l'):
                        if name in ('u','vt'):
                            values=np.asarray(p["v" if name=="vt" else name])
                            if not np.all((values==1)|(values==-1)): raise ValueError('Non-binary factor')
                            raw=np.packbits((values<0).astype('u1'),axis=1,bitorder='little').tobytes()
                        else:
                            raw=np.asarray(p[name],dtype='<f2').tobytes()
                        t=self.tensors[pre+name]
                        if len(raw)!=t.nbytes: raise ValueError(f'Factor shape/size mismatch: {pre+name}')
                        dst.seek(self.data_start+t.offset)
                        dst.write(raw)
            key='littlebit.recovery_training'
            if key in self.string_positions:
                st,n=self.string_positions[key]
                tag='QAT-trained; independent recovery sidecar is authoritative'
                encoded=tag.encode('utf-8')[:n].ljust(n,b' ')
                dst.seek(st); dst.write(encoded)
            dst.flush(); os.fsync(dst.fileno())
        os.replace(tmp,destination)
        if provenance:
            sidecar=destination.with_suffix(destination.suffix+'.json')
            sidecar.write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
        return sha256_file(destination)

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def unpack_bpw(gguf):
    names=gguf.factor_names()
    if not names: return None
    converted=sum(int(np.prod(gguf.tensors[n.replace('.weight','.lb0.u')].shape))*8 for n in []) # placeholder not used
    weights=0; bits=0
    for name in names:
        paths=gguf.factor(name)
        if not paths: continue
        m,r=paths[0]['u'].shape; _,n=paths[0]['v'].shape
        weights+=m*n
        for p in paths: bits+=p['u'].size + p['v'].size + 16*(p['h'].size+p['g'].size+p['l'].size)
    return bits/weights if weights else None
