#include "llama.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
int main(int argc,char**argv){
 if(argc<4)return 2;llama_backend_init();auto mp=llama_model_default_params();mp.n_gpu_layers=0;
 auto *model=llama_model_load_from_file(argv[1],mp);if(!model)return 3;const auto *vocab=llama_model_get_vocab(model);
 if(std::string(argv[2])=="tokenize") {std::vector<llama_token>ids(4096);int n=llama_tokenize(vocab,argv[3],std::string(argv[3]).size(),ids.data(),ids.size(),false,false);for(int i=0;i<n;i++)std::cout<<(i?",":"")<<ids[i];std::cout<<"\n";return 0;}
 auto cp=llama_context_default_params();cp.n_ctx=128;cp.type_k=GGML_TYPE_F32;cp.type_v=GGML_TYPE_F32;cp.n_batch=128;cp.n_threads=4;cp.n_threads_batch=4;cp.flash_attn_type=LLAMA_FLASH_ATTN_TYPE_DISABLED;
 auto*ctx=llama_init_from_model(model,cp);std::vector<llama_token>ids;std::stringstream ss(argv[2]);std::string word;while(std::getline(ss,word,','))ids.push_back(std::stoi(word));
 auto batch=llama_batch_get_one(ids.data(),ids.size());if(llama_decode(ctx,batch))return 4;const float *logits=llama_get_logits_ith(ctx,-1);std::ofstream out(argv[3],std::ios::binary);out.write((char*)logits,llama_vocab_n_tokens(vocab)*sizeof(float));llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
}
