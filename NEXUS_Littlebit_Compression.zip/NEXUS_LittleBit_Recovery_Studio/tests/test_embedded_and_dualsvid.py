import sys,io,zipfile,hashlib,base64
from pathlib import Path
import numpy as np
import pytest
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import torch_compress as tc
from embedded_corpus import embedded_zip,extract
import corpus_builder as cb

def test_dualsvid_matches_independent_magnitude_svd():
    torch.manual_seed(123);w=torch.randn(32,48)
    torch.manual_seed(5);a,b=tc.orthogonal_initialization(w,8,return_magnitudes=True)
    def scale(x):
        u,s,v=torch.linalg.svd(x.abs(),full_matrices=False)
        return u[:,0].abs()*s[0].sqrt(),v[0].abs()*s[0].sqrt()
    h,lu=scale(a);g,lv=scale(b)
    expected=tc.reconstruct((torch.where(a>=0,1.,-1.),torch.where(b.T>=0,1.,-1.),h,g,lu*lv))
    torch.manual_seed(5);actual=tc.reconstruct(tc.dual_svid(w,8))
    torch.testing.assert_close(actual,expected)

def test_residual_is_fit_to_primary_error():
    torch.manual_seed(55);w=torch.randn(32,48)
    torch.manual_seed(8);paths=tc.compression_paths(w,8,8,als=0)
    torch.manual_seed(8);p=tc.dual_svid(w,8);first=tc.fit_path(w,p[0],p[1],0,initial=p[2:])
    residual=w-tc.reconstruct(first);p=tc.dual_svid(residual,8)
    second=tc.fit_path(residual,p[0],p[1],0,initial=p[2:])
    torch.testing.assert_close(tc.reconstruct(paths[1]),tc.reconstruct(second))

def test_both_math_sources_required():
    assert cb.stage_mix(2,2_000_000)=={'finemath':1_000_000,'infimm':1_000_000}
    assert cb.category('infimm_webmath')=='infimm'
    assert cb.category('finemath')=='finemath'

def test_real_embedded_payload_counts_and_integrity(tmp_path):
    m=extract(ROOT/'NEXUS_LittleBit_Recovery_Studio.html',tmp_path)
    assert m['total_stage_exposures']==10_000_000 and m['new_source_tokens']==8_000_000
    for i in range(1,6):
        a=np.fromfile(tmp_path/f'stage{i}.tokens.bin',dtype='<u4')
        assert len(a)==2_000_000 and a.max()<49152
    assert len(np.fromfile(tmp_path/'validation.tokens.bin',dtype='<u4'))==32768
    extract(ROOT/'NEXUS_LittleBit_Recovery_Studio.html',tmp_path) # idempotent
    (tmp_path/'stage1.tokens.bin').write_bytes(b'wrong')
    with pytest.raises(FileExistsError):extract(ROOT/'NEXUS_LittleBit_Recovery_Studio.html',tmp_path)

def test_corrupt_embedded_checksum_rejected(tmp_path):
    f=tmp_path/'bad.html'
    f.write_text('<script id="nexus-corpus-payload" type="application/octet-stream" data-sha256="'+('0'*64)+'">YWJj</script>')
    with pytest.raises(ValueError,match='SHA256'):embedded_zip(f)
