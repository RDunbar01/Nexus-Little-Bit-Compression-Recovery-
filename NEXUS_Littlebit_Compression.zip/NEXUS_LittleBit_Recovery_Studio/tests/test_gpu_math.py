import json,base64
from pathlib import Path
import numpy as np,torch,wgpu
from torch.nn import functional as F
ROOT=Path(__file__).parent
t=json.loads((ROOT/'autograd_trace.json').read_text());ks=json.loads((ROOT/'kernels.json').read_text())
d=wgpu.gpu.request_adapter_sync(power_preference='low-power').request_device_sync()
print('Adapter:',d.adapter.info,flush=True)
layout=d.create_bind_group_layout(entries=[{'binding':i,'visibility':wgpu.ShaderStage.COMPUTE,'buffer':{'type':'uniform' if i==4 else 'storage' if i==3 else 'read-only-storage'}} for i in range(5)])
pl=d.create_pipeline_layout(bind_group_layouts=[layout]);pipes={}
for name,code in ks.items():pipes[name]=d.create_compute_pipeline(layout=pl,compute={'module':d.create_shader_module(code=code),'entry_point':'main'})
print(len(pipes),'WGSL kernels compiled',flush=True)
bufs=[d.create_buffer(size=x['size'],usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.UNIFORM|wgpu.BufferUsage.COPY_SRC|wgpu.BufferUsage.COPY_DST) for x in t['buffers']]
for cmd in t['commands']:
 if 'write' in cmd:d.queue.write_buffer(bufs[cmd['write']],cmd['offset'],base64.b64decode(cmd['data']))
 elif 'kernel' in cmd:
  bg=d.create_bind_group(layout=layout,entries=[{'binding':i,'resource':{'buffer':bufs[b]}} for i,b in enumerate(cmd['bindings'])]);enc=d.create_command_encoder();p=enc.begin_compute_pass();p.set_pipeline(pipes[cmd['kernel']]);p.set_bind_group(0,bg);p.dispatch_workgroups(*cmd['groups']);p.end();d.queue.submit([enc.finish()])
 elif 'copy' in cmd:
  a,ao,b,bo,n=cmd['copy'];enc=d.create_command_encoder();enc.copy_buffer_to_buffer(bufs[a],ao,bufs[b],bo,n);d.queue.submit([enc.finish()])
def read(i):return np.frombuffer(d.queue.read_buffer(bufs[i]),dtype=np.float32).copy()
class Sign(torch.autograd.Function):
 @staticmethod
 def forward(ctx,x):ctx.save_for_backward(x);return torch.where(x>=0,1.,-1.)
 @staticmethod
 def backward(ctx,g):x,=ctx.saved_tensors;return g*100*(1-torch.tanh(100*x)**2)
params={name:torch.tensor(x['values']).reshape(x['shape']).requires_grad_() for name,x in t['data'].items()}
def half(x):return x+(x.half().float()-x).detach()
def factors(name):return [Sign.apply(params[name+'/'+k]) if k in ['u','v'] else half(params[name+'/'+k]) for k in ['u','v','h','g','l']]
def linear(name,x):
 u,v,h,g,l=factors(name);return ((x*g)@v.T*l)@u.T*h
u,v,h,g,l=factors('token_embd.weight');ids=torch.tensor(t['ids']);x=(u[ids]*l)@v*g*h[ids,None]
def norm(x):return x*torch.rsqrt(x.square().mean(-1,keepdim=True)+1e-5)
def rope(x,heads):
 x=x.reshape(3,heads,4);ang=torch.arange(3)[:,None,None]*100000**(-torch.arange(0,4,2).float()/4);cs=ang.cos();sn=ang.sin();return torch.stack((x[:,:,::2]*cs-x[:,:,1::2]*sn,x[:,:,::2]*sn+x[:,:,1::2]*cs),-1).flatten(2).reshape(3,heads*4)
a=norm(x);q=rope(linear('blk.0.attn_q.weight',a),2).reshape(3,2,4).transpose(0,1);k=rope(linear('blk.0.attn_k.weight',a),1).reshape(3,1,4).transpose(0,1).repeat_interleave(2,0);v=linear('blk.0.attn_v.weight',a).reshape(3,1,4).transpose(0,1).repeat_interleave(2,0)
s=q@k.transpose(-1,-2)/2;s=s.masked_fill(torch.ones(3,3,dtype=torch.bool).triu(1),-1e30);a=(s.softmax(-1)@v).transpose(0,1).reshape(3,8);x=x+linear('blk.0.attn_output.weight',a);a=norm(x);x=x+linear('blk.0.ffn_down.weight',F.silu(linear('blk.0.ffn_gate.weight',a))*linear('blk.0.ffn_up.weight',a));out=linear('token_embd.weight',norm(x));(out*torch.tensor(t['seed']).reshape(3,16)).sum().backward()
np.testing.assert_allclose(read(t['logits']),out.detach().numpy().ravel(),rtol=3e-3,atol=1e-6)
maxerr=0
for p in t['grads']:
 ref=params[p['name']].grad.numpy().ravel();got=read(p['buffer']);np.testing.assert_allclose(got,ref,rtol=1e-2,atol=2e-6,err_msg=p['name']);maxerr=max(maxerr,float(np.max(abs(got-ref))))
print('PASS: full tiny factorized transformer forward and all 40 gradients vs PyTorch; max absolute gradient error',maxerr)

def dispatch(name,a,b,c,n,params,groups=None):
 vals=[np.asarray(x,dtype='<f4').ravel() if x is not None else np.zeros(1,dtype='<f4') for x in [a,b,c]]
 bs=[d.create_buffer_with_data(data=x,usage=wgpu.BufferUsage.STORAGE) for x in vals]
 out=d.create_buffer(size=n*4,usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_SRC);p=d.create_buffer_with_data(data=np.array(params+[0]*(16-len(params)),dtype='<u4'),usage=wgpu.BufferUsage.UNIFORM)
 bg=d.create_bind_group(layout=layout,entries=[{'binding':i,'resource':{'buffer':buf}} for i,buf in enumerate(bs+[out,p])]);enc=d.create_command_encoder();pas=enc.begin_compute_pass();pas.set_pipeline(pipes[name]);pas.set_bind_group(0,bg);pas.dispatch_workgroups(*(groups or [(n+255)//256]));pas.end();d.queue.submit([enc.finish()]);result=np.frombuffer(d.queue.read_buffer(out),dtype='<f4').copy()
 for buf in bs+[out,p]:buf.destroy()
 return result

def bits(x):return int(np.array([x],dtype='<f4').view('<u4')[0])
rng=np.random.default_rng(72);logits=rng.normal(size=(3,16)).astype('f4')*7;teacher=rng.normal(size=(3,16)).astype('f4');labels=np.array([3,8,1],dtype='f4')
ps=dispatch('softmax',logits,None,None,48,[3,16],[3]);pt=dispatch('softmax',teacher,None,None,48,[3,16],[3]);grad=dispatch('logitgrad',ps,pt,labels,48,[48,16,bits(.2),3]);sl=torch.tensor(logits,requires_grad=True);tl=torch.tensor(teacher);loss=F.kl_div(F.log_softmax(sl,-1),F.softmax(tl,-1),reduction='batchmean')+.2*F.cross_entropy(sl,torch.tensor(labels,dtype=torch.long));loss.backward();np.testing.assert_allclose(grad,sl.grad.numpy().ravel(),rtol=1e-5,atol=1e-7)
nll=dispatch('nll',logits,labels,None,3,[3,16],[3]);np.testing.assert_allclose(nll,F.cross_entropy(torch.tensor(logits),torch.tensor(labels,dtype=torch.long),reduction='none').numpy(),rtol=1e-6,atol=1e-5)
p=rng.normal(size=17).astype('f4')*.01;param=torch.tensor(p.copy(),requires_grad=True);opt=torch.optim.Adam([param],lr=3e-5);m=np.zeros(17,'f4');v=m.copy()
for step in range(1,4):
 grad=rng.normal(size=17).astype('f4')*.1;param.grad=torch.tensor(grad);opt.step();m=dispatch('adamM',m,grad,None,17,[17,bits(1)]);v=dispatch('adamV',v,grad,None,17,[17,bits(1)]);p=dispatch('adamW',p,m,v,17,[17,bits(3e-5),bits(1-.9**step),bits(1-.999**step),0]);np.testing.assert_allclose(p,param.detach().numpy(),rtol=1e-5,atol=2e-8)
print('PASS: KL+CE gradients, stable NLL and three Adam updates against PyTorch')
