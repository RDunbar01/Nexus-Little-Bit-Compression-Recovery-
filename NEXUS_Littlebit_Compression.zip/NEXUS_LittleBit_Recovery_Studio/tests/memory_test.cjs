const fs=require('fs');require('../webgpu_autograd.js');
Object.assign(globalThis,{GPUBufferUsage:{STORAGE:128,COPY_DST:8,COPY_SRC:4,UNIFORM:64,MAP_READ:1},GPUShaderStage:{COMPUTE:4}});
fs.writeFileSync(__dirname+'/kernels.json',JSON.stringify(NexusQAT.kernels));
const buffers=[],commands=[],codes=[];
const device={limits:{maxStorageBufferBindingSize:2**30},createBuffer({size}){let b={id:buffers.length,size,destroy(){}};buffers.push({size});return b;},
 queue:{writeBuffer(buf,offset,data){let bytes=new Uint8Array(data.buffer||data,data.byteOffset||0,data.byteLength);commands.push({write:buf.id,offset,data:Buffer.from(bytes).toString('base64')});},submit(cmds){for(const c of cmds)commands.push(...c);},async onSubmittedWorkDone(){}},
 createBindGroupLayout(x){return x;},createPipelineLayout(x){return x;},createShaderModule({code}){return {code,async getCompilationInfo(){return {messages:[]}}}},async createComputePipelineAsync({compute}){return {code:compute.module.code,getBindGroupLayout(){return null;}};},createBindGroup({entries}){return entries.map(x=>x.resource.buffer.id)},
 createCommandEncoder(){const cmds=[];return {beginComputePass(){let p,b;return {setPipeline(x){p=x},setBindGroup(i,x){b=x},dispatchWorkgroups(...groups){const name=Object.keys(NexusQAT.kernels).find(n=>NexusQAT.kernels[n]===p.code);cmds.push({kernel:name,bindings:b,groups});},end(){}};},copyBufferToBuffer(a,ao,b,bo,n){cmds.push({copy:[a.id,ao,b.id,bo,n]});},finish(){return cmds;}};}};
(async()=>{
 const assert=require('assert');const g=await new NexusQAT.GPUAutograd(device).init();
 const p=g.parameter(new Float32Array(16),[4,4],'test/u');
 const base=g.memory;g.tensor(null,[100]);p.grad=g.tensor(null,[4,4]);
 await g.retain([p.grad]);assert.equal(g.memory,base+64);assert.equal(g.temp.length,1);
 g.maxBytes=g.memory;assert.throws(()=>g.tensor(null,[1]),/ceiling reached/);
 await g.abort();assert.equal(g.memory,base);assert.equal(g.temp.length,0);assert.equal(p.grad,null);
 g.maxBytes=4096;p.grad=g.tensor(null,[4,4]);g.read=async()=>{g.flush();return new Float32Array([1]);};
 await g.step(.001,1);assert.equal(g.temp.filter(t=>t.n===16).length,4);await g.clear();assert.equal(g.memory,base);
 // Allocation failure must precede every optimizer mutation.
 p.grad=g.tensor(null,[4,4]);g.maxBytes=g.memory+64;const before=commands.length;
 await assert.rejects(()=>g.step(.001,2),/ceiling reached/);
 assert(!commands.slice(before).some(c=>c.kernel?.startsWith('adam')));
 await g.abort();assert.equal(g.memory,base);
 console.log('PASS memory retention, abort cleanup, bounded optimizer scratch, pre-mutation allocation failure');
})();
