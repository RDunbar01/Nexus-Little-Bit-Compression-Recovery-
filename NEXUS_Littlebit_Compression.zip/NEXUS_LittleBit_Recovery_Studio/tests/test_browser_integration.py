"""Opt-in Chrome/Edge regression; requires playwright and Chromium installed.
Run NEXUS_TEST_BROWSER=1 pytest -q tests/test_browser_integration.py
"""
import os
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import pytest
from gguf_factors import GGUF
from test_recovery_end_to_end import fixture_files

if os.environ.get('NEXUS_TEST_BROWSER')!='1':
    pytest.skip('Browser test is opt-in (NEXUS_TEST_BROWSER=1)',allow_module_level=True)
playwright=pytest.importorskip('playwright.sync_api')


def test_browser_factor_export_and_budget(tmp_path):
    html=(Path(__file__).parents[1]/'NEXUS_LittleBit_Recovery_Studio.html').read_text()
    fixture=fixture_files(tmp_path/'model')
    with playwright.sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
        page=browser.new_page(accept_downloads=True)
        errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
        page.goto((ROOT/'NEXUS_LittleBit_Recovery_Studio.html').as_uri(),wait_until='domcontentloaded')
        assert page.input_value('#optBpw')=='0.5'
        assert page.input_value('#optEmbedBpw')=='2'
        page.locator('#budgetMillions').fill('100000')
        assert page.evaluate('window.nexusRecoveryStudio.recipe().budget_tokens')==100_000_000_000
        page.set_input_files('#file',str(fixture[0]))
        page.wait_for_function("!document.querySelector('#info').classList.contains('hidden')",timeout=15000)
        page.locator('#optRes').uncheck()
        page.locator('#optBpw').fill('4')
        page.locator('#optEmbedBpw').fill('2')
        for k,v in [('optAls','1'),('optItq','0'),('optBackfit','0'),('optPow','0')]:page.locator('#'+k).fill(v)
        page.locator('#optGPU').select_option('cpu');page.locator('#outRecon').uncheck()
        assert page.locator('#go').is_enabled()
        page.locator('#go').click()
        page.wait_for_function("document.getElementById('status').textContent.includes('Downloads are ready')",timeout=90000)
        with page.expect_download(timeout=15000) as evt:page.locator('#downloads a').first.click()
        exported=tmp_path/'converted.lb.gguf';evt.value.save_as(exported)
        with GGUF(exported) as fac:
            assert len(fac.factor_names())==8 and fac.factor('token_embd.weight')
        assert not errors
        browser.close()


def test_embedded_corpus_export_and_recipe(tmp_path):
    import zipfile,json
    with playwright.sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path=os.environ['CHROMIUM_PATH'],args=['--no-sandbox'])
        page=browser.new_page(accept_downloads=True,viewport={'width':1440,'height':1000})
        errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
        page.goto((ROOT/'NEXUS_LittleBit_Recovery_Studio.html').as_uri())
        assert page.evaluate('nexusRecoveryStudio.recipe().lr_schedule')=='cosine'
        page.locator('#inspectEmbeddedCorpus').click()
        assert '8000000' in page.locator('#embeddedCorpusManifest').inner_text()
        page.locator('#inspectEmbeddedCorpus').click()
        with page.expect_download() as event:page.locator('#exportEmbeddedCorpus').click()
        path=tmp_path/'corpus.zip';event.value.save_as(path)
        with zipfile.ZipFile(path) as z:
            assert len(z.namelist())==7
            assert len(z.read('stage1.tokens.bin'))==8_000_000
            assert json.loads(z.read('manifest.json'))['validation_tokens']==32768
        assert 'SHA-256 verified' in page.locator('#embeddedCorpusStatus').inner_text()
        page.screenshot(path=str(ROOT/'browser-validation.png'))
        assert not errors
        browser.close()
