"""Local executable integration probes. Synthetic tiny weights are NOT SmolLM2 quality evidence."""
from __future__ import annotations
import json
import math
import os
from pathlib import Path
import shutil
import struct
import sys
import types
import zlib

import numpy as np
import pytest
import torch
from torch import nn

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from gguf_factors import GGUF, unpack_bpw
import recovery
import corpus_builder

D=32;VOCAB=64

class SmallTokenizer:
    vocab_size=VOCAB
    eos_token_id=2
    @classmethod
    def from_pretrained(cls,*a,**kw):return cls()
    def encode(self,text,add_special_tokens=False):return [ord(x)%VOCAB for x in text]
    def apply_chat_template(self,msgs,tokenize=True,add_generation_prompt=False):
        return self.encode(''.join(v.get('content','') for v in msgs))

class TinyLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.input_layernorm=nn.LayerNorm(D)
        self.post_attention_layernorm=nn.LayerNorm(D)
        self.self_attn=nn.Module()
        for key in ('q_proj','k_proj','v_proj','o_proj'):
            setattr(self.self_attn,key,nn.Linear(D,D,bias=False))
        self.mlp=nn.Module()
        for key in ('gate_proj','up_proj','down_proj'):
            setattr(self.mlp,key,nn.Linear(D,D,bias=False))
    def forward(self,x):
        z=self.input_layernorm(x)
        sa=self.self_attn
        x=x+sa.o_proj(torch.tanh((sa.q_proj(z)+sa.k_proj(z)+sa.v_proj(z))/3))
        z=self.post_attention_layernorm(x)
        return x+self.mlp.down_proj(torch.tanh(self.mlp.gate_proj(z))*torch.tanh(self.mlp.up_proj(z)))

class TinyLM(nn.Module):
    def __init__(self):
        super().__init__();torch.manual_seed(91)
        self.config=types.SimpleNamespace(model_type='llama',num_attention_heads=2,
            num_key_value_heads=2,num_hidden_layers=1,vocab_size=VOCAB,
            tie_word_embeddings=True,use_cache=False)
        self.model=nn.Module()
        self.model.embed_tokens=nn.Embedding(VOCAB,D)
        self.model.layers=nn.ModuleList([TinyLayer()])
        self.model.norm=nn.LayerNorm(D)
        self.lm_head=nn.Linear(D,VOCAB,bias=False)
        self.lm_head.weight=self.model.embed_tokens.weight
    @classmethod
    def from_pretrained(cls,*a,**kw):return cls()
    def forward(self,input_ids,output_hidden_states=False,use_cache=False):
        x=self.model.embed_tokens(input_ids)
        h=[x]
        for layer in self.model.layers:x=layer(x);h.append(x)
        return types.SimpleNamespace(logits=self.lm_head(self.model.norm(x)),hidden_states=h)

@pytest.fixture(autouse=True)
def fake_hf(monkeypatch):
    mod=types.ModuleType('transformers')
    mod.AutoModelForCausalLM=TinyLM
    mod.AutoTokenizer=SmallTokenizer
    monkeypatch.setitem(sys.modules,'transformers',mod)
    torch.set_num_threads(1)


def gguf_string(value):
    x=value.encode('utf8')
    return struct.pack('<Q',len(x))+x

def gguf_header(metadata,tensors):
    out=bytearray(b'GGUF'+struct.pack('<IQQ',3,len(tensors),len(metadata)))
    for key,(typ,v) in metadata.items():
        out+=gguf_string(key)+struct.pack('<I',typ)
        if typ==8:out+=gguf_string(v)
        elif typ==4:out+=struct.pack('<I',v)
        elif typ==6:out+=struct.pack('<f',v)
        elif typ==9:
            out+=struct.pack('<IQ',v[0],len(v[1]))
            for val in v[1]:out+=gguf_string(val) if v[0]==8 else struct.pack('<I',val)
        else:raise NotImplementedError(typ)
    for name,dims,typ,off,raw in tensors:
        out+=gguf_string(name)+struct.pack('<I',len(dims))+b''.join(struct.pack('<Q',x) for x in dims)+struct.pack('<IQ',typ,off)
    return out+b'\0'*((-len(out))%32)


def write_gguf(path,metadata,items):
    offset=0;tensors=[]
    for name,dims,typ,raw in items:
        offset=(offset+31)//32*32
        tensors.append((name,dims,typ,offset,raw));offset+=len(raw)
    header=gguf_header(metadata,tensors)
    out=bytearray(header+b'\0'*((offset+31)//32*32))
    for _,_,_,off,raw in tensors:out[len(header)+off:len(header)+off+len(raw)]=raw
    path.write_bytes(out)


def q8(x):
    x=np.asarray(x,dtype=np.float32).reshape(-1,32)
    raw=bytearray()
    for row in x:
        scale=(max(1e-8,float(np.max(np.abs(row)))/127))
        raw+=np.float16(scale).tobytes()
        raw+=np.clip(np.rint(row/scale),-127,127).astype(np.int8).tobytes()
    return bytes(raw)


def fixture_files(d):
    d=Path(d);d.mkdir(parents=True,exist_ok=True)
    (d/'hf').mkdir(exist_ok=True)
    (d/'hf'/'config.json').write_text('{"model_type":"llama"}')
    (d/'hf'/'tokenizer.json').write_text('{"tokenizer":"toy-only"}')
    model=TinyLM()
    def tensors():
        yield 'token_embd.weight',model.model.embed_tokens.weight.detach().numpy()
        layer=model.model.layers[0]
        for key,m in [('attn_q',layer.self_attn.q_proj),('attn_k',layer.self_attn.k_proj),
                      ('attn_v',layer.self_attn.v_proj),('attn_output',layer.self_attn.o_proj),
                      ('ffn_gate',layer.mlp.gate_proj),('ffn_up',layer.mlp.up_proj),
                      ('ffn_down',layer.mlp.down_proj)]:yield f'blk.0.{key}.weight',m.weight.detach().numpy()
        yield 'blk.0.attn_norm.weight',layer.input_layernorm.weight.detach().numpy()
        yield 'blk.0.ffn_norm.weight',layer.post_attention_layernorm.weight.detach().numpy()
        yield 'output_norm.weight',model.model.norm.weight.detach().numpy()
    base={name:np.asarray(arr).copy() for name,arr in tensors()}
    model_meta={'general.architecture':(8,'llama'),'general.alignment':(4,32),
                'llama.block_count':(4,1),'llama.embedding_length':(4,D)}
    original=[]
    for name,x in base.items():
        if x.ndim==1:original.append((name,[len(x)],0,x.astype('<f4').tobytes()))
        else: original.append((name,list(reversed(x.shape)),8,q8(x)))
    src=d/'toy-q8.gguf';write_gguf(src,model_meta,original)
    # test factor file uses the exact GGUF packed layout, sign=1 means + and 1 bit means -.
    factors={}
    for name,x in base.items():
        if x.ndim!=2:continue
        paths=[]
        for j in range(1):
            rng=np.random.default_rng(zlib.crc32(name.encode())+j)
            r=8;m,n=x.shape
            paths.append({'u':rng.choice([-1,1],size=(m,r)).astype(np.float32),
                          'v':rng.choice([-1,1],size=(r,n)).astype(np.float32),
                          'h':np.full(m,.01,dtype=np.float32),'g':np.ones(n,dtype=np.float32),
                          'l':np.full(r,.02,dtype=np.float32)})
        factors[name]=paths
    # keep GGUF norms unchanged; factorized model includes tied embedding and seven matrix types.
    meta=dict(model_meta)
    meta.update({'littlebit.role':(8,'littlebit-factors'),
                 'littlebit.recovery_training':(8,'none (post-training init only; paper uses QAT + distillation)'),
                 'littlebit.tensors':(9,(8,list(factors))),
                 'littlebit.bpw':(6,.5)})
    facitems=[]
    for name,x in base.items():
        if name not in factors:
            facitems.append((name,[len(x)],0,x.astype('<f4').tobytes()))
            continue
        m,n=x.shape
        for pi,p in enumerate(factors[name]):
            prefix=name.replace('.weight','')+f'.lb{pi}.'
            for field,arr in (('u',p['u']),('vt',p['v']),('h',p['h']),('g',p['g']),('l',p['l'])):
                if field=='u':typ=24;dims=[8//8,m];raw=np.packbits((arr<0).astype('u1'),axis=1,bitorder='little').tobytes()
                elif field=='vt':typ=24;dims=[n//8,8];raw=np.packbits((arr<0).astype('u1'),axis=1,bitorder='little').tobytes()
                else:typ=1;dims=[len(arr)];raw=arr.astype('<f2').tobytes()
                facitems.append((prefix+field,dims,typ,raw))
    factorfile=d/'toy-lb.gguf';write_gguf(factorfile,meta,facitems)
    corp=d/'corpus';corp.mkdir(exist_ok=True)
    for stage in range(1,6):
        data=np.random.default_rng(100+stage).integers(0,VOCAB,size=96,dtype=np.uint32)
        data.tofile(corp/f'stage{stage}.tokens.bin')
    np.random.default_rng(909).integers(0,VOCAB,size=96,dtype=np.uint32).tofile(corp/'validation.tokens.bin')
    (corp/'manifest.json').write_text(json.dumps({'format':2,'sha256':{f.name:recovery.sha256_file(f) for f in corp.glob('*.tokens.bin')}}))
    return src,factorfile,corp,d/'hf'


def make_recipe(out,fixtures,mode='new',checkpoint=''):
    src,fac,corp,hf=fixtures
    return {'factor_gguf':str(fac),'q8_gguf':str(src),'hf_model':str(hf),
            'corpus_dir':str(corp),'output_dir':str(out),'checkpoint':checkpoint,
            'mode':mode,'budget_tokens':80,'seq_len':8,'batch_size':1,
            'seed':900,'checkpoint_every':1,'retain':3,'validation_tokens':17,
            'device':'cpu','lr':.001,'log_every':1}


def test_real_gguf_and_numerical_forward(tmp_path):
    files=fixture_files(tmp_path)
    with GGUF(files[1]) as f:
        assert len(f.factor_names())==8
        assert f.factor('token_embd.weight')[0]['u'].shape==(VOCAB,8)
        assert f.metadata['general.architecture']=='llama'
        assert unpack_bpw(f)>0
    teacher,student,tok,mapping,label=recovery.build_networks(make_recipe(tmp_path/'run',files),'cpu')
    a=torch.tensor([[1,2,3,4]])
    assert student(a).logits.shape==(1,4,VOCAB)
    assert label.startswith('Original Q8')
    metrics=recovery.perplexity(student,np.arange(20,dtype=np.uint32),'cpu',seq_len=8,max_tokens=17)
    assert metrics['tokens']>=12 and math.isfinite(metrics['ppl'])
    for name,fx in mapping.items():
        W=sum(torch.outer(p.h,p.g)*(recovery.SmoothSign.apply(p.u)@torch.diag(p.l)@recovery.SmoothSign.apply(p.v))
              for p in fx.paths)
        x=torch.randn((2,fx.in_features))
        assert torch.allclose(fx(x),x@W.T,rtol=1e-3,atol=2e-3),name


def test_five_stage_checkpoint_resume_cycle(tmp_path,monkeypatch):
    files=fixture_files(tmp_path/'data')
    baseline=make_recipe(tmp_path/'base',files)
    full=recovery.run(baseline)
    assert full['status']=='complete' and full['exposures']==80
    assert math.isfinite(full['original_baseline']['ppl'])
    assert math.isfinite(full['pre']['ppl']) and math.isfinite(full['post']['ppl'])
    assert Path(full['recovered_file']).is_file()
    # An interrupted run must restart at its exact optimizer/RNG/window state.
    org=recovery.checkpoint_record
    def interrupt(run,*args,**kw):
        result=org(run,*args,**kw)
        if int(args[2])==3:(Path(run)/'STOP').touch()
        return result
    monkeypatch.setattr(recovery,'checkpoint_record',interrupt)
    interrupted=make_recipe(tmp_path/'interrupted',files)
    paused=recovery.run(interrupted)
    assert paused['status']=='paused'
    monkeypatch.setattr(recovery,'checkpoint_record',org)
    continuation=dict(interrupted,mode='resume',checkpoint=str(tmp_path/'interrupted'/'latest.pt'))
    resumed=recovery.run(continuation)
    assert resumed['exposures']==80
    assert resumed['post']['ppl']==pytest.approx(full['post']['ppl'],abs=1e-7)
    assert resumed['post']['nll']==pytest.approx(full['post']['nll'],abs=1e-7)
    # Additional cycle is not a fake metric: it starts from actual trained state.
    cycle=make_recipe(tmp_path/'cycle2',files,mode='cycle',checkpoint=str(tmp_path/'base'/'latest.pt'))
    cy=recovery.run(cycle)
    assert cy['mode']=='cycle'
    assert cy['pre']['ppl']==pytest.approx(full['post']['ppl'],abs=1e-7)
    assert cy['parent_checkpoint_sha256']==recovery.sha256_file(cycle['checkpoint'])
    assert cy['exposures']==80


def test_corpus_buckets_and_import(tmp_path):
    assert corpus_builder.category('dclm_edu')=='dclm'
    assert corpus_builder.category('fineweb_edu')=='fineweb'
    assert corpus_builder.category('finemath')=='finemath'
    assert corpus_builder.category('infimm_webmath')=='infimm'
    assert corpus_builder.category('cosmopedia_v2')=='cosmopedia'
    assert corpus_builder.category('stack_edu')=='stack'
    assert sum(corpus_builder.stage_mix(0,20).values())==20
    assert sum(corpus_builder.stage_mix(1,20).values())==20
    assert sum(corpus_builder.stage_mix(2,20).values())==20
    texts=tmp_path/'texts';texts.mkdir()
    for i in range(1,6):(texts/f'stage{i}.txt').write_text('This is real locally supplied training text. '*9)
    (texts/'validation.txt').write_text('This is a distinct held-out validation sample. '*8)
    arrays,val,prov=corpus_builder.local_import(texts,40,20,SmallTokenizer())
    assert all(len(x)==40 for x in arrays) and len(val)==20
    assert prov['import_dir']==str(texts.resolve())
    with pytest.raises(ValueError):corpus_builder.local_import(texts,99999,20,SmallTokenizer())


def test_interleave_preserves_training_mix():
    a=np.full(120,10,dtype=np.uint32);b=np.full(80,11,dtype=np.uint32)
    arr=corpus_builder.interleave([a,b],200)
    assert len(arr)==200
    assert (arr==10).sum()==120
    assert (arr==11).sum()==80
    assert len(corpus_builder.interleave([a,b],500))==500  # explicit stage replay
