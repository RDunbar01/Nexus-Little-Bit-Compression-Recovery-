const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'../NEXUS_LittleBit_Recovery_Studio.html'),'utf8');
const core=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('root.LittleBit ='));
vm.runInThisContext(core);const LB=globalThis.LittleBit;
const tensors=[];function add(name,n,m){tensors.push({name,dims:[n,m],type:8,index:tensors.length})}
for(let i=0;i<30;i++)for(const [name,n,m] of [['attn_q',576,576],['attn_k',576,192],['attn_v',576,192],['attn_output',576,576],['ffn_gate',576,1536],['ffn_up',576,1536],['ffn_down',1536,576]])add(`blk.${i}.${name}.weight`,n,m);
add('token_embd.weight',576,49152);
const model={arch:'llama',kv:{'llama.block_count':{value:30}},tensors},opts={targetBpw:.5,embeddingBpw:2,binarizeEmbd:true,residual:true,resFrac:.5};
let p=LB.planByGroup(model,opts);assert(p.bpw>.5);assert(p.projectionBpw<=.5);assert(p.embeddingBpw<=2);assert(LB.validatePlanBudget(p));
let bad=structuredClone(p);bad.items[0].r1=10000;assert.throws(()=>LB.validatePlanBudget(bad),/projection bit budget/);
bad=structuredClone(p);bad.embeddingTarget=.1;assert.throws(()=>LB.validatePlanBudget(bad),/embedding bit budget/);
assert.throws(()=>LB.validatePlanBudget(LB.planByGroup(model,{...opts,targetBpw:.1})),/infeasible/);
assert(LB.validatePlanBudget(LB.planByGroup(model,{...opts,binarizeEmbd:false})));
console.log('PASS: SmolLM2 211-matrix 0.5/2 mixed budget accepted; projection/embedding overruns and infeasible .1 rejected; projections-only accepted.');
