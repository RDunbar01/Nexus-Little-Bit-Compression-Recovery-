"""Exercise an elementwise tensor exceeding WebGPU's 65535-workgroup X limit."""
import json
from pathlib import Path
import numpy as np, wgpu
k=json.loads((Path(__file__).parent/'kernels.json').read_text())
d=wgpu.gpu.request_adapter_sync(power_preference='low-power').request_device_sync()
n=65535*256+513
x=np.ones(n,dtype='f4');x[-513:]=-1
layout=d.create_bind_group_layout(entries=[{'binding':i,'visibility':wgpu.ShaderStage.COMPUTE,'buffer':{'type':'uniform' if i==4 else 'storage' if i==3 else 'read-only-storage'}} for i in range(5)])
p=d.create_compute_pipeline(layout=d.create_pipeline_layout(bind_group_layouts=[layout]),compute={'module':d.create_shader_module(code=k['sign']),'entry_point':'main'})
b=[d.create_buffer_with_data(data=x,usage=wgpu.BufferUsage.STORAGE),d.create_buffer(size=4,usage=wgpu.BufferUsage.STORAGE),d.create_buffer(size=4,usage=wgpu.BufferUsage.STORAGE),d.create_buffer(size=n*4,usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_SRC),d.create_buffer_with_data(data=np.array([n]+[0]*15,dtype='u4'),usage=wgpu.BufferUsage.UNIFORM)]
bg=d.create_bind_group(layout=layout,entries=[{'binding':i,'resource':{'buffer':v}} for i,v in enumerate(b)])
e=d.create_command_encoder();c=e.begin_compute_pass();c.set_pipeline(p);c.set_bind_group(0,bg);c.dispatch_workgroups(65535,2);c.end();d.queue.submit([e.finish()]);out=np.frombuffer(d.queue.read_buffer(b[3]),dtype='f4');np.testing.assert_array_equal(out,x)
print('PASS: 16,777,473-element sign operation crosses the 65535 X-workgroup boundary correctly.')
