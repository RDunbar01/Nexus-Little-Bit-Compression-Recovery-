const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const {JSDOM,VirtualConsole}=require('jsdom');
const path=require('path').resolve(__dirname,'../NEXUS_LittleBit_Recovery_Studio.html');
const html=fs.readFileSync(path,'utf8');
let count=0;
for(const m of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)){
 if(/application\/(json|octet-stream)/.test(m[1]))continue;
 new vm.Script(m[2]);count++;
}
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
let exported;
const dom=new JSDOM(html,{url:'file://'+path,runScripts:'dangerously',virtualConsole:vc,beforeParse(w){
 w.TextEncoder=TextEncoder;w.TextDecoder=TextDecoder;w.URL.createObjectURL=b=>{exported=b;return 'blob:test';};w.URL.revokeObjectURL=()=>{};
 w.HTMLAnchorElement.prototype.click=function(){};
 Object.defineProperty(w.crypto,'subtle',{value:crypto.webcrypto.subtle});
 w.setTimeout=(f,ms)=>{if(ms<1000)return setTimeout(f,ms);return 0;};
}});
(async()=>{
 const w=dom.window,d=w.document;
 assert.equal(w.nexusRecoveryStudio.recipe().lr_schedule,'cosine');
 d.getElementById('budgetMillions').value='100000';
 assert.equal(w.nexusRecoveryStudio.recipe().budget_tokens,100000000000);
 d.getElementById('inspectEmbeddedCorpus').click();
 assert(d.getElementById('embeddedCorpusManifest').textContent.includes('8000000'));
 await d.getElementById('exportEmbeddedCorpus').onclick();
 assert(exported.size>13000000);
 assert(d.getElementById('embeddedCorpusStatus').textContent.includes('SHA-256 verified'));
 await d.getElementById('startCorpus').onclick();
 assert(d.getElementById('corpusBuildStatus').textContent.includes('already ready'));
 await d.getElementById('startGPUCompress').onclick();
 assert(d.getElementById('compressionStatus').textContent.includes('Compression failed:'));
 assert(!d.getElementById('startGPUCompress').disabled);
 assert.deepEqual(errors,[]);
 console.log(`${count} JavaScript blocks parsed; DOM recipe, 100B exposure limit, provenance, embedded ZIP export and SHA-256 checks passed. This is jsdom, not a real browser.`);
 dom.window.close();
})().catch(e=>{console.error(e);process.exit(1)});
