"""Safety checks for provenance and proper SmolLM2-135M datasets."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import corpus_builder


def test_instruction_source_matches_135m_not_17b():
    assert corpus_builder.REPOS['instruction'] == ('HuggingFaceTB/smol-smoltalk', None, 'train')


def test_dclm_fineweb_60_40_and_disjoint_categories():
    mix=corpus_builder.stage_mix(0,2_000_000)
    assert mix == {'dclm':1_200_000,'fineweb':800_000}
    assert set(mix).isdisjoint(corpus_builder.stage_mix(1,2_000_000))


def test_token_mix_proportions_stay_exact():
    import numpy as np
    a=np.ones(60,dtype='<u4');b=np.full(40,2,dtype='<u4')
    data=corpus_builder.interleave([a,b],100)
    assert len(data)==100
    assert (data==1).sum()==60
    assert (data==2).sum()==40
