const fs=require('fs');require('../webgpu_autograd.js');
Object.assign(globalThis,{GPUBufferUsage:{STORAGE:128,COPY_DST:8,COPY_SRC:4,UNIFORM:64,MAP_READ:1},GPUShaderStage:{COMPUTE:4}});
fs.writeFileSync(__dirname+'/kernels.json',JSON.stringify(NexusQAT.kernels));
const buffers=[],commands=[],codes=[];
const device={limits:{maxStorageBufferBindingSize:2**30},createBuffer({size}){let b={id:buffers.length,size,destroy(){}};buffers.push({size});return b;},
 queue:{writeBuffer(buf,offset,data){let bytes=new Uint8Array(data.buffer||data,data.byteOffset||0,data.byteLength);commands.push({write:buf.id,offset,data:Buffer.from(bytes).toString('base64')});},submit(cmds){for(const c of cmds)commands.push(...c);},async onSubmittedWorkDone(){}},
 createBindGroupLayout(x){return x;},createPipelineLayout(x){return x;},createShaderModule({code}){return {code,async getCompilationInfo(){return {messages:[]}}}},async createComputePipelineAsync({compute}){return {code:compute.module.code,getBindGroupLayout(){return null;}};},createBindGroup({entries}){return entries.map(x=>x.resource.buffer.id)},
 createCommandEncoder(){const cmds=[];return {beginComputePass(){let p,b;return {setPipeline(x){p=x},setBindGroup(i,x){b=x},dispatchWorkgroups(...groups){const name=Object.keys(NexusQAT.kernels).find(n=>NexusQAT.kernels[n]===p.code);cmds.push({kernel:name,bindings:b,groups});},end(){}};},copyBufferToBuffer(a,ao,b,bo,n){cmds.push({copy:[a.id,ao,b.id,bo,n]});},finish(){return cmds;}};}};
(async()=>{
 const g=await new NexusQAT.GPUAutograd(device).init(),config={layers:1,dim:8,heads:2,kv:1,hd:4,eps:1e-5,theta:100000};
 const model=new NexusQAT.SmolTrainingModel(g,config),data={};let serial=1;
 const mk=(shape,name,sign=false)=>{let n=shape.reduce((a,b)=>a*b),a=Float32Array.from({length:n},(_,i)=>sign?.01*Math.sin((i+serial)*1.33):.1+.03*Math.cos((i+serial)*1.7));serial+=n;data[name]={shape,values:[...a]};return g.parameter(a,shape,name);};
 function factor(name,rows,cols){const rank=4;const p={u:mk([rows,rank],name+'/u',true),v:mk([rank,cols],name+'/v',true),h:mk([rows],name+'/h'),g:mk([cols],name+'/g'),l:mk([rank],name+'/l')};model.weights.set(name,{paths:[p]});}
 factor('token_embd.weight',16,8);model.weights.set('output.weight',model.weights.get('token_embd.weight'));
 for(const [n,m,k] of [['attn_q',8,8],['attn_k',4,8],['attn_v',4,8],['attn_output',8,8],['ffn_gate',12,8],['ffn_up',12,8],['ffn_down',8,12]])factor('blk.0.'+n+'.weight',m,k);
 for(const n of ['blk.0.attn_norm.weight','blk.0.ffn_norm.weight','output_norm.weight'])model.weights.set(n,{dense:model.constant(new Float32Array(8).fill(1),[8])});
 const ids=g.tensor([1,4,1],[3]),result=model.forward(ids,true);
 const target=Float32Array.from({length:48},(_,i)=>Math.sin(i*.9)*.01),seed=g.tensor(target,[3,16]);g.backward([[result.logits,seed]]);g.flush();
 fs.writeFileSync(__dirname+'/autograd_trace.json',JSON.stringify({buffers,commands,config,data,ids:[1,4,1],seed:[...target],logits:result.logits.buf.id,grads:g.params.map(p=>({name:p.name,buffer:p.grad?.buf.id,shape:p.shape}))}));
 console.log('Recorded',commands.filter(c=>c.kernel).length,'GPU dispatches and',g.params.length,'parameter gradients');
})();
