"""PyTorch full-compression integration; CPU hardware tests, GPU guarded."""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
import types
import pytest
import torch
import recovery
from gguf_factors import GGUF
import torch_compress
from test_recovery_end_to_end import fixture_files, make_recipe, SmallTokenizer,TinyLM


def args(src,out,device='cpu'):
    return argparse.Namespace(q8_gguf=str(src),output=str(out),weights_bpw=4.0,
        embeddings_bpw=2.0,residual=False,split=0.5,als=1,power=0,itq=0,
        edge=1.,kv=1.,seed=20261007,device=device)


def test_torch_compress_into_real_qat(tmp_path,monkeypatch):
    fixture=fixture_files(tmp_path/'input')
    out=tmp_path/'new.lb.gguf'
    result=torch_compress.run(args(fixture[0],out))
    assert result['matrix_count']==8 and result['packed_bpw']<=4
    with GGUF(out) as g:
        assert g.factor_names() and len(g.factor_names())==8
        assert g.metadata['littlebit.role']=='littlebit-factors'
        assert g.metadata['general.architecture']=='llama'
        assert g.metadata['llama.block_count']==1
        assert g.metadata['littlebit.bpw_file']>0
        assert len(g.factor('token_embd.weight'))==1
    mod=types.ModuleType('transformers')
    mod.AutoModelForCausalLM=TinyLM
    mod.AutoTokenizer=SmallTokenizer
    monkeypatch.setitem(sys.modules,'transformers',mod)
    original=tuple(fixture)
    rec=make_recipe(tmp_path/'run',(fixture[0],out,fixture[2],fixture[3]))
    result=recovery.run(rec)
    assert result['status']=='complete' and result['exposures']==80
    assert result['checkpoint_format']==3
    ckpt=torch.load(tmp_path/'run'/'latest.pt',weights_only=False)
    assert ckpt['format']==3 and 'student' not in ckpt and ckpt['factor_state']


def test_unsupported_low_bpw_is_refused(tmp_path):
    fixture=fixture_files(tmp_path/'input')
    setting=args(fixture[0],tmp_path/'fail.lb.gguf')
    setting.weights_bpw=.1
    with pytest.raises(ValueError,match='infeasible'):
        torch_compress.run(setting)


def test_require_real_gpu(tmp_path,monkeypatch):
    fixture=fixture_files(tmp_path/'input')
    setting=args(fixture[0],tmp_path/'never.lb.gguf',device='cuda')
    monkeypatch.setattr(torch.cuda,'is_available',lambda:False)
    with pytest.raises(RuntimeError,match='unavailable'):
        torch_compress.run(setting)
