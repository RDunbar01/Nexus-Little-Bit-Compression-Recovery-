from pathlib import Path
import wgpu,json,numpy as np
r=Path(__file__).parent;d=wgpu.gpu.request_adapter_sync(power_preference='low-power').request_device_sync();ks=json.loads((r/'inference_shaders.json').read_text());pipes={n:d.create_compute_pipeline(layout='auto',compute={'module':d.create_shader_module(code=s),'entry_point':'main'}) for n,s in ks.items()};print(len(pipes),'inference pipelines compiled')
def invoke(name,values,outsize,output_binding,uniform_binding,groups):
 p=pipes[name];bs=[]
 for i,value in enumerate(values):
  a=np.frombuffer(value,dtype='u1') if isinstance(value,bytes) else np.asarray(value).view('u1').ravel();padded=np.zeros(max(4,(len(a)+3)//4*4),'u1');padded[:len(a)]=a
  bs.append(d.create_buffer_with_data(data=padded,usage=(wgpu.BufferUsage.UNIFORM if i==uniform_binding else wgpu.BufferUsage.STORAGE)|wgpu.BufferUsage.COPY_SRC))
 bg=d.create_bind_group(layout=p.get_bind_group_layout(0),entries=[{'binding':i,'resource':{'buffer':b}} for i,b in enumerate(bs)]);e=d.create_command_encoder();pas=e.begin_compute_pass();pas.set_pipeline(p);pas.set_bind_group(0,bg);pas.dispatch_workgroups(*groups);pas.end();d.queue.submit([e.finish()]);out=np.frombuffer(d.queue.read_buffer(bs[output_binding]),dtype='<f4').copy()[:outsize]
 for b in bs:b.destroy()
 return out
rng=np.random.default_rng(125);rows,cols,rank=5,32,8;u=rng.choice([-1.,1.],(rows,rank)).astype('f4');v=rng.choice([-1.,1.],(rank,cols)).astype('f4');h=rng.normal(size=rows).astype('f4');g=rng.normal(size=cols).astype('f4');l=rng.normal(size=rank).astype('f4');x=rng.normal(size=cols).astype('f4');up=np.packbits(u<0,axis=None,bitorder='little');vp=np.packbits(v<0,axis=None,bitorder='little')
z=invoke('packedFactors',[vp,x,g,l,np.zeros(rank,'f4'),np.array([cols,rank,0,0],'u4')],rank,4,5,[rank]);y=invoke('packedFactors',[up,z,l,h,np.zeros(rows,'f4'),np.array([rank,rows,1,0],'u4')],rows,4,5,[rows]);expected=h*(u@(l*(v@(g*x))));np.testing.assert_allclose(y,expected,rtol=1e-5,atol=1e-5)
y=invoke('Packed LittleBit embedding',[up,vp,h,g,l,np.zeros(cols,'f4'),np.array([cols,rank,3,0],'u4')],cols,5,6,[1]);np.testing.assert_allclose(y,(u[3]*l)@v*h[3]*g,rtol=1e-5,atol=1e-6)
# Actual Q8 bytes independently generated using binary16 scales.
q=rng.integers(-127,128,size=(3,64),dtype=np.int8);scale=np.array([[.01,.02],[.03,.01],[.02,.04]],dtype='<f2');raw=bytearray()
for i in range(3):
 for j in range(2):raw+=scale[i,j].tobytes()+q[i,j*32:j*32+32].tobytes()
x=rng.normal(size=64).astype('f4');out=invoke('NEXUS QuantMatmul shader',[bytes(raw),x,np.zeros(3,'f4'),np.array([3,64,8,68,0,0,0,0],'u4')],3,2,3,[3]);ref=(q.astype('f4')*np.repeat(scale.astype('f4'),32,axis=1))@x;np.testing.assert_allclose(out,ref,rtol=1e-5,atol=2e-6)
print('PASS: packed-factor matvec, packed embedding and Q8 dot products against independent NumPy references')
