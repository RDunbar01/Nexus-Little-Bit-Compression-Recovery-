const fs=require('fs'),vm=require('vm'),{JSDOM,VirtualConsole}=require('jsdom');
const html=fs.readFileSync(require('path').resolve(__dirname,'../Nexus_Web_LLM.html'),'utf8').replace('bootStable();','/* test controlled boot */');
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(html,{url:'https://localhost/',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.TextEncoder=TextEncoder;w.TextDecoder=TextDecoder;w.structuredClone=structuredClone;w.Response=Response;w.DecompressionStream=DecompressionStream;w.Blob=Blob;w.URL.createObjectURL=()=>'';w.URL.revokeObjectURL=()=>{};w.setInterval=()=>0;w.setTimeout=()=>0;Object.defineProperty(w.crypto,'subtle',{value:require('crypto').webcrypto.subtle});}});
console.log('errors',errors);
(async()=>{
 const {GGUF}= {};const raw=fs.readFileSync(process.argv[2]||'smol-q8.gguf');const reader={read:async(o,n)=>new Uint8Array(raw.subarray(o,o+n)),file:{size:raw.length},header:{}};
 const api=dom.window.NexusEngineAPI;const base=await api.parseGGUF(reader),em=await api.buildExecutionModel(reader,base),tok=new api.Tok(em);console.log('Model:',em.meta['general.name'],'pre:',tok.pre,'vocab',tok.tokens.length,'smol:',tok.smol);
 const cases=['Hello','How are you?',"I'm testing 12345 and 3.14159.",'Café — naïve 🦊\n第二行','  spaced\ttext\n\nnext',"we'll he's don't I've",'مرحبا ١٢٣'];
 fs.writeFileSync(__dirname+'/tokenizer_actual.json',JSON.stringify({cases:cases.map(text=>({text,ids:tok.encodeText(text)})),chat:tok.chatIds([{role:'user',content:'Hello'}]),vocabHash:require('crypto').createHash('sha256').update(JSON.stringify(tok.tokens)).digest('hex')}));
 fs.writeFileSync(__dirname+'/gguf_meta.json',JSON.stringify(em.meta));
 const eng=await new api.MistralEngine(reader,em,{}).init();let logits;const ids=tok.encodeText('Hello world');for(let i=0;i<ids.length;i++)logits=await eng.token(ids[i],i,()=>{});fs.writeFileSync(__dirname+'/engine_logits.bin',Buffer.from(logits.buffer));fs.writeFileSync(__dirname+'/logit_tokens.json',JSON.stringify(ids));console.log('CPU graph logits computed',ids);if(errors.length)throw Error(errors.join('\n'));dom.window.close();
})().catch(e=>{console.error(e);process.exit(1)});
