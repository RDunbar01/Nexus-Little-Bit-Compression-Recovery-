# NEXUS v11 — size-optimized distribution

This ZIP is a complete copy of NEXUS WebGPU Complete v11, repackaged to eliminate a duplicate 10-million-token corpus payload. Both browser HTML applications now share `nexus_corpus_payload.js`, located alongside them.

1. Extract **the entire ZIP** (do not open HTML from inside the ZIP file).
2. Open `NEXUS_LittleBit_Recovery_Studio/Nexus_Web_LLM.html` or `NEXUS_LittleBit_Recovery_Studio/NEXUS_LittleBit_Recovery_Studio.html` in an up-to-date Edge or Chrome browser.
3. Keep `nexus_corpus_payload.js` in the same folder as both HTML files, or the recovery curriculum will not load.
4. Optional: `python launch.py` from the app folder starts the local Python interface.

**No recovery tokens, application components, or verification fixtures were removed.** The corpus data is SHA-256 checked before Python extraction and browser export. This packaging change does not itself establish model-quality or GPU-performance results.
