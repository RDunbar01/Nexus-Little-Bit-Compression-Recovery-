"""Validate and extract the corpus carried inside the standalone HTML."""
from pathlib import Path
import base64,hashlib,io,json,re,zipfile,os
FILES={*(f'stage{i}.tokens.bin' for i in range(1,6)),'validation.tokens.bin','manifest.json'}
def embedded_zip(html):
    """Load and verify a corpus from legacy standalone HTML or shared local JS."""
    html=Path(html)
    text=html.read_text(encoding='utf8')
    legacy=re.search(r'<script id="nexus-corpus-payload" type="application/octet-stream" data-sha256="([0-9a-f]{64})">([A-Za-z0-9+/=\s]+)</script>',text)
    if legacy:
        digest,encoded=legacy.group(1,2)
    else:
        if not re.search(r'<script src="\./nexus_corpus_payload\.js"></script>',text):
            raise ValueError('No embedded corpus payload or linked corpus asset')
        shared=html.parent/'nexus_corpus_payload.js'
        source=shared.read_text(encoding='utf8')
        sha=re.search(r'payload\.dataset\.sha256\s*=\s*"([0-9a-f]{64})"',source)
        data=re.search(r'payload\.textContent\s*=\s*"([A-Za-z0-9+/=]+)"',source)
        if not sha or not data:raise ValueError('Shared corpus JS asset invalid')
        digest,encoded=sha.group(1),data.group(1)
    raw=base64.b64decode(encoded,validate=False)
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Embedded archive SHA256 mismatch')
    return raw

def extract(html,destination):
    destination=Path(destination)
    raw=embedded_zip(html)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if set(z.namelist())!=FILES or len(z.namelist())!=len(FILES):raise ValueError('Unexpected embedded archive entries')
        if sum(i.file_size for i in z.infolist())>100_000_000:raise ValueError('Corpus archive too large')
        manifest=json.loads(z.read('manifest.json'));contents={n:z.read(n) for n in FILES}
        for n in FILES-{'manifest.json'}:
            data=contents[n]
            if len(data)%4 or hashlib.sha256(data).hexdigest()!=manifest['sha256'].get(n):raise ValueError('Corrupt token file: '+n)
            count=manifest['validation_tokens'] if n.startswith('validation') else manifest['tokens_per_stage']
            if len(data)!=count*4:raise ValueError('Token count mismatch: '+n)
        # Existing corpus may belong to another run. Never silently replace it.
        destination.mkdir(parents=True,exist_ok=True)
        for n,data in contents.items():
            p=destination/n
            if p.exists() and p.read_bytes()!=data:raise FileExistsError('Different corpus exists: '+str(p))
        for n in sorted(FILES-{'manifest.json'})+['manifest.json']:
            p=destination/n
            if p.exists():continue
            tmp=destination/(n+'.partial');tmp.write_bytes(contents[n]);os.replace(tmp,p)
    return manifest
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('html');a.add_argument('--output',default='corpus');r=a.parse_args()
    print(json.dumps(extract(r.html,r.output),indent=2))
