"""Embed a shared corpus asset used by both local HTML applications."""
from pathlib import Path
import zipfile,io,json,hashlib,base64,re
ROOT=Path(__file__).resolve().parent

def build():
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted((ROOT/'corpus').iterdir()):
            if p.name=='manifest.json' or p.name.endswith('.tokens.bin'):
                info=zipfile.ZipInfo(p.name,(2026,10,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,p.read_bytes())
    raw=data.getvalue();digest=hashlib.sha256(raw).hexdigest()
    path=ROOT/'NEXUS_LittleBit_Recovery_Studio.html';html=path.read_text()
    html=re.sub(r'<!-- EMBEDDED_CORPUS_START -->.*?<!-- EMBEDDED_CORPUS_END -->','',html,flags=re.S)
    block='<!-- EMBEDDED_CORPUS_START -->\n'
    block+='<script id="nexus-corpus-manifest" type="application/json">'+(ROOT/'corpus/manifest.json').read_text().replace('<','\\u003c')+'</script>\n'
    corpus_b64=base64.b64encode(raw).decode('ascii')
    shared=(
        '/* NEXUS 10M-token shared local recovery corpus. */\n'
        '(function(){\n'
        '  const host=document.currentScript;\n'
        '  if(!host)throw Error("Missing NEXUS corpus script host");\n'
        '  const payload=document.createElement("script");\n'
        '  payload.id="nexus-corpus-payload";\n'
        '  payload.type="application/octet-stream";\n'
        '  payload.dataset.sha256="'+digest+'";\n'
        '  payload.textContent="'+corpus_b64+'";\n'
        '  host.after(payload);\n'
        '})();\n'
    )
    (ROOT/'nexus_corpus_payload.js').write_text(shared,encoding='utf8')
    block+='<script src="./nexus_corpus_payload.js"></script>\n'
    block+='''<script>
(function(){
 const status=document.getElementById('embeddedCorpusStatus');
 document.getElementById('inspectEmbeddedCorpus').onclick=()=>{
   const box=document.getElementById('embeddedCorpusManifest');
   box.textContent=JSON.stringify(JSON.parse(document.getElementById('nexus-corpus-manifest').textContent),null,2);
   box.style.display=box.style.display==='none'?'block':'none';
 };
 document.getElementById('exportEmbeddedCorpus').onclick=async function(){
   this.disabled=true;status.textContent='Decoding and verifying included corpus…';
   try{
     await new Promise(r=>setTimeout(r,0));
     const node=document.getElementById('nexus-corpus-payload');
     const raw=atob(node.textContent.trim());const data=new Uint8Array(raw.length);
     for(let i=0;i<raw.length;i++)data[i]=raw.charCodeAt(i);
     let verified=false;
     if(globalThis.crypto?.subtle){
       const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),x=>x.toString(16).padStart(2,'0')).join('');
       if(digest!==node.dataset.sha256)throw Error('Embedded archive checksum mismatch');
       verified=true;
     }
     const url=URL.createObjectURL(new Blob([data],{type:'application/zip'}));
     const a=document.createElement('a');a.href=url;a.download='NEXUS_SmolLM2_10M_Corpus.zip';a.click();
     setTimeout(()=>URL.revokeObjectURL(url),30000);
     status.textContent=(verified?'SHA-256 verified. ':'Browser hashing unavailable; Python extractor will verify. ')+
       'Corpus ZIP exported. Extract into the corpus folder beside launch.py. 10M curriculum tokens + 32,768 held-out validation tokens.';
   }catch(e){status.textContent='Export failed: '+e.message;}finally{this.disabled=false;}
 };
})();
</script>\n<!-- EMBEDDED_CORPUS_END -->'''
    html=html.replace('</body>',block+'\n</body>');path.write_text(html)
    print('Shared corpus ZIP bytes:',len(raw),'Studio HTML bytes:',path.stat().st_size,'SHA256:',digest)
if __name__=='__main__':build()
